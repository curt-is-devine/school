README.txt for the Windows Application: RPNCalculator

Consists of: 	-frmRPNCalculator.cs
		-frmRPNCalculator.Designer.cs
		-frmRPNCalculator.resx

Description:
	This project functions as a simple "Reverse Polish" calculator, a.k.a. 
a postfix notation calculator. This simply translates to that functions represented 
as 2 + 4 = 4 become 2 4 + 4. Functions included in this calculator include 
addition, subtraction, multiplication, division, modulo, exponentiation, factorial, 
and roots (taking the n-th root of a number). The application consists of two text 
entry fields for the user's input numbers and an answer field for the result of 
whatever calculation the user desires. Clear and Quit buttons are incorporated in 
order to allow for clearing of information, defaulting both input fields to zero,
and for graceful closing of the application respectively. 
	The app is purposefully plain. The guidelines given by the "investor" clearly
stated that this app needs to be sleek and professional while still giving a unique 
take on how a calculator should behave. Thus, the only real design decisions made
were to chang ethe background color of the application to a more mechanical color, 
change font of lables and buttons to be more rigid and scientific in their structure,
bolding the factorial (!) label so that it would not look so much like a line and more
like an exclamation mark, and extension of the answer field to allow for large outputs
that the applicaiton may output for any of the operations. Text fields have been placed
one over the other in order to keep the post-fix layout, with function buttons separating
those fields form the answer field. The eight buttons are layed out in a 3 x 3 layout in 
order to be symmetric in their presentation. Below the answer field are Clear and Quit 
buttons, extended horizontally to give these buttons more presence since they are more
important functionally. The buttons are laid side-by-side due to the fact that most
applications the user is accustomed to have these buttons side by side at the bottom 
of each page that they are a part of, and caring for the user is a central theme in 
all of my projects.
	Along the lines of caring for the user, checks exist for each function and
text field to ensure that the user is entering information that is valid for the 
operation and for mathematic operations in general.If the user leaves the field with 
a string of letters inserted, or even leaves the field empty, the program will immediately 
warn the user that this is an invalid input, and replace it with a zero to allow the user 
to do some sort of calculation with their input. In the case of functions like rooting, 
division, or factorial, zeros or negatives may not be allowed for certain numbers in the
operation. This is accounted for in the code, which will output to the answer field that
there is a problem in the input numbers. For example, entering a 0 for the second number 
and using the division operator will result in the message "Divide by zero error" and 
taking the square root of a negative number will result in "The answer is imaginary". 
Thus, car efor the user is addressed and the application accomplishes what it set out to do.

