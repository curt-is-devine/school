﻿/**********************************************************
* frmRPNCalculator.cs
*
* These definitions set up a Reverse Polish Calculator
*
* Author: Curtis Devine
* Date Created: 11-13-2017
* Last Modified by: Curtis Devine
* Date Last Modified: 12-2-2017
* Assignment: Homework Project 3
* Part of: RPNCalculator
*/

//Importing of all necessary libraries
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Initialization of the form within the project
namespace RPNCalculator
{
    public partial class frmRPNCalculator : Form
    {
        //intialization of the global variables used throughout the project
        double dblFirstNum = 0;
        double dblSecondNum = 0;
        double dblAnswer = 0;
        string strFirstNum = "0";
        string strSecondNum = "0";
        string strAnswer = "0";
        string strTest = "0";
        double dblNumCheck = 0;
        public bool isNum;

        //Initialization of the form
        public frmRPNCalculator()
        {
            InitializeComponent();
        }

        //a helper function for the factorial function of the calculator
        double factorial(double num)
        {
            //variable for storing the total up to this point from 1
            double store;

            //edge case of factorial function: zero and one result in 1
            if (num == 1 || num == 0)
            {
                store = 1;
            }

            //if not one or zero, the function multiplies the input number by the factorial of the 
            //number minus one (recursive call)
            else
            {
                store = num * factorial(num - 1);
            }
            //returns the stored value of the factorial
            return store;
        }

        //When the calculator loads:
        private void frmRPNCalculator_Load(object sender, EventArgs e)
        {
            //Set the text values of the first number and second number to be text describing the fields
            txtFirstNum.Text = "First Number";
            txtSecondNum.Text = "Second Number";
        }

        //When leaving the first number field:
        private void txtfirstnum_Leave(object sender, EventArgs e)
        {
            //Set the string value of the first number field to a global variable
            strFirstNum = txtFirstNum.Text.ToString();
            strTest = strFirstNum;

            //set the global testing boolean to if the string can be represented as a double or not
            bool isNum = double.TryParse(strTest, out dblNumCheck);

            //if it can:
            if (isNum)
            {
                //set the double appropriately
                dblFirstNum = double.Parse(strFirstNum);
            }
            //otherwise if the field is empty:
            else if (strFirstNum.Equals(""))
            {
                //set the string to zero, set 0 to be the value of the double, and send a 
                //messagebox to the user saying that they did not enter anything
                strFirstNum = "0";
                txtFirstNum.Text = strFirstNum;
                dblFirstNum = double.Parse(strFirstNum);
                MessageBox.Show("OOPS!!! You didn't enter anything. Try again");
            }
            //otherwise (the string cannot be represented by a double):
            else
            {
                //set the string to zero, set 0 to be the value of the double, and send a 
                //messagebox to the user saying that they did not enter a number
                strFirstNum = "0";
                txtFirstNum.Text = strFirstNum;
                dblFirstNum = double.Parse(strFirstNum);
                MessageBox.Show("That was not a number. Try again");
            }

            
        }

        //When leaving the second number field:
        private void txtSecondNum_Leave(object sender, EventArgs e)
        {
            //Set the string value of the second number field to a global variable
            strSecondNum = txtSecondNum.Text.ToString();
            strTest = strSecondNum;

            //set the global testing boolean to if the string can be represented as a double or not
            bool isNum = double.TryParse(strTest, out dblNumCheck);

            //if it can:
            if (isNum)
            {
                //set the double appropriately
                dblSecondNum = double.Parse(strSecondNum);
            }
            //otherwise if the field is empty:
            else if (strFirstNum.Equals(""))
            {
                //set the string to zero, set 0 to be the value of the double, and send a 
                //messagebox to the user saying that they did not enter anything
                strSecondNum = "0";
                txtSecondNum.Text = strSecondNum;
                dblSecondNum = double.Parse(strSecondNum);
                MessageBox.Show("OOPS!!! You didn't enter anything");
            }
            //otherwise (the string cannot be represented by a double):
            else
            {
                //set the string to zero, set 0 to be the value of the double, and send a 
                //messagebox to the user saying that they did not enter a number
                strSecondNum = "0";
                txtSecondNum.Text = strSecondNum;
                dblSecondNum = double.Parse(strSecondNum);
                MessageBox.Show("That was not a number. Try again");
            }
            
        }

        //Function for addition:
        private void btnAdd_Click(object sender, EventArgs e)
        {
            //Set the text values in case factorial was used previously or the clear button was used
            txtFirstNum.Text = strFirstNum;
            txtSecondNum.Text = strSecondNum;

            //Add the numbers, convert to a string, and output it to the answer field
            dblAnswer = (dblFirstNum + dblSecondNum);
            strAnswer = dblAnswer.ToString();
            txtAnswer.Text = strAnswer;
        }

        //Function for subtraction:
        private void btnSubt_Click(object sender, EventArgs e)
        {
            //Set the text values in case factorial was used previously or the clear button was used
            txtFirstNum.Text = strFirstNum;
            txtSecondNum.Text = strSecondNum;

            //Subract the numbers, convert to a string, and output it to the answer field
            dblAnswer = (dblFirstNum - dblSecondNum);
            strAnswer = dblAnswer.ToString();
            txtAnswer.Text = strAnswer;
        }

        //Function for multiplication:
        private void btnMult_Click(object sender, EventArgs e)
        {
            //Set the text values in case factorial was used previously or the clear button was used
            txtFirstNum.Text = strFirstNum;
            txtSecondNum.Text = strSecondNum;

            //Multiply the numbers, convert to a string, and output it to the answer field
            dblAnswer = (dblFirstNum * dblSecondNum);
            strAnswer = dblAnswer.ToString();
            txtAnswer.Text = strAnswer;
        }

        //Function for division:
        private void btnDiv_Click(object sender, EventArgs e)
        {
            //Set the text values in case factorial was used previously or the clear button was used
            txtFirstNum.Text = strFirstNum;
            txtSecondNum.Text = strSecondNum;

            //If the second number is a zero:
            if (dblSecondNum == 0.0)
            {           
                //output a divide by zero error
                txtAnswer.Text = "Divide by zero error";
            }
            //otherwise:
            else
            {
                //Divide the numbers, convert to a string, and output it to the answer field
                dblAnswer = (dblFirstNum / dblSecondNum);
                strAnswer = dblAnswer.ToString();
                txtAnswer.Text = strAnswer;
            }
            
        }

        //Function for factorial:
        private void btnFact_Click(object sender, EventArgs e)
        {
            //Set the text values in case the clear button was used, and delete the second number since 
            //factorial is a one number operation
            txtFirstNum.Text = strFirstNum;
            txtSecondNum.Text = "";

            //If the first number is negative:
            if (dblFirstNum < 0)
            {
                //output an error that negative numbers cannot be factorialized
                txtAnswer.Text = "Cannot apply factorial to negative numbers";
            }
            //otherwise:
            else
            {
                //Factorial the first number, convert to a string, and output it to the answer field
                dblAnswer = factorial(dblFirstNum);
                strAnswer = dblAnswer.ToString();
                txtAnswer.Text = strAnswer;
            }
            
        }

        //Function for modulo:
        private void btnMod_Click(object sender, EventArgs e)
        {
            //Set the text values in case factorial was used previously or the clear button was used
            txtFirstNum.Text = strFirstNum;
            txtSecondNum.Text = strSecondNum;

            //If the second number is a zero:
            if (dblSecondNum == 0.0)
            {                
                //output a modulo zero error
                txtAnswer.Text = "Modulo zero is undefined";
            }
            //otherwise:
            else
            {
                //modulo the numbers, convert to a string, and output it to the answer field
                dblAnswer = dblFirstNum % dblSecondNum;
                strAnswer = dblAnswer.ToString();
                txtAnswer.Text = strAnswer;
            }
            
        }

        //Function for exponentiation:
        private void btnPower_Click(object sender, EventArgs e)
        {
            //Set the text values in case factorial was used previously or the clear button was used
            txtFirstNum.Text = strFirstNum;
            txtSecondNum.Text = strSecondNum;

            //Exponentiate the numbers using a Visual Studio class, convert to a string, 
            //and output it to the answer field
            dblAnswer = Math.Pow(dblFirstNum, dblSecondNum);
            strAnswer = dblAnswer.ToString();
            txtAnswer.Text = strAnswer;
        }

        //Function for taking a root:
        private void btnRoot_Click(object sender, EventArgs e)
        {
            //Set the text values in case factorial was used previously or the clear button was used
            txtFirstNum.Text = strFirstNum;
            txtSecondNum.Text = strSecondNum;

            //If the second number is a zero:
            if (dblSecondNum == 0.0)
            {                
                //add a zero-th root error
                txtAnswer.Text = "Cannot take zero-th root";
            }
            //otherwise: If the first number is negative:
            else if (dblFirstNum < 0) {
                //output an imaginary answer output
                txtAnswer.Text = "The answer is imaginary";
            }
            //otherwise:
            else
            {
                //Root the numbers, convert to a string, and output it to the answer field
                dblAnswer = Math.Pow(dblFirstNum, 1 / dblSecondNum);
                strAnswer = dblAnswer.ToString();
                txtAnswer.Text = strAnswer;
            }
            
        }

        //If the clear button is clicked:
        private void btnClear_Click(object sender, EventArgs e)
        {
            //set the text values of the text fields to be 0 and clear the answer field
            txtFirstNum.Text = "0";
            txtSecondNum.Text = "0";
            txtAnswer.Text = "";

            //Set the string variable to reflect the text and then convert the doubles
            strFirstNum = txtFirstNum.Text;
            strSecondNum = txtSecondNum.Text;
            dblFirstNum = double.Parse(strFirstNum);
            dblSecondNum = double.Parse(strSecondNum);
        }

        //If the quit button is clicked, close the application
        private void btnQuit_Click(object sender, EventArgs e)
        {
            Close();
        }

        //when clicking the text field for the first number, clear the field
        private void txtFirstNum_MouseDown(object sender, MouseEventArgs e)
        {
            txtFirstNum.Text = "";
        }

        //when clicking the text field for the second number, clear the field
        private void txtSecondNum_MouseDown(object sender, MouseEventArgs e)
        {
            txtSecondNum.Text = "";
        }
    }
}
