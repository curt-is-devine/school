﻿/*A590Buffet
*
* A page that demonstrates to the user controls on the page via dialog box
*
* Author: Curtis Devine
* Date Created: 11-13-2017
* Last Modified by: Curtis Devine
* Date Last Modified: 11-13-2017
* Assignment: Assignment 2, A590Buffet 
* Part of: Assignment 2: A590Buffet
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Aspect of the page changed: Changed background color of the buttons to white and text color of all 
//controls to a blood red. Bakcground image is a knife in order to keep the creepy vibe going. Background
//color is also not the default (although you cannot tell due to the background image).

namespace A590Buffet
{
    public partial class frmBuffetCollection : Form
    {
        public frmBuffetCollection()
        {
            InitializeComponent();
        }

        //Event listener that initiates the dialog boxes that show all of the controls and their names
        private void btnShowNames_Click(object sender, EventArgs e)
        {
            //for every control (number is stored in the application), create a message box that shows
            //which control number it is as well as the name
            for (int intIndex = 0; intIndex < Controls.Count; intIndex++)
            {
                MessageBox.Show("Control #" + (intIndex + 1).ToString() + " has the name " + Controls[intIndex].Name);
            }
        }

        //Closes the form when the "OK" button is clicked (Or if Esc or Enter are hit)
        private void btnOk_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
