﻿/*A590Buffet
*
* A page allows the user to modify design options for the form.
*
* Author: Curtis Devine
* Date Created: 11-13-2017
* Last Modified by: Curtis Devine
* Date Last Modified: 11-13-2017
* Assignment: Assignment 2, A590Buffet 
* Part of: Assignment 2: A590Buffet
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A590Buffet
{
    public partial class frmBuffetOptions : Form
    {
        public frmBuffetOptions()
        {
            InitializeComponent();
        }


        //A helper function that is supposed to draw a new border on the page
        //whenever the background color is changed. I could not get this to work.
        private void colorBorder()
        {
            //Uses a switch construct to determine what color to make the border, either green, yellow
            //orange, gray, or the default.
            switch (cboBorderColors.Text)
            {
                case "Green":
                    //for each color, a ne wgraphics object is created. Then it is initiated and
                    //a rectangle is drawn. when the rectangle is done being drawn, the graphic 
                    //object is thrown away and the code breaks away.
                    Graphics objGraphicsGreen = null;
                    objGraphicsGreen = CreateGraphics();
                    objGraphicsGreen.DrawRectangle(Pens.Green, 1, 1, 281, 258);
                    objGraphicsGreen.Dispose();
                    break;
                case "Yellow":
                    Graphics objGraphicsYellow = null;
                    objGraphicsYellow = CreateGraphics();
                    objGraphicsYellow.DrawRectangle(Pens.Yellow, 1, 1, 281, 258);
                    objGraphicsYellow.Dispose();
                    break;
                case "Orange":
                    Graphics objGraphicsOrange = null;
                    objGraphicsOrange = CreateGraphics();
                    objGraphicsOrange.DrawRectangle(Pens.Orange, 1, 1, 281, 258);
                    objGraphicsOrange.Dispose();
                    break;
                case "Gray":
                    Graphics objGraphicsGray = null;
                    objGraphicsGray = CreateGraphics();
                    objGraphicsGray.DrawRectangle(Pens.Gray, 1, 1, 281, 258);
                    objGraphicsGray.Dispose();
                    break;
                default:
                    Graphics objGraphicsDefault = null;
                    objGraphicsDefault = CreateGraphics();
                    objGraphicsDefault.DrawRectangle(Pens.LightSteelBlue, 1, 1, 281, 258);
                    objGraphicsDefault.Dispose();
                    break;
            }
        }


        //Event Handler that closes the application when the "OK" button is clicked.
        private void btnOK_Click(object sender, EventArgs e)
        {
            Close();
        }

        //Event Handler that closes the application when the "Cancel" button is clicked.
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        //Event Handler that changes the bakcground color of the app when the  orange radio button
        //is selected (It says red in the code because Visual studio would not let me change this
        //without throwing a fit)
        private void optBackgroundRed_CheckedChanged(object sender, EventArgs e)
        {
            //The back color is changed to orange, the text for the orange radio button is changed
            //to white, and all other buttons are given their original color.
            BackColor = Color.Orange;
            optBackgroundOrange.ForeColor = System.Drawing.Color.White;
            optBackgroundBlue.ForeColor = System.Drawing.Color.CornflowerBlue;
            optBackgroundPurple.ForeColor = System.Drawing.Color.Magenta;

            //Attempt to keep the border present.
            colorBorder();              
        }

        //Event Handler that changes the bakcground color of the app when the blue radio button
        //is selected 
        private void optBackgroundBlue_CheckedChanged(object sender, EventArgs e)
        {
            //The back color is changed to a shade of blue, the text for the blue radio button is changed
            //to white, and all other buttons are given their original color.
            BackColor = Color.CornflowerBlue;
            optBackgroundOrange.ForeColor = System.Drawing.Color.Orange;
            optBackgroundBlue.ForeColor = System.Drawing.Color.White;
            optBackgroundPurple.ForeColor = System.Drawing.Color.Magenta;

            //Attempt to redraw the current border
            colorBorder();
        }

        //Event Handler that changes the bakcground color of the app when the purple radio button
        //is selected 
        private void optBackgroundPurple_CheckedChanged(object sender, EventArgs e)
        {
            //The back color is changed to Magenta, the text for the Purple radio button is changed
            //to white, and all other buttons are given their original color.
            BackColor = Color.Magenta;
            optBackgroundOrange.ForeColor = System.Drawing.Color.Orange;
            optBackgroundBlue.ForeColor = System.Drawing.Color.CornflowerBlue;
            optBackgroundPurple.ForeColor = System.Drawing.Color.White;

            //Attempt to redraw current border
            colorBorder();
        }

        //Event Handler that changes the bakcground color of the app when the default radio button
        //is selected 
        private void optBackgroundDefault_CheckedChanged(object sender, EventArgs e)
        {
            //The back color is changed to the default, and all other buttons are given their original color.
            BackColor = Color.LightSteelBlue;
            optBackgroundOrange.ForeColor = System.Drawing.Color.Orange;
            optBackgroundBlue.ForeColor = System.Drawing.Color.CornflowerBlue;
            optBackgroundPurple.ForeColor = System.Drawing.Color.Magenta;

            
        }

        //An event listener that adds a border to the form whenever the user selects one of the combobox options
        private void cboBorderColors_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Uses a switch construct to determine what color to make the border, either green, yellow
            //orange, gray, or the default.
            switch (cboBorderColors.Text)
            {
                case "Green":
                    //for each color, a new graphics object is created. Then it is initiated and
                    //a rectangle is drawn. when the rectangle is done being drawn, the graphic 
                    //object is thrown away and the code breaks away.
                    MessageBox.Show("Green was chosen");
                    Graphics objGraphicsGreen = null;
                    objGraphicsGreen = CreateGraphics();
                    //This line is commented out as it was what caused the bakckground color to break
                    //objGraphicsGreen.Clear(SystemColors.Control);
                    objGraphicsGreen.DrawRectangle(Pens.Green, 1, 1, 281, 258);
                    objGraphicsGreen.Dispose();
                    break;
                case "Yellow":
                    MessageBox.Show("Yellow was chosen");
                    Graphics objGraphicsYellow = null;
                    objGraphicsYellow = CreateGraphics();
                    //objGraphicsYellow.Clear(SystemColors.Control);
                    objGraphicsYellow.DrawRectangle(Pens.Yellow, 1, 1, 281, 258);
                    objGraphicsYellow.Dispose();
                    break;
                case "Orange":
                    MessageBox.Show("Orange was chosen");
                    Graphics objGraphicsOrange = null;
                    objGraphicsOrange = CreateGraphics();
                    //objGraphicsOrange.Clear(SystemColors.Control);
                    objGraphicsOrange.DrawRectangle(Pens.Orange, 1, 1, 281, 258);
                    objGraphicsOrange.Dispose();
                    break;
                case "Gray":
                    MessageBox.Show("Gray was chosen");
                    Graphics objGraphicsGray = null;
                    objGraphicsGray = CreateGraphics();
                    //objGraphicsGray.Clear(SystemColors.Control);
                    objGraphicsGray.DrawRectangle(Pens.Gray, 1, 1, 281, 258);
                    objGraphicsGray.Dispose();
                    break;
                default:
                    MessageBox.Show("Back to the Default");
                    Graphics objGraphicsDefault = null;
                    objGraphicsDefault = CreateGraphics();
                    //objGraphicsDefault.Clear(SystemColors.Control);
                    objGraphicsDefault.DrawRectangle(Pens.LightSteelBlue, 1, 1, 281, 258);
                    objGraphicsDefault.Dispose();
                    break;
            }
        }
    }
}