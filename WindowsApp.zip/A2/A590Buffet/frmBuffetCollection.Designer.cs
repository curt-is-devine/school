﻿namespace A590Buffet
{
    partial class frmBuffetCollection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBuffetCollection));
            this.btnShowNames = new System.Windows.Forms.Button();
            this.btnLeatherface = new System.Windows.Forms.Button();
            this.btnJigsaw = new System.Windows.Forms.Button();
            this.btnFreddy = new System.Windows.Forms.Button();
            this.btnMichael = new System.Windows.Forms.Button();
            this.btnJason = new System.Windows.Forms.Button();
            this.txtKillers = new System.Windows.Forms.TextBox();
            this.btnOk = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnShowNames
            // 
            this.btnShowNames.BackColor = System.Drawing.Color.White;
            this.btnShowNames.Font = new System.Drawing.Font("Papyrus", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowNames.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnShowNames.Location = new System.Drawing.Point(76, 149);
            this.btnShowNames.Name = "btnShowNames";
            this.btnShowNames.Size = new System.Drawing.Size(130, 27);
            this.btnShowNames.TabIndex = 7;
            this.btnShowNames.Text = "Show Control Names";
            this.btnShowNames.UseVisualStyleBackColor = false;
            this.btnShowNames.Click += new System.EventHandler(this.btnShowNames_Click);
            // 
            // btnLeatherface
            // 
            this.btnLeatherface.BackColor = System.Drawing.Color.White;
            this.btnLeatherface.Font = new System.Drawing.Font("Papyrus", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLeatherface.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnLeatherface.Location = new System.Drawing.Point(144, 42);
            this.btnLeatherface.Name = "btnLeatherface";
            this.btnLeatherface.Size = new System.Drawing.Size(123, 25);
            this.btnLeatherface.TabIndex = 5;
            this.btnLeatherface.Text = "Leatherface";
            this.btnLeatherface.UseVisualStyleBackColor = false;
            // 
            // btnJigsaw
            // 
            this.btnJigsaw.BackColor = System.Drawing.Color.White;
            this.btnJigsaw.Font = new System.Drawing.Font("Papyrus", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJigsaw.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnJigsaw.Location = new System.Drawing.Point(15, 42);
            this.btnJigsaw.Name = "btnJigsaw";
            this.btnJigsaw.Size = new System.Drawing.Size(123, 25);
            this.btnJigsaw.TabIndex = 4;
            this.btnJigsaw.Text = "Jigsaw";
            this.btnJigsaw.UseVisualStyleBackColor = false;
            // 
            // btnFreddy
            // 
            this.btnFreddy.BackColor = System.Drawing.Color.White;
            this.btnFreddy.Font = new System.Drawing.Font("Papyrus", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFreddy.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnFreddy.Location = new System.Drawing.Point(192, 13);
            this.btnFreddy.Name = "btnFreddy";
            this.btnFreddy.Size = new System.Drawing.Size(81, 25);
            this.btnFreddy.TabIndex = 3;
            this.btnFreddy.Text = "Freddy";
            this.btnFreddy.UseVisualStyleBackColor = false;
            // 
            // btnMichael
            // 
            this.btnMichael.BackColor = System.Drawing.Color.White;
            this.btnMichael.Font = new System.Drawing.Font("Papyrus", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMichael.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnMichael.Location = new System.Drawing.Point(105, 13);
            this.btnMichael.Name = "btnMichael";
            this.btnMichael.Size = new System.Drawing.Size(81, 25);
            this.btnMichael.TabIndex = 2;
            this.btnMichael.Text = "Michael";
            this.btnMichael.UseVisualStyleBackColor = false;
            // 
            // btnJason
            // 
            this.btnJason.BackColor = System.Drawing.Color.White;
            this.btnJason.Font = new System.Drawing.Font("Papyrus", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJason.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnJason.Location = new System.Drawing.Point(15, 13);
            this.btnJason.Name = "btnJason";
            this.btnJason.Size = new System.Drawing.Size(81, 25);
            this.btnJason.TabIndex = 1;
            this.btnJason.Text = "Jason";
            this.btnJason.UseVisualStyleBackColor = false;
            // 
            // txtKillers
            // 
            this.txtKillers.BackColor = System.Drawing.Color.White;
            this.txtKillers.Font = new System.Drawing.Font("Papyrus", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKillers.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtKillers.Location = new System.Drawing.Point(76, 71);
            this.txtKillers.Name = "txtKillers";
            this.txtKillers.Size = new System.Drawing.Size(120, 28);
            this.txtKillers.TabIndex = 6;
            this.txtKillers.Text = "Killers";
            // 
            // btnOk
            // 
            this.btnOk.BackColor = System.Drawing.Color.White;
            this.btnOk.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnOk.Font = new System.Drawing.Font("Papyrus", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOk.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnOk.Location = new System.Drawing.Point(192, 227);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(83, 25);
            this.btnOk.TabIndex = 0;
            this.btnOk.Text = "Ok";
            this.btnOk.UseVisualStyleBackColor = false;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // frmBuffetCollection
            // 
            this.AcceptButton = this.btnOk;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.CancelButton = this.btnOk;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.txtKillers);
            this.Controls.Add(this.btnJason);
            this.Controls.Add(this.btnMichael);
            this.Controls.Add(this.btnFreddy);
            this.Controls.Add(this.btnJigsaw);
            this.Controls.Add(this.btnLeatherface);
            this.Controls.Add(this.btnShowNames);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmBuffetCollection";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "A590 Buffet Collection";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnShowNames;
        private System.Windows.Forms.Button btnLeatherface;
        private System.Windows.Forms.Button btnJigsaw;
        private System.Windows.Forms.Button btnFreddy;
        private System.Windows.Forms.Button btnMichael;
        private System.Windows.Forms.Button btnJason;
        private System.Windows.Forms.TextBox txtKillers;
        private System.Windows.Forms.Button btnOk;
    }
}