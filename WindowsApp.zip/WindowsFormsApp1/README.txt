Icon made by http://www.danilodemarco.com/
All images used are part of the public domain

This application simulates a quiz that helps a user decide on what to eat, based on his current taste
preferences. The initial form allows the user to select a button that could start the quiz, provide
a help page, or close out of the application if he has had a change of heart.

The help form provides a simple dialog to the user that explains the application and how it works. Once
done reading, the user can click a Cancel button and returns to the home page.

In the Quiz part of the application: the user is prompted with many questions to determine what he or she
may desire taste wise. Check boxes were used in case the user was feeling indecisive about what they want.
A Next button allows the user to progress to the next question, and a Previous button allows regression
to the previous question set, erasing all entries into the data for the current and previous question. 
The user is allowed to quit the quiz whenever he desires, and can click a Quit button to exit the quiz
and return to the home screen.

Once all questions have been answered, the application processes the user answers and determines a food 
item that matches what the user desires. Additional buttons are incorporated to allow the user to retake
the quiz or close the results form and return to the menu. 

In order to test this code, you must (naturally) use Visual Studio. The user can select how ever many food
preferences he wants and he will still get an output that makes sense. As far as I can tell, this application
will not fail except in the case that the host computer is too slow. 

Last minute changes to this project included removing the additional foods that were not best matches,
but good second options as I ran out of time to incorporate this functionality. I also removed the button 
on the results page that would close the application. I could only ever close the results page, and not the
whole application, and with time running short I had to abandon that objective. The original project proposal
said I would be using classes to store the information that the user entered, but passing a list of data from
form to form proved to be challenging enough, let alone a data type not defined throughout the environment. So
I abandoned that goal for one that may be more messy logically, but more intuitive in regards to typing. Other
than these minor issues, I believe that this app is a success.

Fun fact: the use of orange as the background color was due to the fact that the colors yellow, red, and orange
are proven to make people hungry.