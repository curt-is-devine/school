﻿namespace WindowsFormsApp1
{
    partial class frmQuiz
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmQuiz));
            this.picFood = new System.Windows.Forms.PictureBox();
            this.lblQuestion = new System.Windows.Forms.Label();
            this.chkOpt6 = new System.Windows.Forms.CheckBox();
            this.chkOpt5 = new System.Windows.Forms.CheckBox();
            this.chkOpt4 = new System.Windows.Forms.CheckBox();
            this.chkOpt3 = new System.Windows.Forms.CheckBox();
            this.chkOpt2 = new System.Windows.Forms.CheckBox();
            this.chkOpt1 = new System.Windows.Forms.CheckBox();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrev = new System.Windows.Forms.Button();
            this.btnQuit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picFood)).BeginInit();
            this.SuspendLayout();
            // 
            // picFood
            // 
            this.picFood.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picFood.Location = new System.Drawing.Point(77, 14);
            this.picFood.Margin = new System.Windows.Forms.Padding(5);
            this.picFood.Name = "picFood";
            this.picFood.Size = new System.Drawing.Size(259, 193);
            this.picFood.TabIndex = 0;
            this.picFood.TabStop = false;
            // 
            // lblQuestion
            // 
            this.lblQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestion.Location = new System.Drawing.Point(14, 212);
            this.lblQuestion.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblQuestion.Name = "lblQuestion";
            this.lblQuestion.Size = new System.Drawing.Size(387, 61);
            this.lblQuestion.TabIndex = 1;
            this.lblQuestion.Text = "Placeholder";
            this.lblQuestion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chkOpt6
            // 
            this.chkOpt6.AutoSize = true;
            this.chkOpt6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkOpt6.Location = new System.Drawing.Point(225, 375);
            this.chkOpt6.Margin = new System.Windows.Forms.Padding(5);
            this.chkOpt6.Name = "chkOpt6";
            this.chkOpt6.Size = new System.Drawing.Size(15, 14);
            this.chkOpt6.TabIndex = 5;
            this.chkOpt6.UseVisualStyleBackColor = true;
            // 
            // chkOpt5
            // 
            this.chkOpt5.AutoSize = true;
            this.chkOpt5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkOpt5.Location = new System.Drawing.Point(77, 375);
            this.chkOpt5.Margin = new System.Windows.Forms.Padding(5);
            this.chkOpt5.Name = "chkOpt5";
            this.chkOpt5.Size = new System.Drawing.Size(15, 14);
            this.chkOpt5.TabIndex = 4;
            this.chkOpt5.UseVisualStyleBackColor = true;
            // 
            // chkOpt4
            // 
            this.chkOpt4.AutoSize = true;
            this.chkOpt4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkOpt4.Location = new System.Drawing.Point(225, 329);
            this.chkOpt4.Margin = new System.Windows.Forms.Padding(5);
            this.chkOpt4.Name = "chkOpt4";
            this.chkOpt4.Size = new System.Drawing.Size(15, 14);
            this.chkOpt4.TabIndex = 3;
            this.chkOpt4.UseVisualStyleBackColor = true;
            // 
            // chkOpt3
            // 
            this.chkOpt3.AutoSize = true;
            this.chkOpt3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkOpt3.Location = new System.Drawing.Point(77, 329);
            this.chkOpt3.Margin = new System.Windows.Forms.Padding(5);
            this.chkOpt3.Name = "chkOpt3";
            this.chkOpt3.Size = new System.Drawing.Size(15, 14);
            this.chkOpt3.TabIndex = 2;
            this.chkOpt3.UseVisualStyleBackColor = true;
            // 
            // chkOpt2
            // 
            this.chkOpt2.AutoSize = true;
            this.chkOpt2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkOpt2.Location = new System.Drawing.Point(225, 278);
            this.chkOpt2.Margin = new System.Windows.Forms.Padding(5);
            this.chkOpt2.Name = "chkOpt2";
            this.chkOpt2.Size = new System.Drawing.Size(15, 14);
            this.chkOpt2.TabIndex = 1;
            this.chkOpt2.UseVisualStyleBackColor = true;
            // 
            // chkOpt1
            // 
            this.chkOpt1.AutoSize = true;
            this.chkOpt1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkOpt1.Location = new System.Drawing.Point(77, 278);
            this.chkOpt1.Margin = new System.Windows.Forms.Padding(5);
            this.chkOpt1.Name = "chkOpt1";
            this.chkOpt1.Size = new System.Drawing.Size(15, 14);
            this.chkOpt1.TabIndex = 0;
            this.chkOpt1.UseVisualStyleBackColor = true;
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(346, 447);
            this.btnNext.Margin = new System.Windows.Forms.Padding(5);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(88, 35);
            this.btnNext.TabIndex = 3;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnPrev
            // 
            this.btnPrev.Location = new System.Drawing.Point(152, 447);
            this.btnPrev.Margin = new System.Windows.Forms.Padding(5);
            this.btnPrev.Name = "btnPrev";
            this.btnPrev.Size = new System.Drawing.Size(88, 35);
            this.btnPrev.TabIndex = 4;
            this.btnPrev.Text = "Previous";
            this.btnPrev.UseVisualStyleBackColor = true;
            this.btnPrev.Click += new System.EventHandler(this.btnPrev_Click);
            // 
            // btnQuit
            // 
            this.btnQuit.Location = new System.Drawing.Point(248, 447);
            this.btnQuit.Margin = new System.Windows.Forms.Padding(5);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(88, 35);
            this.btnQuit.TabIndex = 5;
            this.btnQuit.Text = "Quit";
            this.btnQuit.UseVisualStyleBackColor = true;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // frmQuiz
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Orange;
            this.ClientSize = new System.Drawing.Size(452, 500);
            this.Controls.Add(this.chkOpt5);
            this.Controls.Add(this.chkOpt6);
            this.Controls.Add(this.chkOpt3);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.chkOpt1);
            this.Controls.Add(this.btnPrev);
            this.Controls.Add(this.chkOpt4);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.chkOpt2);
            this.Controls.Add(this.lblQuestion);
            this.Controls.Add(this.picFood);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "frmQuiz";
            this.Text = "Eat Me! - Quiz";
            this.Load += new System.EventHandler(this.frmQuiz_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picFood)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picFood;
        private System.Windows.Forms.Label lblQuestion;
        private System.Windows.Forms.CheckBox chkOpt6;
        private System.Windows.Forms.CheckBox chkOpt5;
        private System.Windows.Forms.CheckBox chkOpt4;
        private System.Windows.Forms.CheckBox chkOpt3;
        private System.Windows.Forms.CheckBox chkOpt2;
        private System.Windows.Forms.CheckBox chkOpt1;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnPrev;
        private System.Windows.Forms.Button btnQuit;
    }
}