﻿/**********************************************************
* frmHome.cs
*
* A home page for the Eat Me! application. Displays a nice food picture and some buttons
*
* Author: Curtis Devine
* Date Created: 12/1/17
* Last Modified by: Curtis Devine
* Date Last Modified: 12/8/17
* Assignment: Final Project
* Part of: Eat Me!
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frmHome : Form
    {
        public frmHome()
        {
            InitializeComponent();
        }


        //Closes the application when the user clicks the "Quit" button
        private void btnQuit_Click(object sender, EventArgs e)
        {
            Close();
        }

        //Displays a help dialog box when the user clicks "Help"
        private void btnHelp_Click(object sender, EventArgs e)
        {
            //initiates a new instance of help that does not interfere with operations in the application
            frmHelp frmHelpDialog = new frmHelp();
            frmHelpDialog.Show();
        }


        //Starts the quiz process
        private void btnStart_Click(object sender, EventArgs e)
        {
            //Initiates the quiz form when the user clicks "Start"
            frmQuiz frmNewQuiz = new frmQuiz();
            frmNewQuiz.Show();
        }
    }
}
