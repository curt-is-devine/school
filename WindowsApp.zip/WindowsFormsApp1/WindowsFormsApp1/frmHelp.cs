﻿/**********************************************************
* frmHelp.cs
*
* A simple "Help" box for the user
*
* Author: Curtis Devine
* Date Created: 12/1/17
* Last Modified by: Curtis Devine
* Date Last Modified: 12/8/17
* Assignment: Final Project
* Part of: eatMe
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frmHelp : Form
    {
        public frmHelp()
        {
            InitializeComponent();
        }

        //My only action for this form. When the user clicks "Close" the form closes
        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
