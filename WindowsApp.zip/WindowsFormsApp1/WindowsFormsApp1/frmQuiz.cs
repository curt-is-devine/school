﻿/**********************************************************
* frmQuiz.cs
*
* The quiz aspect of the Eat Me! application. Gets user preferences and sends them to the result form
*
* Author: Curtis Devine
* Date Created: 12/1/17
* Last Modified by: Curtis Devine
* Date Last Modified: 12/8/17
* Assignment: Final Project
* Part of: Eat Me!
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frmQuiz : Form
    {


        //arrays of strings to hold each question/answer set
        string[] restrictions = { "First of all: Any diet preferences?", "Vegetarian", "Vegan", "Pescatarian", "Gluten Free", "Peanut Allergy", "None" };
        string[] spices = { "What type of flavoring do you want?", "Spicy", "Sour", "Sweet", "Bitter", "Mild", "Savory" };
        string[] nationalities = { "Any particular country's food sounding good?", "American", "Mexican", "Chinese", "French", "Indian", "Italian" };
        string[] intensive = { "Finally, How labor intensive are you feeling up to?", "Not at all", "Only Slightly", "A Little", "Some", "A Bit", "Bring it On" };


        //An integer array to store references to the user's answers in the next form
        int[,] answers = new int[4, 6];


        //An index to keep track of which question the user is on
        int index = 0;

        public frmQuiz()
        {
            InitializeComponent();
        }


        //Closes the form when the user clicks the "Quit" Button
        private void btnQuit_Click(object sender, EventArgs e)
        {
            Close();
        }


        //when the form loads:
        private void frmQuiz_Load(object sender, EventArgs e)
        {
            //Set the picture box image to be the image relating to dietary preferences
            picFood.Image = Properties.Resources.diet;
            picFood.BackgroundImageLayout = ImageLayout.Zoom;

            //Sets text attributes of the question label and the check box options based off of the first question array above
            lblQuestion.Text = restrictions[0];
            chkOpt1.Text = restrictions[1];
            chkOpt2.Text = restrictions[2];
            chkOpt3.Text = restrictions[3];
            chkOpt4.Text = restrictions[4];
            chkOpt5.Text = restrictions[5];
            chkOpt6.Text = restrictions[6];
        }

        //When the user clicks "Next"
        private void btnNext_Click(object sender, EventArgs e)
        {
            //The next chunk of code is repetitive but keeps the same pattern:
            //If checkbox _ is checked: record that check in the appropriate index of the answers array for that question and then uncheck it
            //for the next form
            if (chkOpt1.Checked)
            {
                answers[index, 0] = 1;
                chkOpt1.Checked = false;
                //Otherwise record that it was not checked
            } else answers[index, 1] = 0;

            if (chkOpt2.Checked)
            {
                answers[index, 1] = 1;
                chkOpt2.Checked = false;
            } else answers[index, 1] = 0;

            if (chkOpt3.Checked)
            {
                answers[index, 2] = 1;
                chkOpt3.Checked = false;
            } else answers[index, 2] = 0;

            if (chkOpt4.Checked)
            {
                answers[index, 3] = 1;
                chkOpt4.Checked = false;
            } else answers[index, 3] = 0;

            if (chkOpt5.Checked)
            {
                answers[index, 4] = 1;
                chkOpt5.Checked = false;
            } else answers[index, 4] = 0;

            if (chkOpt6.Checked)
            {
                answers[index, 5] = 1;
                chkOpt6.Checked = false;
            } else answers[index, 5] = 0; 

                //Looking at the index value:
                switch (index) { 
                //for the first few indexes (up to 2), load the information for the next question, listed above
                case 0:
                    //increment the index by one
                    index++;
                    //set the new picture
                    picFood.Image = Properties.Resources.spices;
                    picFood.BackgroundImageLayout = ImageLayout.Zoom;
                    //set all text values
                    lblQuestion.Text = spices[0];
                    chkOpt1.Text = spices[1];
                    chkOpt2.Text = spices[2];
                    chkOpt3.Text = spices[3];
                    chkOpt4.Text = spices[4];
                    chkOpt5.Text = spices[5];
                    chkOpt6.Text = spices[6];
                    //break out of the switch loop
                    break;
                case 1:
                    index++;
                    picFood.Image = Properties.Resources.international;
                    picFood.BackgroundImageLayout = ImageLayout.Zoom;
                    lblQuestion.Text = nationalities[0];
                    chkOpt1.Text = nationalities[1];
                    chkOpt2.Text = nationalities[2];
                    chkOpt3.Text = nationalities[3];
                    chkOpt4.Text = nationalities[4];
                    chkOpt5.Text = nationalities[5];
                    chkOpt6.Text = nationalities[6];
                    break;
                case 2:
                    index++;
                    picFood.Image = Properties.Resources.intensive;
                    picFood.BackgroundImageLayout = ImageLayout.Zoom;
                    lblQuestion.Text = intensive[0];
                    chkOpt1.Text = intensive[1];
                    chkOpt2.Text = intensive[2];
                    chkOpt3.Text = intensive[3];
                    chkOpt4.Text = intensive[4];
                    chkOpt5.Text = intensive[5];
                    chkOpt6.Text = intensive[6];
                    break;
                //If this is the final question, then hide the form, initiate a new result form while passing the answers from this quiz, and close this form
                case 3:
                    this.Hide();
                    frmResult frmNewResult = new frmResult(answers);
                    frmNewResult.Show();
                    this.Close();
                    break;
            }
        }

        //if the "previous" button is clicked:
        private void btnPrev_Click(object sender, EventArgs e)
        {
            //set every checkbox to be unchecked
            foreach (CheckBox box in this.Controls.OfType<CheckBox>())
            {
                box.Checked = false;
            }

            //as above, look at the current index
            switch (index)
            {
                //if this is the first question, do nothing
                case 0:
                    break;
                //If this is any other question, decrement the question index
                case 1:
                    index = index - 1;
                    //upload the previous picture
                    picFood.Image = Properties.Resources.diet;
                    picFood.BackgroundImageLayout = ImageLayout.Zoom;
                    //and upload the previous text attributes
                    lblQuestion.Text = restrictions[0];
                    chkOpt1.Text = restrictions[1];
                    chkOpt2.Text = restrictions[2];
                    chkOpt3.Text = restrictions[3];
                    chkOpt4.Text = restrictions[4];
                    chkOpt5.Text = restrictions[5];
                    chkOpt6.Text = restrictions[6];
                    //break out of the loop
                    break;
                case 2:
                    index = index - 1;
                    picFood.Image = Properties.Resources.spices;
                    picFood.BackgroundImageLayout = ImageLayout.Zoom;
                    lblQuestion.Text = spices[0];
                    chkOpt1.Text = spices[1];
                    chkOpt2.Text = spices[2];
                    chkOpt3.Text = spices[3];
                    chkOpt4.Text = spices[4];
                    chkOpt5.Text = spices[5];
                    chkOpt6.Text = spices[6];
                    break;
                case 3:
                    index = index - 1;
                    picFood.Image = Properties.Resources.international;
                    picFood.BackgroundImageLayout = ImageLayout.Zoom;
                    lblQuestion.Text = nationalities[0];
                    chkOpt1.Text = nationalities[1];
                    chkOpt2.Text = nationalities[2];
                    chkOpt3.Text = nationalities[3];
                    chkOpt4.Text = nationalities[4];
                    chkOpt5.Text = nationalities[5];
                    chkOpt6.Text = nationalities[6];
                    break;
                case 4:
                    index = index - 1;
                    picFood.Image = Properties.Resources.intensive;
                    picFood.BackgroundImageLayout = ImageLayout.Zoom;
                    lblQuestion.Text = intensive[0];
                    chkOpt1.Text = intensive[1];
                    chkOpt2.Text = intensive[2];
                    chkOpt3.Text = intensive[3];
                    chkOpt4.Text = intensive[4];
                    chkOpt5.Text = intensive[5];
                    chkOpt6.Text = intensive[6];
                    break;
            }
        }
    }
}
