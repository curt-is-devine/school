﻿/**********************************************************
* frmResult.cs
*
* The result form of the Eat Me! application. Says what to eat and gives a picture
*
* Author: Curtis Devine
* Date Created: 12/8/2017
* Last Modified by: Curtis Devine
* Date Last Modified: 12/8/17
* Assignment: Final Project
* Part of: Eat Me!
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frmResult : Form
    {
        //initiate the variable that will be used to store the answers from the quiz form
        int[,] results = new int[4, 6];

        //When the form loads, take the answers form the quiz and set it to the global answers variable
        public frmResult(int[,] quizResults)
        {
            InitializeComponent();
            results = quizResults;
        }

        

        //When the form loads:
        private void frmResult_Load(object sender, EventArgs e)
        {
            //Initiate lists for each predefined food type. Each of the first four indexes describe which check box should be clicked for this food
            //to be considered. the final index is to store an accumulation of how many of these preferences matched the user's input. Do this for
            //10 food items
            int[] spaghetti = { 4, 4, 5, 1, 0 };
            int[] curry = { 3, 0, 3, 2, 0 };
            int[] hamburger = { 4, 5, 0, 2, 0 };
            int[] escargot = { 2, 4, 3, 3, 0 };
            int[] salad = { 0, 4, 5, 2, 0 };
            int[] vegLasagna = { 1, 5, 5, 5, 0 };
            int[] iceCream = { 0, 2, 0, 0, 0 };
            int[] rhubarbPie = { 1, 3, 0, 3, 0 };
            int[] greekYogurt = { 0, 1, 0, 0, 0 };
            int[] loMein = { 4, 4, 2, 4, 0 };

            //a multi-dimensional array of integers to store each food and its values
            int[][] foods = { spaghetti, curry, hamburger, escargot, salad, vegLasagna, iceCream, rhubarbPie, greekYogurt, loMein };
            //an ordering of the most popular food items. I only use the first in my code since I ran out of time on the project,
            //Otherwise I would have included the 2 second best options. Initiated them all to be the same food item, which was not the best idea
            int[] order = { 0, 0, 0};

            //A complicated for loop to process how the answers match the food items. For every question:
            for (int question = 0; question < 4; question++) 
            {
                //And for each answer for the question:
                for (int answer = 0; answer < 5; answer++)
                {
                    //if the check box was clicked for that answer:
                    if (results[question, answer] == 1)
                    {
                        //Then for each food:
                        for (int food = 0; food < 10; food++) 
                        {
                            //if the food's value for the question matches the user's answer:
                            if (foods[food][question] == answer) 
                            {
                                //Add one to the food's counting index
                                foods[food][4] += foods[food][4] + 1;
                            }
                        }
                    } 
                }
            }


            //Helper functions that were supposed to keep track of numbers to be rewritten in order to keep track of the order of best options
            //int oneBefore;
            //int twoBefore;


            //A loop to determine which food best matches the user's preferences. For each food item:
            for (int food = 1; food < 10; food++)
            {
                //and for each element of the "best options":
                for (int res = 0; res < 3; res++)
                {
                    //if the counting index of the food item is greater than a food stored in the best options array's
                    if (foods[food][4] > foods[order[res]][4])
                    {
                        //save the previous "best" value
                        //oneBefore = order[res];

                        //replace the best value by the new best value
                        order[res] = food;

                        //and replace subsequent "best values" as appropriate
                        //for (int index = res + 1; res < 3; index++)
                        //{
                        //    twoBefore = oneBefore;
                        //   oneBefore = order[index];
                        //    order[index] = twoBefore;
                        //}
                        //break out of the "best options" array, since we found replaced as high as we could
                        break;
                    }
                }
            }   

            //depending on the first index of the best preferences:
            switch(order[0])
            {
                //replace the image and txt with the food item that the array represents and break out of the switch loop
                case 0:
                    picRes.Image = Properties.Resources.spaghetti;
                    lblFood.Text = "Spaghetti!";
                    break;
                case 1:
                    picRes.Image = Properties.Resources.curry;
                    lblFood.Text = "Curry!";
                    break;
                case 2:
                    picRes.Image = Properties.Resources.hamburger;
                    lblFood.Text = "Hamburger!";
                    break;
                case 3:
                    picRes.Image = Properties.Resources.escargot;
                    lblFood.Text = "Escargot!";
                    break;
               case 4:
                    picRes.Image = Properties.Resources.salad;
                    lblFood.Text = "Salad!";
                    break;
                case 5:
                    picRes.Image = Properties.Resources.vegLasagna;
                    lblFood.Text = "Veggie Lasagna!";
                    break;
                case 6:
                    picRes.Image = Properties.Resources.iceCream;
                    lblFood.Text = "Ice Cream!";
                    break;
                case 7:
                    picRes.Image = Properties.Resources.rhubarbPie;
                    lblFood.Text = "Rhubarb Pie!";
                    break;
                case 8:
                    picRes.Image = Properties.Resources.greekyogurt;
                    lblFood.Text = "Greek Yogurt!";
                    break;
                case 9:
                    picRes.Image = Properties.Resources.lomein;
                    lblFood.Text = "Lo Mein!";
                    break;
            }
        }


        //if the user clicks the "Retake" button:
        private void btnRetake_Click(object sender, EventArgs e)
        {
            //hide this form, start a new quiz, and close this form
            this.Hide();
            frmQuiz frmNewQuiz = new frmQuiz();
            frmNewQuiz.Show();
            this.Close();
        }

        //If the user clicks the "home" button, 
        private void btnHome_Click(object sender, EventArgs e)
        {
            //close this form
            this.Close();
        }
    }
}
