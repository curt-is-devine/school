Property Changes:
	1) Icon is a Jason Voorhees icon since I was working on this near Halloween time
	2) Changed border color to violet since it is less harsh on the eyes
	3) Resize buttons are labeled "v" and "V" to better distinguish shrinking/growing
	   of the form. This is more intuitive to me than v and ^, which I constantly mixed up during
	   class trials.
	4) Changed the background color of the form to be a dim orange, also in the Halloween spirit (I really like Halloween),
	5) Changed all text properties to be "Papyrus" font
	6) Changed the X and Y coordinates to be bold
	7) Added a background picture to the picture box. It disappears when the user sleects a new picture to use.
	8) Got rid of "Minimize" and "Maximize" buttons on the form toolbar
	9) Changed the cursor to a weird type of arrow that seemed kind of spooky
	10) Made the "Quit" button a "CancelButton" in the Form properties.
	11) Changed Background colors of the buttons to "White"
	12) Set the tab indices of the buttons to make logical sense
	
Additions to what has been done in class:

	Redrawing the border was the biggest challenge in this assignment. And I feel slightly offended
	that it took me so long to think of such a simple solution. I realized that constantly redrawing the 
	border would probably be the easiest way to accomplish this task, which was easy enough when considering 
	the resizing buttons. All I had to do in those cases was add the drawing code we already had to the event handlers 
	and it would be done. The challenge was when the user manually resized the form, in which case my 
	strategy would fail. It wasnt until I was working on adding the X and Y labels that I realized that
	there was a resizing event handler for the form. So I tried it and it worked beautifully. Incorporating
	that into my code and erasing the additional redrawings I incorporated into the button events for resizing,
	I made a helper function that drew the border in order to clean up the code and I simply added that to the 
	events for drawing the border and for resizing the form. This was such a simple solution for what I was
	making to be a complicated problem.
	
	The resizing of the picture I think I did right, but I am not sure. In hindsight I should have asked about
	this in class, but I do have the image set such that the whole image is displayed in the proper ratio of
	height to width. However, there is always some "blank" space either above and below or to the left and right
	of the image depending on the image's proportions. However, since the assignment instructions simply
	said to display the image in its entirety and in the proper ratios, I think I accomplished was was asked
	(I know this goes against programming for the user and not for my own ease and I feel really sorry for it). 
	This resizing was done by simply setting the "SizeMode" property of the picture box to "Zoom".
	
	As for the additional changes I made to the project. I made more than 10 just for solidarity. I had made 
	changes to text in buttons which I felt clarified the intent and changed the border color of the image and 
	I wasn't sure that that would be good enough for the final submission so I made more in order to make up for it.