﻿/*A590Buffet
*
* A page that gives the user a dialog box with many different resizing and image options to perform
*
* Author: Curtis Devine
* Date Created: 10-23-2017
* Last Modified by: Curtis Devine
* Date Last Modified: 10-23-2017
* Assignment: Assignment 1, A590Buffet 
* Part of: Assignment 1: A590Buffet
*/

/*Property Changes:
*	1) Icon is a Jason Voorhees icon since I was working on this near Halloween time
*	2) Changed border color to violet since it is less harsh on the eyes
*	3) Resize buttons are labeled "v" and "V" to better distinguish shrinking/growing
*      of the form. This is more intuitive to me than v and ^, which I constantly mixed up during
*
*      class trials.
*	5) Changed all text properties to be "Papyrus" font
*	6) Changed the X and Y coordinates to be bold
*	7) Added a background picture to the picture box.It disappears when the user sleects a new picture to use.
*	8) Got rid of "Minimize" and "Maximize" buttons on the form toolbar
*	9) Changed the cursor to a weird type of arrow that seemed kind of spooky
*	10) Made the "Quit" button a "CancelButton" in the Form properties.
*	11) Changed Background colors of the buttons to "White"
*	12) Set the tab indices of the buttons to make logical sense
*	4: was supposed to change background color, but I could not get it to work with the border drawing.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A590Buffet
{
    public partial class frmBuffetMain : Form
    {
        public frmBuffetMain()
        {
            InitializeComponent();
        }

        //a global boolean to tell if a border has been drawn on the picture or not. If it has, 
        //the helper function drawBorder (listed below) is called when the form is resized
        bool borderPresent = false;

        //a helper function to draw a border (used my knowledge of C to guess that this was allowed
        private void drawBorder()
        {

            /*used the code in class to draw borders within this function instead of spontaneously 
            *throughout the code. If the boolean above is set to true (i.e. a border has been drawn,
            *then this function will draw a new border when the form is resized. Otherwise nothing happens
            */
            if (borderPresent)
            {
                //sets a graphics object and initiailizaes with "null"
                Graphics objDrawBorder = null;

                //Establishes that a new graphic will be made and clears the previous graphic
                objDrawBorder = CreateGraphics();
                objDrawBorder.Clear(SystemColors.Control);

                //Draws a blue rectangle around the image window by dleineating the upper, lower, left, and right limits of the rectangle
                objDrawBorder.DrawRectangle(Pens.Violet,
                    picShowPicture.Left - 1, picShowPicture.Top - 1,
                    picShowPicture.Width + 1, picShowPicture.Height + 1);

                //Finalizes the border design 
                objDrawBorder.Dispose();
            }

        }


        //an event handler for when the form loads. It simply sets the labels to display nothing.
        private void frmBuffetMain_Load(object sender, EventArgs e)
        {
            //sets the X and Y coordinate labels respectively to be invisible to the user
            lblX.Text = "";
            lblY.Text = "";
        }

        //and event handler to allow users to select a picture when clicking the "Select Picture" button
        private void btnSelectPicture_Click(object sender, EventArgs e)
        {
            //Display the dialog box
            if (ofdSelectPicture.ShowDialog() == DialogResult.OK)
            {

                //picture box loads user selected picture
                picShowPicture.Image = Image.FromFile(ofdSelectPicture.FileName);

                //Hides the background image that is displayed by default
                picShowPicture.BackgroundImage = null;
                //Display the file's location with respect to the project in the filesystem as the title of the form
                Text = string.Concat("A590 buffet(" + ofdSelectPicture.FileName + ")");
            }
        }

        //an event handler that closes the application when the "Quit" button is clicked
        private void btnQuit_Click(object sender, EventArgs e)
        {
            //Properly exit the program
            Close();
        }


        //and event handler to enlarge the form when the "V" button is clicked
        private void btnEnlarge_Click(object sender, EventArgs e)
        {            
            //Increases the size of the image when this button is clicked
            Width = Width + 20;
            Height = Height + 20;

        }

        //Same as above, but shrinks the form if "v" is clicked
        private void btnShrink_Click(object sender, EventArgs e)
        {
            //decreases size of the window when the button is clicked
            Width = Width - 20;
            Height = Height - 20;
        }

        //Draws the initial border when the "Draw Border" button is clicked
        private void btnDrawBorder_Click(object sender, EventArgs e)
        {
            //sets the global booloean to true so that the drawBorder function 
            //works whenever it is called in the future
            borderPresent = true;

            //draws the first border for the image
            drawBorder();
            
        }

        /*an event handler for whenever the form size changes. this handler will 
        *call the drawBorder function and draw a new border around the image if
        *appropriate.
        */
        private void frmBuffetMain_SizeChanged(object sender, EventArgs e)
        {
            drawBorder();
        }

        //An event handler for when themouse moves over the picture box. It lists
        //the coordinates of the mouse at all times
        private void picShowPicture_MouseMove(object sender, MouseEventArgs e)
        {
            //Labels the X and Y coordinates respectively in the X and Y labels
            lblX.Text = "X: " + e.X.ToString();
            lblY.Text = "Y: " + e.Y.ToString();
        }

        //An event handler that clears the X and Y labels when the mouse leaves the form
        private void picShowPicture_MouseLeave(object sender, EventArgs e)
        {
            //Sets the text value of the labels to empty
            lblX.Text = "";
            lblY.Text = "";
        }        
    }
}
