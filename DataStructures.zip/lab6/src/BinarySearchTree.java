/**
 * Starter for lab6.
 *
 * In this lab you will implement BinarySearchTree.kthSmallest(),
 * which takes a positive integer k and returns the k-th smallest
 * element in the BST. As usual, we assume that all keys in the BST
 * are unique. This function must run in O(h) time, where h is the
 * height of the tree.
 *
 * Follow the following steps to implement kthSmallest().
 *
 * (5) Define kthSmallest. Write a suitable javadoc style comment.
 *     Implement the following algorithm:
 *   
 *       To find the k-th smallest value in the tree rooted at p:
 *         If the kth-smallest must be in the left subtree
 *            then recur on the left subtree
 *            else if the kth-smallest must be in p
 *                    then return p's data field
 *                    else recur on the right subtree
 *
 * @author <Curtis Devine and Brendan Moore>
 */

interface Tree<E extends Comparable<E>> {
  void insert(E key);
  default boolean remove(E key) {
    throw new UnsupportedOperationException();
  }
  boolean contains(E key);
  int size();
  default boolean isEmpty() {
    return size() == 0;
  }
  default int height() {
    throw new UnsupportedOperationException();
  }
  default E kthSmallest(int n) {throw new UnsupportedOperationException();}
}

public class BinarySearchTree<E extends Comparable<E>> 
  implements Tree<E> {

  class Node {
    E data;
    Node left, right, parent;
    int n;

    Node(E key) {
      this(key, null, null, null);
    }

    Node (E key, Node parent) {
      this(key, null, null, parent);
    }
    Node(E data, Node left, Node right, Node parent) {
      this.data = data;
      this.left = left;
      this.right = right;
      this.n = 1;
      this.parent = parent;
    }

    boolean isLeaf() {
      return left == null && right == null;
    }
  }

  Node root;
  int n;

  /**
   * Inserts the key into this tree. Runs in O(h) time, where h is
   * the height of the tree.
   */

  public void insert(E key) {
    n++;
    root = insertHelper(key, root, null);
  }

  private Node insertHelper(E key, Node p, Node parent) {

    if (p == null) 
      return new Node(key, null, null, parent);
    if (key.compareTo(p.data) < 0)
      p.left = insertHelper(key, p.left, p);
    else 
      // if keys are unique, it must be the case that key > p.data
      // otherwise, we will put duplicate data on the right anyways
      p.right = insertHelper(key, p.right, p);

    if (p.right != null && p.left != null)
      p.n = 1 + p.left.n + p.right.n;
    else if (p.right == null)
      p.n = 1 + p.left.n;
    else if (p.left == null)
      p.n = 1 + p.right.n;

    return p;
  }

  /**
   * Returns true iff key is in this tree. Runs in O(h) time, where h is
   * the height of the tree.
   */

  public boolean contains(E key) {
    return containsHelper(key, root);
  }

  private boolean containsHelper(E key, Node p) {
    if (p == null)
      return false;
    if (key.equals(p.data))
      return true;
    if (key.compareTo(p.data) < 0)
      return containsHelper(key, p.left);
    return containsHelper(key, p.right);
  }

  /**
   * Returns the number of keys in this tree.
   */

  public int size() {
    return n;
  }

  /**
   * Attempts to remove an occurrence of x in this tree.
   * Returns true iff the remove succeeds.
   */

  public boolean remove(E x) {
    boolean ans = removeHelper(x, root, null);
    if (ans)
      n--;
    return ans;
  }

  public boolean removeHelper(E x, Node p, Node parent) {
    if (p == null)
      return false;
    if (contains(x))
      p.n--;
    if (p.data.equals(x)) {
      if (p.isLeaf()) {
        if (parent == null)
          root = null;
        else if (parent.left == p)
          parent.left = null;
        else
          parent.right = null;
      }
      else if (p.left == null) {
        if (parent == null)
          root = p.right;
        else if (parent.left == p)
          parent.left = p.right;
        else 
          parent.right = p.right;
      }
      else if (p.right == null) {
        if (parent == null)
          root = p.left;
        else if (parent.left == p)
          parent.left = p.left;
        else 
          parent.right = p.left;
      }
      else {
        Node pred = largestNode(p.left);
        p.data = pred.data;
        removeHelper(pred.data, p.left, p);
      }
      return true;
    }
    if (x.compareTo(p.data) < 0) 
      return removeHelper(x, p.left, p);
    return removeHelper(x, p.right, p);
  }

  /**
   * Returns a pointer to the node containing the largest data
   * value in this non-empty BST.
   */

  Node largestNode(Node p) {
    if (p.right == null)
      return p;
    return largestNode(p.right);    
  }


  public E kthSmallest(int n) {

    assert n < this.n && n > 0;

    return helperSmallest(n, root);
  }

  public E helperSmallest(int n, Node p) {
    if (p.left == null)
      return helperSmallest(n - 1, p.right);
    while (p.left != null && n <= p.left.n){
        p = p.left;
    }
    if (n == p.left.n + 1)
      return p.data;
    else
      return helperSmallest(n - 1 - p.left.n, p.right);
  }

  /**
   * Returns a pretty text version of this tree.
   */

  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("(");
    toStringHelper(root, sb);
    return sb.toString().trim() + ")";
  }

  private void toStringHelper(Node p, StringBuilder sb) {
    if (p != null) {
      toStringHelper(p.left, sb);
      sb.append(p.data).append(" ");
      toStringHelper(p.right, sb);
    }
  }
}




