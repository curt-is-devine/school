/**
 * hw3: Problem 5 starter code.
 */

public class SelfAdjustingList<T> extends DoublyLinkedList<T> {

  public SelfAdjustingList() {
    n = 0;
    modCount = 0;
    head = new Node(null);
    head.next = head;
    head.prev = head;
  }

  public void add(T x) {
    n++;
    modCount++;
    Node newSecond = head.next;
    Node added = new Node(x, head, newSecond);
    head.next = added;
    newSecond.prev = added;
  }

  public T find(int i) {

    if (i >= n || i < 0)
        throw new IndexOutOfBoundsException();
    modCount++;
    Node curr = head.next;
    while ( i > 0 ) {
      i--;
      curr = curr.next;
    }

    //removed the node from the list and connected the elements that already exist
    Node before = curr.prev;
    Node after = curr.next;
    before.next = after;
    after.prev = before;


    curr.next = head.next;
    head.next.prev = curr;

    curr.prev = head;
    head.next = curr;


    return curr.data;

  }
  
  /**
   * Simple testing to get you started. Add more tests of your own!
   */

  public static void main(String... args) {
    SelfAdjustingList<Integer> xs = new SelfAdjustingList<>();
    for (int x = 1; x <= 10; x++)
      xs.add(x);
    for (int i = 0; i < xs.size(); i++)
      assert 10 - i == xs.get(i);
    for (int i = 0; i < xs.size(); i++) {
      int x = xs.get(i);
      assert x == xs.find(i);
    }
    for (int i = 0; i < xs.size(); i++) {
      int x = xs.find(i);
      assert x == xs.get(0);
    }
    System.out.println("All tests passed...");
  }
}
