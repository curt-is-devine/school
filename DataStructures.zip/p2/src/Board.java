/**
 * A Board represents the current state of the game. Boards know their
 * dimension, the collection of tiles that are inside the current flooded
 * region, and those tiles that are on the outside.
 * 
 * @author Curtis Devine
 */

public class Board {
  List<Tile> inside, outside;
  private int size;

  /**
   * Constructs a square game board of the given size, initializes the list of 
   * inside tiles to include just the tile in the upper left corner, and puts 
   * all the other tiles in the outside list.
   */

  public Board(int size) {
    // A tile is either inside or outside the current flooded region.
    inside = new DoublyLinkedList<>();
    outside = new DoublyLinkedList<>();
    this.size = size;
    for (int y = 0; y < size; y++)
      for (int x = 0; x < size; x++) {
        Coord coord = new Coord(x, y);
        outside.add(new Tile(coord));
      }
    // Move the corner tile into the flooded region.
    Tile corner = get(Coord.ORIGIN);
    outside.remove(corner);
    inside.add(corner);
  }
  
  /**
   * Returns the tile at the specified coordinate on this board.
   *
   * @throws CoordOutOfBoundsException if no such tile is found at the
   * given coordinate.
   */

  public Tile get(Coord coord) {
	for (Tile t : inside) if (coord.equals(t.getCoord())) return t;
	for (Tile t : outside) if (coord.equals(t.getCoord())) return t;
    throw new CoordOutOfBoundsException();
  }
  
  /**
   * Returns the size of this board.
   */

  public int getSize() {
    return size;
  }
  
  /**
   * Returns true iff all tiles on the board have the same color.
   * Must run in O(1) time.
   */

  public boolean fullyFlooded() {
    return outside.isEmpty();
  }
  
  /**
   * Updates this board by changing the color of the current flood region 
   * and extending its reach. Make this as efficient as possible.
   */

  public void flood(WaterColor color) {
    List<Coord> neighs = new DoublyLinkedList<>();
    for (Tile t : inside) {
        t.setColor(color);
        Coord tileCoord = t.getCoord();
        for(Coord c: tileCoord.neighbors(size))
            if(color.equals(get(c).getColor()) && !neighs.contains(c) && outside.contains(get(c)))
                neighs.add(c);
    }

    for (Coord c : neighs) {
        helpFlood(c, color, neighs);
    }
  }

  public void helpFlood(Coord c, WaterColor color, List<Coord> neighs) {
    Tile t = get(c);
    outside.remove(t);
    inside.add(t);

    for (Coord newC : c.neighbors(size))
      if (color.equals(get(newC).getColor()) && !neighs.contains(newC) && outside.contains(get(newC)))
        helpFlood(newC, color, neighs);

  }
  
  /**
   * Returns the "best" WaterColor for the next move. 
   * 
   * Modify this comment to describe your algorithm. Possible strategies to
   * pursue include maximizing the number of tiles in the current flooded
   * region, or maximizing the size of the perimeter of the current flooded
   * region.
   *
   * My algorithm simply looks for the color that fills the most tiles in one flood.
   * While this may be the most "basic" strategy, it is definitely the best strategy
   * when considering that the point of the game is to fill the board. And while other
   * strategies may boil down to increasing depth into the "outside" colors or increasing
   * perimeter, these strategies are also accounted for in looking for the color that
   * best fills the board in any one turn.
   *
   * My algorithm follows similar logic of the flood method, where a collection of
   * neighboring tiles to the flooded tiles is assembled, then parsed through color by color
   * to find how many neighbors of that color exist. Once counts have been established, I use
   * the Math.max function to find the color that occurs the most and return that color to the
   * user.
   *
   * The logic is clear in the suggest method, the helper methods: counter and counter helper
   * fulfill some of the more difficult aspects of the strategy. Both methods take the flood color,
   * a water color, and the neighbor elements array. counter compares the colors first and returns 0 if
   * they match, since no neighbors will exist of the already flooded color. Then it reduces the neighbors
   * list to a list of tiles that match the searched color. From here, the method funnels through the
   * list, calling on the helper to recursively search neighboring tiles to each tile in the color list
   * that match the same color and add them to the list. once the recursion is complete, the counter
   * method returns the length of the color list.
   *
   */

  public WaterColor suggest() {
    WaterColor cornerColor = inside.get(0).getColor();
    List<Coord> neighs = new DoublyLinkedList<>();
    for (Tile t : inside) {
        Coord tileCoord = t.getCoord();
        for(Coord c: tileCoord.neighbors(size))
            if(outside.contains(get(c)) && !neighs.contains(c))
                neighs.add(c);
    }

    int redCount = counter(cornerColor, WaterColor.RED, neighs);
    int cyanCount = counter(cornerColor, WaterColor.CYAN, neighs);
    int blueCount = counter(cornerColor, WaterColor.BLUE, neighs);
    int pinkCount = counter(cornerColor, WaterColor.PINK, neighs);
    int yellowCount = counter(cornerColor, WaterColor.YELLOW, neighs);

    int pyMax = Math.max(pinkCount, yellowCount);
    int bpyMax = Math.max(blueCount, pyMax);
    if (redCount >= Math.max(cyanCount, bpyMax))
        return WaterColor.RED;
    else if (cyanCount >= Math.max(redCount, bpyMax))
        return WaterColor.CYAN;
    else if (blueCount >= Math.max(redCount, Math.max(cyanCount, pyMax)))
        return WaterColor.BLUE;
    else if (pinkCount >= Math.max(redCount, Math.max(blueCount, Math.max(cyanCount, yellowCount))))
        return WaterColor.PINK;
    else return WaterColor.YELLOW;

  }

  public int counter(WaterColor floodColor, WaterColor compareColor, List<Coord> neighbors) {
      if (floodColor.equals(compareColor)) return 0;

      List<Coord> colorList = new DoublyLinkedList<>();
      for (Coord c : neighbors) {
          if (compareColor.equals(get(c).getColor()))
              colorList.add(c);
      }


      for (Coord c : colorList)
          counterHelper(c, compareColor, colorList);

      return colorList.size();
  }

  public void counterHelper(Coord c, WaterColor color, List<Coord> colorList) {

      for(Coord neighC: c.neighbors(size))
          if(color.equals(get(neighC).getColor()) && !colorList.contains(neighC)) {
              colorList.add(neighC);
              counterHelper(neighC, color, colorList);
          }
  }
  
  /**
   * Returns a string representation of this board. Tiles are given as their
   * color names, with those inside the flooded region written in uppercase.
   */

  public String toString() {
    StringBuilder ans = new StringBuilder();
    for (int y = 0; y < size; y++) {
      for (int x = 0; x < size; x++) {
        Tile curr = get(new Coord(x, y));
        WaterColor color = curr.getColor();
        ans.append(String.format("%-8s",
            inside.contains(curr) ?
            color.toString().toUpperCase() :
            color));
      }
      ans.append("\n");
    }
    return ans.toString();
  }
  
  /**
   * Simple testing.
   */
  public static void main(String... args) {
    // Print out boards of size 1, 2, ..., 5
    int n = 5;
    for (int size = 1; size <= n; size++) {
      Board someBoard = new Board(size);
      System.out.println(someBoard);
    }

    Board b = new Board(3);
    b.get(new Coord(0, 0)).setColor(WaterColor.BLUE);
    b.get(new Coord(1, 0)).setColor(WaterColor.CYAN);
    b.get(new Coord(0, 1)).setColor(WaterColor.YELLOW);
    b.get(new Coord(1, 1)).setColor(WaterColor.CYAN);
    b.get(new Coord(0, 2)).setColor(WaterColor.YELLOW);
    b.get(new Coord(1, 2)).setColor(WaterColor.YELLOW);
    b.get(new Coord(2, 0)).setColor(WaterColor.CYAN);
    b.get(new Coord(2, 1)).setColor(WaterColor.YELLOW);
    b.get(new Coord(2, 2)).setColor(WaterColor.YELLOW);
    System.out.println(b);

    System.out.println(b.suggest());
    b.flood(b.suggest());
  }
}

class CoordOutOfBoundsException extends IndexOutOfBoundsException {

}






