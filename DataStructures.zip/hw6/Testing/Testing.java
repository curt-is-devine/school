import static org.junit.Assert.*;
import org.junit.Test;

public class Testing {

  @Test
  public void smallHuff() {
    HuffmanTree ht;
    ht = new HuffmanTree("");
    assertNull(ht.root);
    assertEquals(0, height(ht));
    ht = new HuffmanTree("a");
    assertTrue(1 == ht.root.value);
    assertTrue('a' == ht.root.key);
    assertEquals(1, height(ht));
    ht = new HuffmanTree("aaaaaaaaaaaaaaaaaaa");
    assertEquals(1, height(ht));
    ht = new HuffmanTree("ab");
    assertTrue(2 == ht.root.value);
    assertEquals(2, height(ht));
    ht = new HuffmanTree("abc");
    assertTrue(3 == ht.root.value);
    assertTrue(1 == ht.root.left.value);
    assertTrue(2 == ht.root.right.value);
    assertEquals(3, height(ht));
    ht = new HuffmanTree("aaaabbc");
    assertEquals(3, height(ht));
    assertTrue(7 == ht.root.value);
    assertTrue(3 == ht.root.left.value);
    assertTrue(4 == ht.root.right.value);
    assertTrue(1 == ht.root.left.left.value);
    assertTrue(2 == ht.root.left.right.value);
    assertTrue('a' == ht.root.right.key);
    assertTrue('c' == ht.root.left.left.key);
    assertTrue('b' == ht.root.left.right.key);
  }

  @Test
  public void encodeHuff() {
    HuffmanTree ht = new HuffmanTree("aaaabbc");
    assertEquals(3, height(ht));
    assertEquals("1", ht.encodeChar('a'));
    assertEquals("01", ht.encodeChar('b'));
    assertEquals("00", ht.encodeChar('c'));
  }

  @Test
  public void decodeHuff() {
    HuffmanTree ht = new HuffmanTree("aaaabbc");
    assertEquals(3, height(ht));
    StringBuilder sb;
    sb = new StringBuilder("1010010001");
    assertEquals(10, sb.length());
    assertEquals('a', ht.decodeChar(sb));
    assertEquals(9, sb.length());
    assertEquals('b', ht.decodeChar(sb));
    assertEquals(7, sb.length());
    assertEquals('c', ht.decodeChar(sb));
    assertEquals(5, sb.length());
    assertEquals('a', ht.decodeChar(sb));
    assertEquals(4, sb.length());
    assertEquals('c', ht.decodeChar(sb));
    assertEquals(2, sb.length());
    assertEquals('b', ht.decodeChar(sb));
    assertEquals(0, sb.length());
  }

  @Test
  public void catInHat() {
    String message = "THE CAT IN THE HAT";
    HuffmanTree ht = new HuffmanTree(message);
    assertEquals(6, height(ht));
    assertEquals(18, ht.root.value);
    assertNotNull(ht.root.left);
    assertNotNull(ht.root.right);
    assertNotNull(ht.root.left.left);
    assertNotNull(ht.root.left.right);
    assertNotNull(ht.root.right.left);
    assertNotNull(ht.root.right.right);
    assertEquals(18, ht.root.left.value + ht.root.right.value);

    String code;
    if (ht.root.left.left.key == 'T') 
      code = "00";
    else if (ht.root.left.right.key == 'T') 
      code = "01";
    else if (ht.root.right.left.key == 'T') 
      code = "10";
    else
      code = "11";
    StringBuilder sb;
    sb = new StringBuilder(code);
    assertEquals('T', ht.decodeChar(sb));
    assertEquals(0, sb.length());
    sb.append(code).append("101110001010101");
    assertEquals('T', ht.decodeChar(sb));
    assertEquals(15, sb.length());

    if (ht.root.left.left.key == ' ') 
      code = "00";
    else if (ht.root.left.right.key == ' ') 
      code = "01";
    else if (ht.root.right.left.key == ' ') 
      code = "10";
    else
      code = "11";
    sb = new StringBuilder(code);
    assertEquals(' ', ht.decodeChar(sb));
    assertEquals(0, sb.length());
    sb.append(code).append("0001010101");
    assertEquals(' ', ht.decodeChar(sb));
    assertEquals(10, sb.length());

    String alpha = "THECAIN ";
    for (int i = 0; i < alpha.length(); i++) {
      char ch = alpha.charAt(i);
      code = ht.encodeChar(ch);
      sb = new StringBuilder(code);
      assertEquals(ch, ht.decodeChar(sb));
      assertEquals(0, sb.length());
      sb.append(code).append("00000");
      assertEquals(ch, ht.decodeChar(sb));
      assertEquals(5, sb.length());
    }
  }

  @Test
  public void theLorax() {
    String message = "I AM THE LORAX. " +
      "I SPEAK FOR THE TREES. " +
      "I SPEAK FOR THE TREES FOR THE TREES HAVE NO TONGUES.";
    HuffmanTree ht = new HuffmanTree(message);
    //assertEquals(7, height(ht));
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < message.length(); i++)
      sb.append(ht.encodeChar(message.charAt(i)));
    StringBuilder decodedMessage = new StringBuilder();
    while (sb.length() > 0) {
      char ch = ht.decodeChar(sb);
      decodedMessage.append(ch);
    }
    assertEquals(message, decodedMessage.toString());
  }

  public static int height(HuffmanTree ht) {
    return heightHelper(ht.root);
  }

  private static int heightHelper(HuffmanTree.Node p) {
    if (p == null)
      return 0;
    return 1 + Math.max(heightHelper(p.left), heightHelper(p.right));
  }

}