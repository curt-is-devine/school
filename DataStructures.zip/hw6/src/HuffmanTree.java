import java.util.Comparator;

/**
 * A HuffmanTree represents a variable-length code such that the
 * shorter the bit pattern associated with a character, the more
 * frequently that character appears in the text to be encoded.
 */
public class HuffmanTree {

  class Node {
    char key;
    int value;
    Node left, right;

    public Node(int value, char key) {
      this(value, key, null, null);
    }

    public Node(int value, Node left, Node right) {
      this(value, '\0', left, right);
    }

    public Node(int value, char key, Node left, Node right) {
      this.key = key;
      this.value = value;
      this.left = left;
      this.right = right;
    }

    public boolean isLeaf() {
      return left == null && right == null;
    }

    public String toString() {
      return String.format("%s:%f", key, value);
    }
  }

  Node root;
  Map<Character, Integer> freqs = new HashMap<>();
  Map<Character, String> codeBook = new HashMap<>();

  /**
   * Creates a HuffmanTree from the given frequencies of letters in
   * the alphabet using the algorithm described in lecture. Starts by
   * initializing the instance variable freqs to hold the frequencies
   * of all letters in the message.
   */
  public HuffmanTree(String message) {

    DoublyLinkedList<Character> charList = new DoublyLinkedList<>();

    //initialize frequencies
    freqs = new HashMap<>(52);
    int len = message.length();
    for (int i = 0; i < len; i++) {
      char index = message.charAt(i);
      Integer count = freqs.get(index);
      if (count != null)
        freqs.put(index, count + 1);
      else {
        charList.add(index);
        freqs.put(index, 1);
      }
    }

    //create priority queue of Nodes by increasing frequencies;
    Comparator<Node> comp;
    comp = (x, y) -> x.value - y.value;
    PriorityQueue<Node> pq = new PriorityQueue<>(comp);

   for (Character c : charList)
     pq.offer(new Node(freqs.get(c), c));

    while (pq.n > 1) {
      Node smallest = pq.poll();
      Node second = pq.poll();
      pq.offer(new Node(smallest.value + second.value, smallest, second));
    }

    root = pq.peek();
  }

  /**
   * Returns the character associated with leading bits of sb and also
   * removes the prefix corresponding to the decoded character from
   * sb.
   *
   * @throws HuffmanDecodeException if the prefix of sb cannot be
   *                                decoded as a character in the alphabet. In this case, there is no
   *                                change to sb.
   */
  public char decodeChar(StringBuilder sb) {
    int len = sb.length(), i = 0;
    Node n = root;
    while (i <= len) {
      if (n.isLeaf()) {
        sb.delete(0, i);
        return n.key;
      }
      n = sb.charAt(i) == '0' ? n.left : n.right;
      i++;
    }
    throw new HuffmanDecodeException(sb.toString());
  }

  /**
   * Returns the bit string associated with the given character. Must
   * search the tree for a leaf containing the character. Every left
   * turn corresponds to a 0 in the code. Every right turn corresponds
   * to a 1.
   * Memoize this function using the instance variable codeBook. That
   * is, if the code is already in the book, then return the stored
   * code. Otherwise, compute the code and store it in the book before
   * returning.
   *
   * @throws HuffmanEncodeException if the character does not appear
   *                                in the tree.
   */
  public String encodeChar(char ch) {
    String s = codeBook.get(ch);
    if (s == null) {
        s = encodeHelper(ch, root);
        if (s == null)
            throw new HuffmanEncodeException(ch);
        codeBook.put(ch, s);
    }
    return s;
  }

  public String encodeHelper(char ch, Node n) {

    if (n.isLeaf())
      return n.key == ch ? "" : null;

    String s = encodeHelper(ch, n.left);
    if (s == null) {
      s = encodeHelper(ch, n.right);
      return s == null ? null : "1" + s;
    }

    return '0' + s;
  }
}



class HuffmanEncodeException extends RuntimeException { 
  public HuffmanEncodeException(char ch) {
    super(String.format("%s is not in the alphabet", ch));
  }
}

class HuffmanDecodeException extends RuntimeException { 

  public HuffmanDecodeException(String bits) {
    super(String.format("%s cannot be decoded", bits));
  }
}
