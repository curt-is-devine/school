import java.util.Iterator;

public class HashMap<K, V> implements Map<K, V> {
  AList<K, V>[] table;
  int n;


  /*
   * Creates a new hashmap table of array size 3
   */
  public HashMap() {
    this(3);
  }

  /*
   * Creates a new hashmap table of array size n
   */
  public HashMap(int n) {
    table = newTable(n);
    for (int i = 0; i < table.length; i++)
      table[i] = new AList<>();
  }


  /*
   * 1) Hashes input key to find the index of this HashMap that should hold this key association
   * 2) Attempts to find the association with the key value
   *    a) If the association does not exist, this key-value association is added to the front
   *       of the AList at that index of the HashMap
   *    b) If it is found, the associated value with that key is overwritten, and the old value
   *       is returned
   */
  public V put(K key, V value) {
    int i = hash(key);
    Assoc<K, V> a = table[i].get(key);
    if (a == null) {
      n++;
      table[i].addFront(new Assoc<K, V>(key, value));
      return null;
    }
    V ans = a.value;
    a.value = value;
    return ans;
  }

  /*
   * Gets the associated value of the key from the AList at its hashed index
   * of the table array and returns the value if it exists. Otherwise returns
   * null
   */
  public V get(K key) {
    Assoc<K, V> a = table[hash(key)].get(key);
    if (a == null)
      return null;
    return a.value;
  }

  /**
   * Returns the number of key-value associations in the HashMap. Implemented by
   * adding a global counter to the class to keep track of the hash map size
   */
  public int size() {
    return n;
  }

  /**
   * Removes the key-value association that matches the input key from the table
   * if it exists. If the association does not exist, returns null and does
   * nothing
   */
  public V remove(K key) {
    int i = hash(key);
    Assoc<K, V> a = table[i].get(key);
    if (a == null)
      return null;
    n--;
    table[i].remove(0);
    return a.value;
  }

  /*
   * Finds the hash index for a given key in the table
   */
  public int hash(K key) {
    return Math.abs(key.hashCode()) % table.length;
  }

  /**
   * Technical workaround for creating a generic array.
   */
  @SafeVarargs 
  private static <K, V> AList<K, V>[] newTable(int length,
                                               AList<K, V>... table) {
    return java.util.Arrays.copyOf(table, length);
  }
}