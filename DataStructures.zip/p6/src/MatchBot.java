/**
 * Design and run a variety of experiments in MatchBot.main() and then
 * summarize your results below in this comment. Which of the three algorithms
 * works best on the Twitter dataset? What about other kinds of data?
 * Hypothesize about the reasons why one algorithm is better suited to a
 * particular type of data. Support your conclusions with evidence.
 *
 * ==========================================================================
 * REPORT:
 * Within the Twitter dataset, the Boyer-Moore algorithm far surpasses the others
 * when it comes to pattern matching. Testing all scenarios where the pattern is
 * short, where it is long, where it is non-existant, the Boyer Moore algorithm
 * is by far the most efficient algorithm comparison wise, with approximately a
 * 500-1000% increase in efficiency when compared to the naive approach based on
 * my test cases.
 *
 * Surprisingly, the KMP
 * algorithm usually performs much less effectively than the naive matching
 * algorithm in all of my tests. However, when running the provided tests, if
 * Boyer-Moore was not the best, KMP was usually better than the naive approach.
 * My first thought was that the alphabet was very small in the test cases, which
 * would make sense why KMP performed better. However, looking at the generative
 * code for these patterns/text strings, it appears that a relatively large alphabet
 * is being used, so that is not the case. My current thought is that this discrepancy
 * has to do with the natural frequencies of certain letters in english text. For example,
 * letters like t and s occur more frequently than x or z. When considering truly random
 * text, it makes sense these frequencies should all be roughly the same, so the chances
 * that a mismatch occur are relatively smaller in the naive approach, but chances of
 * failure over multiple iterations of the flink should not occur very often based on the
 * likelyhood of repetition within the text. Thus, in a convoluted way, it makes sense that
 * KMP would work better in the random cases, but not so much in the Twitter case.
 */

public class MatchBot extends TwitterBot {

  /**
   * Constructs a MatchBot to operate on the last numTweets of the given user.
   */
  public MatchBot(String user, int numTweets) {
    super(user, numTweets);
  }
  
  /**
   * Employs the KMP string matching algorithm to add all tweets containing
   * the given pattern to the provided list. Returns the total number of 
   * character comparisons performed.
   */
  public int searchTweetsKMP(String pattern, List<String> ans) {

    int[] flink = new int[pattern.length() + 1];
    pattern = pattern.toLowerCase();


    int comparisons = StringMatch.buildKMP(pattern, flink);;
    for (String tweet : tweets) {
      String tweetCopy = tweet.toLowerCase();
      Assoc<Integer, Integer> res = StringMatch.runKMP(pattern, tweetCopy, flink);
      comparisons += res.value;
      if (res.key != -1)
        ans.add(tweet);
    }
    return comparisons;
  }
  
  /**
   * Employs the naive string matching algorithm to add all tweets containing
   * the given pattern to the provided list. Returns the total number of 
   * character comparisons performed.
   */
  public int searchTweetsNaive(String pattern, List<String> ans) {

    pattern = pattern.toLowerCase();
    int comparisons = 0;
    for (String tweet : tweets) {
      String tweetCopy = tweet.toLowerCase();
      Assoc<Integer, Integer> res = StringMatch.matchNaive(pattern, tweetCopy);
      comparisons += res.value;
      if (res.key != -1)
        ans.add(tweet);
    }
    return comparisons;
  }

  /**
   * Employs the reduced Boyer Moore algorithm to add all tweets containing
   * the given pattern to the provided list. Returns the total number of
   * character comparisons performed.
   */
  public int searchTweetsBoyerMoore(String pattern, List<String> ans) {

    int[] delta1 = new int[128];
    pattern = pattern.toLowerCase();
    StringMatch.buildDelta1(pattern, delta1);

    int comparisons = 0;
    for (String tweet : tweets) {
      String tweetCopy = tweet.toLowerCase();
      Assoc<Integer, Integer> res = StringMatch.runBoyerMoore(pattern, tweetCopy, delta1);
      comparisons += res.value;
      if (res.key != -1)
        ans.add(tweet);
    }
    return comparisons;
  }


  public static void main(String... args) {
    String handle = "realDonaldTrump", pattern = "mexico";
    MatchBot bot = new MatchBot(handle, 2000);
   
    // search all tweets for the pattern
    List<String> ansNaive = new DoublyLinkedList<>();
    int compsNaive = bot.searchTweetsNaive(pattern, ansNaive); 
    List<String> ansKMP = new DoublyLinkedList<>();
    int compsKMP = bot.searchTweetsKMP(pattern, ansKMP);
    List<String> ansBM = new DoublyLinkedList<>();
    int compsBM = bot.searchTweetsBoyerMoore(pattern, ansKMP);
    System.out.println("realdonaldtrump: 'Mexico': naive comps = " + compsNaive +
        ", KMP comps = " + compsKMP +
    ", Boyer Moore comps = " + compsBM);

    pattern = "Taylor Swift";
    ansNaive = new DoublyLinkedList<>();
    compsNaive = bot.searchTweetsNaive(pattern, ansNaive);
    ansKMP = new DoublyLinkedList<>();
    compsKMP = bot.searchTweetsKMP(pattern, ansKMP);
    ansBM = new DoublyLinkedList<>();
    compsBM = bot.searchTweetsBoyerMoore(pattern, ansKMP);
    System.out.println("realdonaldtrump: 'Taylor Swift': naive comps = " + compsNaive +
            ", KMP comps = " + compsKMP +
            ", Boyer Moore comps = " + compsBM);


    handle = "meganamram";
    pattern = "Trump finally became president";
    bot = new MatchBot(handle, 2000);

    // search all tweets for the pattern
    ansNaive = new DoublyLinkedList<>();
    compsNaive = bot.searchTweetsNaive(pattern, ansNaive);
    ansKMP = new DoublyLinkedList<>();
    compsKMP = bot.searchTweetsKMP(pattern, ansKMP);
    ansBM = new DoublyLinkedList<>();
    compsBM = bot.searchTweetsBoyerMoore(pattern, ansKMP);
    System.out.println("meganamram: 'Trump finally became president': naive comps = " + compsNaive +
            ", KMP comps = " + compsKMP +
            ", Boyer Moore comps = " + compsBM);

    pattern = "to";
    // search all tweets for the pattern
    ansNaive = new DoublyLinkedList<>();
    compsNaive = bot.searchTweetsNaive(pattern, ansNaive);
    ansKMP = new DoublyLinkedList<>();
    compsKMP = bot.searchTweetsKMP(pattern, ansKMP);
    ansBM = new DoublyLinkedList<>();
    compsBM = bot.searchTweetsBoyerMoore(pattern, ansKMP);
    System.out.println("meganamram: 'today was the day donald Trump finally became president': naive comps = " + compsNaive +
            ", KMP comps = " + compsKMP +
            ", Boyer Moore comps = " + compsBM);
    /*
    for (int i = 0; i < ansKMP.size(); i++) {
      String tweet = ansKMP.get(i);
      assert tweet.equals(ansNaive.get(i));
      System.out.println(i++ + ". " + tweet);
      System.out.println(pattern + " appears at index " +
              tweet.toLowerCase().indexOf(pattern.toLowerCase()));
    }
    */
  }
}
