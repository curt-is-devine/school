import static org.junit.Assert.*;
import java.util.Random;
import org.junit.Test;

/**
 * TODO: Write your own tests!!!
 */

public class Testing {
  private static Random random = new Random();
  private static String alphabet = "abcdefghijklmnopqrstuvwxyz0123456789";

  @Test
  public void testRank() {
    PopularityBot billyBot = new PopularityBot();
    for (String lyric : new String[]{
        "We didn't start the fire",
        "It was always burning",
        "Since the world's been turning",
        "We didn't start the fire",
        "No we didn't light it",
        "But we tried to fight it",
    })
        billyBot.tweets.add(lyric);
    billyBot.split();
    billyBot.rank();
    assertEquals(3, billyBot.vocab.size());
    assertEquals("didnt", billyBot.vocab.get(0).key);
    assertEquals("fire", billyBot.vocab.get(1).key);
    assertEquals("start", billyBot.vocab.get(2).key);
    assertEquals(Integer.valueOf(3), billyBot.vocab.get(0).value);
    assertEquals(Integer.valueOf(2), billyBot.vocab.get(1).value);
    assertEquals(Integer.valueOf(2), billyBot.vocab.get(2).value);
  }

  @Test
  public void testNaive() {
    String[] pats = new String[] {
        "AAAA",
        "BAAA",
        "AAAB",
        "AAAC",
        "ABAB",
    };
    String text = "AAAAAAAAABAAAAAAAAAB";
    assertEquals(20, text.length());
    Integer[][] results = new Integer[][] {
        { 0, 4 },
        { 9, 13 },
        { 6, 28 },
        { -1, 62 },
        { -1, 35 },
    };
    int i = 0;
    for (String pat : pats) {
      Assoc<Integer, Integer> res = StringMatch.matchNaive(pat, text);
      assertEquals(results[i][0], res.key);
      assertEquals(results[i][1], res.value);
      i++;
    }
  }

  @Test 
  public void smallGods() { // Shout out to Terry Pratchett.
    String[] pats = new String[] {
        "",
        "A",
        "AB",
        "AA",
        "AAAA",
        "BAAA",
        "AAAB",
        "AAAC",
        "ABAB",
        "ABCD",
        "ABBA",
        "AABC",
        "ABAAB",
        "AABAACAABABA",
        "ABRACADABRA",
    };
    int[][] flinks = new int[][] {
        { -1 },
        { -1, 0 },
        { -1, 0, 0 },
        { -1, 0, 1 },
        { -1, 0, 1, 2, 3 },
        { -1, 0, 0, 0, 0 },
        { -1, 0, 1, 2, 0 },
        { -1, 0, 1, 2, 0 },
        { -1, 0, 0, 1, 2 },
        { -1, 0, 0, 0, 0 },
        { -1, 0, 0, 0, 1 },
        { -1, 0, 1, 0, 0 },
        { -1, 0, 0, 1, 1, 2 },
        { -1, 0, 1, 0, 1, 2, 0, 1, 2, 3, 4, 0, 1 },
        { -1, 0, 0, 0, 1, 0, 1, 0, 1, 2, 3, 4 },
    };
    int[] comps = new int[] { 0, 0, 1, 1, 3, 3, 5, 5, 3, 3, 3, 4, 5, 16, 12 };
    int i = 0;
    for (String pat : pats) {
      int[] flink = new int[pat.length() + 1];
      assertEquals(comps[i], StringMatch.buildKMP(pat, flink));
      assertArrayEquals(flinks[i], flink);
      i++;
    }
  }

  @Test
  public void lec13bKMP() {
    String[] pats = new String[] {
        "AABC",
        "ABCDE",
        "AABAACAABABA",
        "ABRACADABRA",
    };
    int[][] flinks = new int[][] {
        { -1, 0, 1, 0, 0 },
        { -1, 0, 0, 0, 0, 0 },
        { -1, 0, 1, 0, 1, 2, 0, 1, 2, 3, 4, 0, 1 },
        { -1, 0, 0, 0, 1, 0, 1, 0, 1, 2, 3, 4 },
    };
    String text = "AAAAAABRACADABAAAAAAAAAAAAAAAAAAAAAAA" +
        "BCAAAAAAAAAAABAABAAAAAAAAAAAAAAA";
    Integer[][] results = new Integer[][]{
        { 35, 68 },
        { -1, 128 },
        { -1, 123 },
        { -1, 126 },
    };
    int i = 0;
    for (String pat : pats) {
      Assoc<Integer, Integer> res = StringMatch.runKMP(pat, text, flinks[i]);
      assertEquals(results[i][0], res.key);
      assertEquals(results[i][1], res.value);
      i++;
    }
  }

  @Test
  public void testFlinks() {
    String pattern = "AABAACAABABA";
    int m = pattern.length();
    int[] flink = new int[m + 1];
    StringMatch.buildKMP(pattern, flink);
    // System.out.println(java.util.Arrays.toString(flink));
    assertArrayEquals(flink, new int[] {
        -1, 0, 1, 0, 1, 2, 0, 1, 2, 3, 4, 0, 1
    });
    assertTrue(verifyMachine(pattern, flink));
  }

  @Test
  public void delta1s() {

    int[] delta1s = new int[128];
    StringMatch.buildDelta1("ABBEBB", delta1s);
    assertEquals(5, delta1s[(int) 'A']);
    assertEquals(0, delta1s[(int) 'B']);
    assertEquals(6, delta1s[(int) 'C']);
    assertEquals(6, delta1s[(int) 'D']);
    assertEquals(2, delta1s[(int) 'E']);

    delta1s = new int[128];
    StringMatch.buildDelta1("BDCDDCD", delta1s);
    assertEquals(7, delta1s[(int) 'A']);
    assertEquals(6, delta1s[(int) 'B']);
    assertEquals(1, delta1s[(int) 'C']);
    assertEquals(0, delta1s[(int) 'D']);
    assertEquals(7, delta1s[(int) 'E']);

    delta1s = new int[128];
    StringMatch.buildDelta1("ABBCBB", delta1s);
    assertEquals(5, delta1s[(int) 'A']);
    assertEquals(0, delta1s[(int) 'B']);
    assertEquals(2, delta1s[(int) 'C']);
    assertEquals(6, delta1s[(int) 'D']);
    assertEquals(6, delta1s[(int) 'E']);
  }

  @Test
  public void BoyerMoore() {

    String text = "00000000000000000000";
    String[] patterns = new String[] {
            "00000",
            "11111",
            "00011",
            "10100",
            "10000"
    };
    int i = 0;
    Integer[][] results = new Integer[][] {
            {0, 5},
            {-1, 4},
            {-1, 8},
            {-1, 48},
            {-1, 80}
    };
    for (String s : patterns) {
      int[] delta1 = new int[126];
      StringMatch.buildDelta1(patterns[i], delta1);
      Assoc<Integer, Integer> res = StringMatch.runBoyerMoore(patterns[i], text, delta1);
      assertEquals(results[i][0], res.key);
      assertEquals(results[i][1], res.value);
      i++;
    }
  }

  /**
   * The following tests may be useful when writing your REPORT.
   * Remove the // in front of @Test to run.
   */

  @Test
  public void testEmpty() {
    System.out.println("testEmpty");
    match("", "");
    match("", "ab");
    System.out.println();
  }

  @Test
  public void testOneChar() {
    System.out.println("testOneChar");
    match("a", "a");
    match("a", "b");
    System.out.println();
  }

  @Test
  public void testRepeat() {
    System.out.println("testRepeat");
    match("aaa", "aaaaa");
    match("aaa", "abaaba");
    match("abab", "abacababc");
    match("abab", "babacaba");
    System.out.println();
  }

  @Test
  public void testPartialRepeat() {
    System.out.println("testPartialRepeat");
    match("aaacaaaaac", "aaacacaacaaacaaaacaaaaac");
    match("ababcababdabababcababdaba", "ababcababdabababcababdaba");
    System.out.println();
  }

  @Test
  public void testRandomly() {
    System.out.println("testRandomly");
    for (int i = 0; i < 100; i++) {
      String pattern = makeRandomPattern();
      for (int j = 0; j < 100; j++) {
        String text = makeRandomText(pattern);
        match(pattern, text);
      }
    }
    System.out.println();
  }

  /* Helper functions */

  private static String makeRandomPattern() {
    StringBuilder sb = new StringBuilder();
    int steps = random.nextInt(10) + 1;
    for (int i = 0; i < steps; i++) {
      if (sb.length() == 0 || random.nextBoolean()) {  // Add literal
        int len = random.nextInt(5) + 1;
        for (int j = 0; j < len; j++)
          sb.append(alphabet.charAt(random.nextInt(alphabet.length())));
      } 
      else {  // Repeat prefix
        int len = random.nextInt(sb.length()) + 1;
        int reps = random.nextInt(3) + 1;
        if (sb.length() + len * reps > 1000)
          break;
        for (int j = 0; j < reps; j++)
          sb.append(sb.substring(0, len));
      }
    }
    return sb.toString();
  }

  private static String makeRandomText(String pattern) {
    StringBuilder sb = new StringBuilder();
    int steps = random.nextInt(100);
    for (int i = 0; i < steps && sb.length() < 10000; i++) {
      if (random.nextDouble() < 0.7) {  // Add prefix of pattern
        int len = random.nextInt(pattern.length()) + 1;
        sb.append(pattern.substring(0, len));
      } 
      else {  // Add literal
        int len = random.nextInt(30) + 1;
        for (int j = 0; j < len; j++)
          sb.append(alphabet.charAt(random.nextInt(alphabet.length())));
      }
    }
    return sb.toString();
  }

  private static void match(String pattern, String text) {
    // run all three algorithms and test for correctness
    Assoc<Integer, Integer> ansNaive = StringMatch.matchNaive(pattern, text);
    Integer expected = text.indexOf(pattern);
    assertEquals(expected, ansNaive.key);
    Assoc<Integer, Integer> ansKMP = StringMatch.matchKMP(pattern, text);
    assertEquals(expected, ansKMP.key);
    Assoc<Integer, Integer> ansBoyerMoore =
        StringMatch.matchBoyerMoore(pattern, text);
    assertEquals(expected, ansBoyerMoore.key);
    System.out.println(String.format("%5d %5d %5d : %s",
        ansNaive.value, ansKMP.value, ansBoyerMoore.value,
        (ansNaive.value < ansKMP.value &&
            ansNaive.value < ansBoyerMoore.value) ?
            "Naive" :
              (ansKMP.value < ansNaive.value &&
                  ansKMP.value < ansBoyerMoore.value) ?
                  "KMP" : "Boyer-Moore"));
  }

  //--------- For Debugging ---------------
  public static boolean verifyMachine(String pattern, int[] flink) {
    int m = pattern.length();
    if (flink.length != pattern.length() + 1) 
      return false;  // bad length
    if (flink[0] != -1)
      return false;
    for (int i = 2; i < m; i++) {
      if (flink[i] < 0 || flink[i] >= i) 
        return false;  // link out of range
      // Search for the nearest state whose label is a suffix of i's label
      String iLabel = pattern.substring(0, i);  
      int j = i - 1;
      while (j >= 0 && !iLabel.endsWith(pattern.substring(0, j))) 
        j--;
      if (flink[i] != j) 
        return false;  // fails to the wrong state
    }
    return true;
  }
}
