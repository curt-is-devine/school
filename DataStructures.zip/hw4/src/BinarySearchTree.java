/**
 * hw4
 * @author Curtis Devine
 */

interface Tree<E extends Comparable<E>> {
  void insert(E key);
  default boolean remove(E key) {
    throw new UnsupportedOperationException();
  }
  boolean contains(E key);
  int size();
  default boolean isEmpty() {
    return size() == 0;
  }
  default int height() {
    throw new UnsupportedOperationException();
  }
}

public class BinarySearchTree<E extends Comparable<E>> 
  implements Tree<E> {

  class Node {
    E data;
    Node left, right;

    Node(E key) {
      this(key, null, null);
    }

    Node(E data, Node left, Node right) {
      this.data = data;
      this.left = left;
      this.right = right;
    }

    boolean isLeaf() {
      return left == null && right == null;
    }
  }

  Node root;
  int n;
  //Variable for if we need to remove the in order predecessor 'l' or successor 'r'
  char move = 'l';

  /**
   * Inserts the key into this tree. Runs in O(h) time, where h is
   * the height of the tree.
   */

  public void insert(E key) {
    n++;
    root = insertHelper(key, root);
  }

  private Node insertHelper(E key, Node p) {
    if (p == null) 
      return new Node(key);
    if (key.compareTo(p.data) < 0)
      p.left = insertHelper(key, p.left);
    else 
      // if keys are unique, it must be the case that key > p.data
      p.right = insertHelper(key, p.right);
    return p;
  }

  /**
   * Returns true iff key is in this tree. Runs in O(h) time, where h is
   * the height of the tree.
   */

  public boolean contains(E key) {
    return containsHelper(key, root);
  }

  private boolean containsHelper(E key, Node p) {
    if (p == null)
      return false;
    if (key.equals(p.data))
      return true;
    if (key.compareTo(p.data) < 0)
      return containsHelper(key, p.left);
    return containsHelper(key, p.right);
  }

  /**
   * Returns the number of keys in this tree.
   */

  public int size() {
    return n;
  }

  /**
   * Attempts to remove an occurrence of x in this tree.
   * Returns true iff the remove succeeds.
   *
   * Alternates between using the inorder predecessor and
   * the inorder successor as the replacement data when
   * removing nodes with two children.
   *
   * I believe that this strategy should lead to more balanced trees,
   * but not  in the works case. In the case of straight trees for example,
   * the nodes could be all along the right tree, and once a node is removed,
   * this code will only connect the removed nodes, so unless the tree is non-linear
   * for the most part when it is created, then the tree may not end up balanced.
   */
  public boolean remove(E x) {
    boolean ans = removeHelper(x, root, null);
    if (ans)
      n--;
    return ans;
  }

  public boolean removeHelper(E x, Node p, Node parent) {
    if (p == null)
      return false;
    if (p.data.equals(x)) {
      if (p.isLeaf()) {
        if (parent == null)
          root = null;
        else if (parent.left == p)
          parent.left = null;
        else
          parent.right = null;
      }
      else if (p.left == null) {
        if (parent == null)
          root = p.right;
        else if (parent.left == p)
          parent.left = p.right;
        else 
          parent.right = p.right;
      }
      else if (p.right == null) {
        if (parent == null)
          root = p.left;
        else if (parent.left == p)
          parent.left = p.left;
        else 
          parent.right = p.left;
      }
      else if (move == 'l'){
        Node pred = largestNode(p.left);
        p.data = pred.data;
        removeHelper(pred.data, p.left, p);
        move = 'r';
      }
      else {
        Node pred = smallestNode(p.right);
        p.data = pred.data;
        removeHelper(pred.data, p.right, p);
        move = 'l';
      }
      return true;
    }
    if (x.compareTo(p.data) < 0) 
      return removeHelper(x, p.left, p);
    return removeHelper(x, p.right, p);
  }


  /**
   * Attempts to verify that a BST is indeed a BST
   * Returns true iff the tree is a BST.
   *
   * Makes sure lower and upper bounds given by smallestNode
   * and largestNode are upheld, and used appropriate locations
   * within the tree with upper/lower bounds determined by parent
   * node and branching.
   *
   * This function is indeed O(n) since each node is only visited once,
   * with boolean operations and returning done in O(1) time occuring n times
   */
  public boolean verify() {
    if (root == null)
      return true;
    return verifyHelper(root, smallestNode(root), largestNode(root));
  }

  public boolean verifyHelper(Node p, Node small, Node large) {

    if (p == null)
      return true;

    if (p.data.compareTo(small.data) < 0 || p.data.compareTo(large.data) > 0)
      return false;

    return verifyHelper(p.left, small, p) && verifyHelper(p.right, p, large);
  }


  /**
   * Returns a pointer to the node containing the largest data
   * value in this non-empty BST.
   */

  Node largestNode(Node p) {

    assert p != null;

    while (p.right != null)
      p = p.right;

    return p;
  }

  /*
   * Returns a pointer to the node containing the smallest key
   * value in the non-empty BST
   */
  Node smallestNode(Node p) {
    assert p != null;

    while (p.left != null)
      p = p.left;

    return p;
  }

  /**
   * Returns a pretty text version of this tree.
   */

  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("(");
    toStringHelper(root, sb);
    return sb.toString().trim() + ")";
  }

  private void toStringHelper(Node p, StringBuilder sb) {
    if (p != null) {
      toStringHelper(p.left, sb);
      sb.append(p.data).append(" ");
      toStringHelper(p.right, sb);
    }
  }
}


