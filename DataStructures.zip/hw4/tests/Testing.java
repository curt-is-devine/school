import static org.junit.Assert.*;
import org.junit.Test;

public class Testing {

  @Test
  public void BSTlargestNode() {
    Integer[] a = new Integer[] { 3, 9, 7, 2, 1, 5, 6, 4, 8 };
    BinarySearchTree<Integer> bst = new BinarySearchTree<>();
    assertEquals(0, bst.n);
    assertNull(bst.root);
    assert bst.root == null;
    for (Integer key : a)
      bst.insert(key);
    assertEquals(a.length, bst.n);
    Integer expected = 9;
    assertEquals(expected, bst.largestNode(bst.root).data);
    expected = 2;
    assertEquals(expected, bst.largestNode(bst.root.left).data);
    expected = 9;
    assertEquals(expected, bst.largestNode(bst.root.right).data);
    expected = 8;
    assertEquals(expected, bst.largestNode(bst.root.right.left).data);
  }

  @Test
  public void BSTsmallestNode() {
    Integer[] a = new Integer[] { 3, 9, 7, 2, 1, 5, 6, 4, 8 };
    BinarySearchTree<Integer> bst = new BinarySearchTree<>();
    assertEquals(0, bst.n);
    assertNull(bst.root);
    for (Integer key : a)
      bst.insert(key);
    assertEquals(a.length, bst.n);
    Integer expected = 1;
    assertEquals(expected, bst.smallestNode(bst.root).data);
    assertEquals(expected, bst.smallestNode(bst.root.left).data);
    expected = 4;
    assertEquals(expected, bst.smallestNode(bst.root.right).data);
    expected = 8;
    assertEquals(expected, bst.smallestNode(bst.root.right.left.right).data);
    expected = 6;
    assertEquals(expected, bst.smallestNode(bst.root.right.left.left.right).data);
  }

  @Test
  public void BSTverify() {
    BinarySearchTree<Integer> bst = new BinarySearchTree<>();
    assertTrue(bst.verify());
    Integer[] a = new Integer[] { 30, 90, 70, 20, 10, 50, 60, 40, 80 };
    for (Integer key : a)
      bst.insert(key);
    assertTrue(bst.verify());
    bst.root.data = 100;
    assertFalse(bst.verify());
    bst.root.data = 30;
    bst.root.right.data = 55;
    assertFalse(bst.verify());
    bst.root.right.data = 90;
    bst.root.left.data = 5;
    assertFalse(bst.verify());

    BinarySearchTree<String> pets = new BinarySearchTree<>();
    for (String key : new String[] { "dog", "rat", "bat", "cat", "cow", "pig", })
      pets.insert(key);
    assertTrue(pets.verify());
    pets.root.right.data = "emu";
    assertFalse(pets.verify());

    BinarySearchTree<Integer> trial = new BinarySearchTree<>();
    trial.insert(12);
    trial.insert(8);
    trial.insert(10);
    trial.insert(21);
    trial.insert(1);
    trial.insert(61);
    trial.insert(99);
    trial.insert(81);
    trial.insert(100);
    trial.insert(122);
    trial.insert(34);
    trial.insert(15);
    trial.insert(76);
    trial.insert(50);
    trial.insert(22);
    trial.insert(77);
    trial.insert(88);
    trial.insert(86);
    trial.insert(13);
    trial.insert(4);
    trial.insert(9);
    trial.insert(35);
    trial.insert(49);
    assertTrue(trial.verify());







  }

  @Test
  public void BSTremoveSmall() {
    BinarySearchTree<Integer> bst = new BinarySearchTree<>();
    Integer[] a = new Integer[] { 3, 9, 7, 2, 1, 5, 6, 4, 8 };
    for (Integer key : a)
      bst.insert(key);
    // pred
    bst.remove(3);
    Integer expected = 2;
    assertEquals(expected, bst.root.data);
    expected = 9;
    assertEquals(expected, bst.root.right.data);
    bst.remove(9);
    // succ
    bst.remove(7);
    expected = 8;
    assertEquals(expected, bst.root.right.data);
    // pred
    bst.remove(2);
    expected = 1;
    assertEquals(expected, bst.root.data);
    assertNull(bst.root.left);
    // succ
    bst.remove(8);
    bst.remove(5);
    expected = 6;
    assertEquals(expected, bst.root.right.data);
    assertEquals(3, bst.size());
  }

}
