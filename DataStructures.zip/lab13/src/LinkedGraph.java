import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Stack;

/**
 * lab13: starter code.
 * 
 * For our purposes, a graph has no self-loops and no parallel
 * edges. We assume that vertices are labeled with a string and
 * edges are labeled with a non-negative integer.
 *
 * LinkedGraph is a class that implements an undirected graph using
 * adjacency lists, where an adjacency list is an AList. Each
 * association in the AList has the incident vertex as the key and the
 * weight of the edge as the value.
 *
 */

public class LinkedGraph implements Graph {
  String name = "";
  Map<String, AList<String, Integer>> adjLists = new HashMap<>();
  int m; // the number of edges in this graph

  /**
   * Construct the graph with no name and with no nodes and no edges.
   */
  public LinkedGraph() {
  }

  /**
   * Construct the graph with the given name and with no nodes and no
   * edges.
   */
  public LinkedGraph(String name) {
    this.name = name;
  }

  /**
   * Adds the given vertex to this graph. Does nothing if the vertex
   * already exists.
   */
  public void addVertex(String v) {
    if (!hasVertex(v))
      adjLists.put(v, new AList<>()); 
  }

  /** 
   * Adds the edge from u to v of the given weight to this graph. If
   * the edge already exists, then its weight is replaced with the 
   * new weight. The incident vertices are automatically added.
   */
  public void addEdge(String u, String v, int weight) {


    addVertex(u);
    addVertex(v);
    //if (u.equals(v))
      //return;
    AList<String, Integer> uList, vList;
    uList = adjLists.get(u);
    vList = adjLists.get(v);


    if (hasEdge(u, v)) {
      uList.get(0).value = weight;
      vList.get(0).value = weight;
    }
    else {
      uList.add(new Assoc<>(v, weight));
      vList.add(new Assoc<>(u, weight));
      m++;
    }

  }

  /**
   * Returns true iff the vertex v exists.
   */
  public boolean hasVertex(String v) {
    return adjLists.get(v) != null;
  }

  /**
   * Returns true iff the edge between u and v exists.
   */
  public boolean hasEdge(String u, String v) {
    return hasVertex(u) && hasVertex(v) &&
      adjLists.get(u).get(v) != null;
  }

  /**
   * Returns the weight of the edge from u to v, if it exists. 
   * Throws a NoSuchElementException if the edge does not exist.
   */
  public int weight(String u, String v) {
    if (hasEdge(u, v))
      return adjLists.get(u).get(v).value;
    throw new NoSuchElementException();
  }

  /**
   * Returns the name of this graph.
   */
  public String getName() {
    return name;
  }

  /**
   * Returns the number of vertices in this graph.
   */
  public int getNumVertices() {
    return adjLists.size();
  }

  /**
   * Returns the number of edges in this graph.
   */
  public int getNumEdges() {
    return m;
  }

  /**
   * Returns a list of vertices that are adjacent to v in this graph.
   */
  public List<String> adj(String v) {
    List<String> neighbors = new DoublyLinkedList<>();
    if (hasVertex(v)) 
      for (Assoc<String, Integer> edge : adjLists.get(v))
        neighbors.add(edge.key);
    return neighbors;
  }

  /**
   * Returns true iff there is a path (possibly empty) from vertex u to
   * vertex v in this graph.
   */
  public boolean isConnected(String u, String v) {
    if (!hasVertex(u) || !hasVertex(v))
      return false;
    if (hasEdge(u, v) || u.equals(v))
      return true;

    //Populate visited with the initial node, set a current AList add its elements to the visited list
    DoublyLinkedList<String> visited = new DoublyLinkedList<>();
    DoublyLinkedList<String> stack = new DoublyLinkedList<>();
    visited.add(u);
    AList<String, Integer> curr= adjLists.get(u);
    Iterator<Assoc<String, Integer>> adjNodes = curr.iterator();
    while (adjNodes.hasNext())
      stack.add(adjNodes.next().key);

    while (!stack.isEmpty()) {
      int n = stack.size() - 1;
      String currNode = stack.get(n);

      if (currNode.equals(v))
        return true;
      stack.remove(n);
      visited.add(currNode);

      curr= adjLists.get(currNode);
      adjNodes = curr.iterator();
      while (adjNodes.hasNext()) {
        String s = adjNodes.next().key;
        if (visited.contains(s))
          continue;
        stack.add(s);
      }
    }

    return false;
  }

  /*
   *Returns a list of vertices that are exactly two hops away from v
   *(without returning to v)
   */
  public List<String> twoHopsAway(String v) {
    List<String> oneHop = adj(v);
    HashMap<String, String> twoHops = new HashMap<>();
    for (String vertex : oneHop) {
      List<String> two = adj(vertex);
      for (String s : two) {
        if (!s.equals(v))
          twoHops.put(s, "Included");
      }
    }
    Iterator it = twoHops.keys();
    List<String> two = new DoublyLinkedList<>();
    while (it.hasNext())
      two.add((String) it.next());

    return two;
  }

  /**
   * Returns a textual representation of this graph.
   */

  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append(String.format("LinkedGraph %s: n=%d, m=%d",
                            getName(),
                            getNumVertices(),
                            getNumEdges()));
    Iterator<String> it = adjLists.keys();
    while (it.hasNext()) {
      String v = it.next();
      sb.append(String.format("\n  %s: ", v));
      sb.append(adjLists.get(v));
    }
    return sb.toString();
  }
}
