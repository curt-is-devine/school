import java.util.Iterator;

public class Trie {
  class Node {
    String word;   // if word is null, then no data present in this node
    Map<Character, Node> children;  // only non-null children are stored

    /**
     * Creates an empty leaf node.
     */
    Node() {
      this(null);
    }

    /**
     * Creates a leaf node with the given word present.
     */
    Node(String word) {
      this.word = word;
      children = new HashMap<>();
    }

    /**
     * Returns true iff this node is a leaf.
     */
    boolean isLeaf() {
      return children.isEmpty();
    }

    /**
     * Inserts s into the trie assuming that the first i characters
     * in s have led us to this node.
     */
    void insert(String s, int i) {
      if (i == s.length()) {
        if (word == null) {
          n++;
          word = s;
        }
      } else {
        char c = s.charAt(i);
        Node ch = children.get(c);
        if (ch == null) {
          ch = new Node();
          children.put(c, ch);
        }
        ch.insert(s, i + 1);
      }
    }

    /**
     * Returns true iff s is in the trie assuming that the first i
     * characters in s have led us to this node.
     */
    boolean contains(String s, int i) {
      if (i == s.length())
        return word != null ? true : false;

      char c = s.charAt(i);
      Node ch = children.get(c);
      if (ch != null)
        return ch.contains(s, i + 1);

      return false;
    }

    /**
     * Removes s from the trie assuming that the first i character in
     * s have led us to this node. Collapses dead end paths on the way
     * back out of the recursion. Returns true iff this node is now a
     * dead end.
     */
    boolean remove(String s, int i) {
      boolean ans = false;
      if (i == s.length()) {
        if (word != null) {
          n--;
          word = null;
          ans = true;
        }
      } else {
        char index = s.charAt(i);
        Node ch = children.get(index);
        if (ch != null) {
          ans = ch.remove(s, i + 1);
          if (ans && ch.word == null && ch.children.size() == 0)
            children.remove(index);
        }
      }
      return ans;
    }
  }
  Node root = new Node();   // root is never null
  int n = 0;                // number of keys in this trie

  /**
   * Inserts s into this trie. If s was already present in this trie,
   * then nothing happens.
   */
  public void insert(String s) {
    root.insert(s, 0);
  }

  /**
   * Return true iff s is a key in this trie.
   */
  public boolean contains(String s) {
    return root.contains(s, 0);
  }

  /**
   * Removes s from this trie. If s was not in this trie to begin with, 
   * then nothing happens.
   */
  public void remove(String s) {
    root.remove(s, 0);
  }

  /**
   * Returns the number of keys in this trie. Must run in O(1) time.
   */
  public int size() {
    return n;
  }

  /**
   * Returns true iff this trie is empty. Must run in O(1) time.
   */
  public boolean isEmpty() {
    return size() == 0;
  }

  /**
   * Resets this trie to be empty.
   */
  public void clear() {
    n = 0;
    root = new Node();
  }
}

