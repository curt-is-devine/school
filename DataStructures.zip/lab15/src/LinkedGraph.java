/**
 *
 * Your Full Name:Curtis Daniel Devine *
 * Your @iu.edu Username:cudevine
 * Lab Section (circle one):   A    B    C    D    E    F    G
 * Final Start Time (circle one):    10:15am      12:30pm      7:15pm
 *
 **************************************************************************/

import java.util.Iterator;
import java.util.NoSuchElementException;

public class LinkedGraph implements Graph {
  String name = "";
  Map<String, AList<String, Integer>> adjLists = new HashMap<>(10);
  int m; // the number of edges in this graph

  /**
   * Construct the graph with no name and with no nodes and no edges.
   */
  public LinkedGraph() {
  }

  /**
   * Construct the graph with the given name and with no nodes and no
   * edges.
   */
  public LinkedGraph(String name) {
    this.name = name;
  }

  /**
   * Adds the given vertex to this graph. Does nothing if the vertex
   * already exists.
   */
  public void addVertex(String v) {
    if (!hasVertex(v))
      adjLists.put(v, new AList<>()); 
  }

  /** 
   * Adds the edge from u to v of the given weight to this graph. If 
   * the edge already exists, then its weight is replaced with the 
   * new weight. The incident vertices are automatically added.
   */
  public void addEdge(String u, String v, int weight) {
    addVertex(u);
    addVertex(v);
    AList<String, Integer> uList, vList;
    uList = adjLists.get(u);
    vList = adjLists.get(v);
    if (hasEdge(u, v)) {
      uList.get(v).value = weight;
      vList.get(u).value = weight;
    }
    else { 
      uList.addFront(new Assoc<>(v, weight));
      vList.addFront(new Assoc<>(u, weight));
      m++;
    }
  }

  /**
   * Returns true iff the vertex v exists.
   */
  public boolean hasVertex(String v) {
    return adjLists.get(v) != null;
  }

  /**
   * Returns true iff the edge between u and v exists.
   */
  public boolean hasEdge(String u, String v) {
    return hasVertex(u) && hasVertex(v) &&
      adjLists.get(u).get(v) != null;
  }

  /**
   * Returns the weight of the edge from u to v, if it exists. 
   * Throws a NoSuchElementException if the edge does not exist.
   */
  public int weight(String u, String v) {
    if (hasEdge(u, v))
      return adjLists.get(u).get(v).value;
    throw new NoSuchElementException();
  }

  /**
   * Returns the name of this graph.
   */
  public String getName() {
    return name;
  }

  /**
   * Returns the number of vertices in this graph.
   */
  public int getNumVertices() {
    return adjLists.size();
  }

  /**
   * Returns the number of edges in this graph.
   */
  public int getNumEdges() {
    return m;
  }

  /**
   * Returns a list of vertices that are adjacent to v in this graph.
   */
  public List<String> adj(String v) {
    List<String> neighbors = new DoublyLinkedList<>();
    if (hasVertex(v)) 
      for (Assoc<String, Integer> edge : adjLists.get(v))
        neighbors.add(edge.key);
    return neighbors;
  }

  /**
   * Returns true iff there is a path (possibly empty) from vertex u to
   * vertex v in this graph.
   */
  public boolean isConnected(String u, String v) {

    if (!hasVertex(u) || !hasVertex(v))
      return false;
    if (hasEdge(u, v) || u.equals(v))
      return true;

    //Populate visited with the initial node, set a current AList add its elements to the visited list
    DoublyLinkedList<String> visited = new DoublyLinkedList<>();
    DoublyLinkedList<String> stack = new DoublyLinkedList<>();
    visited.add(u);
    AList<String, Integer> curr= adjLists.get(u);
    Iterator<Assoc<String, Integer>> adjNodes = curr.iterator();
    while (adjNodes.hasNext())
      stack.add(adjNodes.next().key);

    while (!stack.isEmpty()) {
      int n = stack.size() - 1;
      String currNode = stack.get(n);

      if (currNode.equals(v))
        return true;
      stack.remove(n);
      visited.add(currNode);

      curr= adjLists.get(currNode);
      adjNodes = curr.iterator();
      while (adjNodes.hasNext()) {
        String s = adjNodes.next().key;
        if (visited.contains(s))
          continue;
        stack.add(s);
      }
    }

    return false;
  }

  /**
   * Returns the length of the given path. A path is a list of
   * vertices where adjacent vertices in the path are connected by an
   * edge in the graph.
   */
  public int pathLength(List<String> path) {
    int wt = 0;
    if (path.size() <= 1)
      return 0;
    Iterator<String> it = path.iterator();
    String curr = it.next();
    while (it.hasNext()) {
      String next = it.next();
      wt = wt + weight(curr, next);
      curr = next;
    }
    return wt;
  }

  /**
   * Runs Dijkstra's algorithm to determine the shortest path from
   * s to t in this graph. Assume this graph is connected and s and
   * t are legal vertices.
   */
  public List<String> shortestPath(String s, String t) {
    assert hasVertex(s);
    assert hasVertex(t);
    assert isConnected(s, t);

    class Label {
      int dist;
      String parent;
      
      Label(int dist, String parent) {
        this.dist = dist;
        this.parent = parent;
      }

      public String toString() {
        return String.format("[%d,%s]", dist, parent);
      }
    }

    Map<String, Label> labels = new HashMap<>();
    PriorityQueue<String> fringe = new PriorityQueue<>((x, y) -> labels.get(x).dist - labels.get(y).dist);

    labels.put(s, new Label(0, null));
    fringe.offer(s);

    while (!fringe.isEmpty()) {
      String x = fringe.poll();
      if (x.equals(t))
        break;
      for (String y : adj(x)) {
        int alt = labels.get(x).dist + weight(x, y);
        if (labels.get(y) == null) {
          labels.put(y, new Label(alt, x));
          fringe.offer(y);
        }
        else if (alt < labels.get(y).dist) {
          fringe.remove(y);
          labels.put(y, new Label(alt, x));
          fringe.offer(y);
        }
      }
    }

    List<String> path = new DoublyLinkedList<>();
    while (!t.equals(s)) {
      path.add(t);
      t = labels.get(t).parent;
    }
    path.add(s);
    List<String> ret = new DoublyLinkedList<>();
    while (path.size() != 0)
      ret.add(path.remove(path.size() - 1));

    return ret;
  }

  /**
   * Returns a textual representation of this graph.
   */
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append(String.format("LinkedGraph %s: n=%d, m=%d", 
                            getName(),
                            getNumVertices(),
                            getNumEdges()));
    Iterator<String> it = adjLists.keys();
    while (it.hasNext()) {
      String v = it.next();
      sb.append(String.format("\n  %s: ", v));
      sb.append(adjLists.get(v));
    }
    return sb.toString();
  }
}
