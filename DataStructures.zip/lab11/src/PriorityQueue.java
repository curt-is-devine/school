import java.util.Comparator;

/**
 * lab11: starter code
 *
 * A PriorityQueue is a collection of keys, ordered according to a
 * specified comparator. The keys will be stored in a heap that is
 * represented as an array. The main operations on a PriorityQueue are
 * offer(), peek(), and poll().
 *
 * If you are unable to complete this exercise during lab, continue to
 * work on it on your own because you will need an implementation of
 * PriorityQueue for when you implement Huffman's algorithm next week.
 */

public class PriorityQueue<E> {
  
  E[] heap = newTable(10);
  Comparator<E> comp;
  int n;  

  /**
   * Creates a priority queue that orders its elements according to
   * the specified comparator.
   */

  public PriorityQueue(Comparator<E> comp) {
    this.comp = comp;
  }

  /**
   * Inserts the specified element into this priority queue.
   */

  public void offer(E e) {
    if (n == heap.length)
      heap = newTable(2 * n, heap);

    heap[n] = e;
    siftUp(n);
    n++;
  }

  /**
   * Retrieves, but does not remove, the head of this queue, or returns
   * null if this queue is empty.
   */

  public E peek() {
    if (isEmpty())
      return null;
    return heap[0];
  }

  /**
   * Retrieves and removes the head of this queue, or returns null if this
   * queue is empty.
   */

  public E poll() {
    E rem = peek();
    if (rem == null)
      return null;

    //swap(0, n-1);
    heap[0] = heap[n-1]; //= null;
    n--;
    siftDown(0);
    return rem;
  }

  /**
   * Returns the number of keys in this queue.
   */

  public int size() {
    return n;
  }
  
  /**
   * Returns true iff this queue is empty.
   */

  public boolean isEmpty() {
    return size() == 0;
  }

  /////////////////////////////////////
  // Utility methods below this line //
  /////////////////////////////////////

  /**
   * Restores the ordering property at node p so that the first n
   * elements of array heap form a heap ordered by this queue's
   * comparator. Used by poll().
   *
   * Implementation requirements: Use O(1) additional space. In
   * particular, this means that you should not use recursion to
   * implement this method.
   */

  public void siftDown(int p) {

    for (int i = p; i < n; ) {
      int leftChild = leftChild(i);
      int rightChild = rightChild(i);

      if (rightChild < n) {
        if (comp.compare(heap[leftChild], heap[rightChild]) >= 0 && comp.compare(heap[i], heap[rightChild]) > 0) {
          swap(i, rightChild);
          i = rightChild;
        } else if (comp.compare(heap[leftChild], heap[rightChild]) < 0 && comp.compare(heap[i], heap[leftChild]) > 0) {
          swap(i, leftChild);
          i = leftChild;
        } else return;
      } else if (leftChild < n) {
        if (comp.compare(heap[i], heap[leftChild]) > 0) {
          swap(i, leftChild);
          return;
        }
        else return;
      } else return;
    }

  }

  /**
   * Restores the heap ordering property by sifting the key at
   * position q up into the heap. Used by offer().
   *
   * Implementation requirements: Use O(1) additional space. In
   * particular, this means that you should not use recursion to
   * implement this method.
   */

  public void siftUp(int q) {

    for (int i = q; i > 0; ) {
      int par =  parent(i);

      if (par >=0) {
        if (comp.compare(heap[i], heap[par]) < 0) {
          swap(i, par);
          i = par;
        }
        else return;
      } else return;
    }

  }

  /**                                                                           
   * Exchanges the elements at indices i and j in the heap.       
   */

  private void swap(int i, int j) {
    if (i != j) {
      E temp = heap[i];
      heap[i] = heap[j];
      heap[j] = temp;
    }
  }

  /**                                                                           
   * Returns a logical pointer to the left child of node p.                     
   */

  private static int leftChild(int p) {
    return 2 * p + 1;
  }

  /**                                                                           
   * Returns a logical pointer to the right child of node p.                    
   */

  private static int rightChild(int p) {
    return leftChild(p) + 1;
  }

  /**                                                                           
   * Returns a logical pointer to the parent of node p.                         
   */

  private static int parent(int p) {
    return (p - 1) / 2;
  }

  /**
   * Technical workaround for creating a generic array.
   */

  @SafeVarargs 
  private static <E> E[] newTable(int length, 
                                  E... table) {
    return java.util.Arrays.copyOf(table, length);
  }

}
