import java.util.Comparator;

public class Select {

  /**
   * Returns the k-th largest element in the given non-empty
   * array. Assume k is at least 1 and at most n, where n is the
   * length of the array.
   *
   * Implementation requirements: Copy all n elements from the array
   * into a priority queue. Then remove k - 1 elements from the queue
   * and return the head of the queue.
   *
   * What is the Big-O running time of kthLargest (in terms of k and
   * n)? O(n)
   *
   */

  public static int kthLargest(int[] a, int k) {
    Comparator<Integer> comp = (x, y) -> y - x;
    PriorityQueue<Integer> aprime = new PriorityQueue<Integer>(comp);
    for (int i : a)
      aprime.offer(i);

    for (int i = 0; i < k - 1; i++)
      aprime.poll();

    return aprime.peek();
  }

  /**
   * Simple testing.
   */

  public static void main(String... args) {
    int[] a = new int[] { 4, 2, 1, 7, 8, 9, 3, 5, 10, 6 };
    System.out.println(kthLargest(a, 4) == 7);
  }
}