/**
 * [hw5]
 * 
 * We implement a top-down memoized solution to the Longest Increasing 
 * Subsequence problem, following the recursive algorithm described in 
 * lecture. See the notes from lec9b.
 *
 * Create a hw5 project in IntelliJ and copy your code for Map,
 * HashMap, AList, Assoc, and DoublyLinkedList from p4 into the src
 * directory.
 *
 * Most of the work that you are to do is in the implementation of the
 * TopDown.lisHelper() function. However, there are two small, but
 * important, items in the Subproblem class below that require your
 * attention.
 */

/**
 * A Subproblem corresponds to one node in the decision tree. It is
 * described by two pieces of information: the index in the array of
 * the element under consideration (for inclusion in the sequence
 * being constructed), and the largest element in the sequence so far.
 */

class Subproblem {
  int pos;  // the index of the element under consideration
  int cap;  // the largest value in the sequence already selected
  
  /**
   * Constructs a problem from the given position and cap.
   */
  Subproblem(int pos, int cap) {
    this.pos = pos;
    this.cap = cap;
  }
  
  /**
   * Returns true iff the given object equals this object, field for
   * field.  If we don't override this method, then the hash map will
   * not be able to find previously stored problems.
   */
  @Override
  public boolean equals(Object obj) {
    if (obj instanceof Subproblem) {
      Subproblem s = (Subproblem) obj;

      return this.pos == s.pos && this.cap == s.cap;
    }
    return false;// uses == to determine equality
  }
  
  /**
   * Returns a nicely packed version of this Subproblem. This promotes
   * good behavior of a hash map that uses Subproblems as keys. This
   * Implementation guarantees a unique hashCode for every pos/cap combination
   */
  @Override
  public int hashCode() {
    return (pos + cap) * (pos + cap + 1)/2 + cap;
  }

  /**
   * Returns a sensible textual version of this Subproblem.
   */
  public String toString() {
    return String.format("(%d, %d)", pos, cap);
  }
}

public class TopDown {
  
  private static Map<Subproblem, Integer> cache;
  
  /**
   * Returns the length of the longest increasing subsequence in the 
   * array a.
   */
  public static int lis(int[] a) {
    if (a.length == 0)
      return 0;

    cache = new HashMap<>(a.length);
    // Initially, we consider the element at position 0 and our cap,
    // so far, is 0.
    Subproblem p = new Subproblem(0, 0);
    return lisHelper(a, p);
  }

  /**
   * Returns the result of solving the Subproblem described by prob. 
   */
  public static int lisHelper(int[] a, Subproblem prob) {


    // Check to see if this problem has been previously
    // solved. If so, return the cached value.
    Integer prev = cache.get(prob);
    if (prev != null)
      return prev;

    int ans = 0;
    if (prob.pos < a.length) {
      int with = 0, without = 0;
      // Recur to find the "with" and "without" results, so
      // we can use those results to build the answer ans.
      int newPos = prob.pos + 1;

      if (prob.cap < a[prob.pos])
        with = lisHelper(a, new Subproblem(newPos, Math.max(prob.cap, a[prob.pos])));
      else
        with = lisHelper(a, new Subproblem(newPos, Math.max(prob.cap, a[prob.pos]))) - 1;
      without = lisHelper(a, new Subproblem(newPos, prob.cap));

      ans = Math.max(1 + with, without);
    }

    // Store this problem/answer association in the cache
    // for future reference.
    cache.put(prob, ans);
    
    return ans;
  }

  /**
   * Simple testing.
   */
  public static void main(String... args) {
    int[] a;
    a = new int[] { 2, 6, 3, 5};
    assert 3 == lis(a);
    a = new int[] { 2, 1};
    assert 1 == lis(a);
    a = new int[] { 5, 6, 1, 2, 9, 3, 4, 7, 4, 3 };
    assert 5 == lis(a);
    a = new int[] { 2, 1, 5, 3, 6, 4, 2, 7, 9, 11, 8, 10 };
    assert 6 == lis(a);
    a = new int[100];
    for (int i = 0; i < a.length; i++)
      a[i] = i + 1;
    assert a.length == lis(a);
    System.out.println("All tests passed...");
  }
}

