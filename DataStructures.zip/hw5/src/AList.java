/**
 * TODO: Implement the addFront() method.
 */

import java.util.Iterator;

public class AList<K, V> extends DoublyLinkedList<Assoc<K, V>> {

  /**
   * Inserts the given association at the front of this list and
   * adjusts pointers accordingly
   */
  public void addFront(Assoc<K, V> a) {  

    n++;
    modCount++;
    Node newNode = new Node(a, head, head.next);
    head.next = newNode;
    newNode.next.prev = newNode;

  }
  
  /**
   * Returns the association with the given key in this list if it
   * exists, and returns null otherwise. Self-adjusts by moving the returned
   * association to the front.
   */

  public Assoc<K, V> get(K key) {
    Iterator<Assoc<K, V>> it = iterator();
    while (it.hasNext()) {
      Assoc<K, V> a = it.next();
      if (key.equals(a.key)) {
        it.remove();
        addFront(a);
        return a;
      }
    }
    return null;
  }

}
