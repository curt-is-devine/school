/**
 * [hw5] 
 * 
 * We implement a bottom-up solution to the Longest Increasing
 * Subsequence problem, following the algorithm described in lec9b and
 * lec10a.
 */

import org.omg.CORBA.DynAnyPackage.Invalid;

/**
 * A subproblem is to compute the length of the longest increasing
 * subsequence that ends with the i-th element in the array. The
 * result of solving such a subproblem is the score (i.e., the length
 * of the sequence) and the parent (i.e., the index of element in the
 * array that precedes the i-th one in the identified sequence).
 */

class Result {
  int score;
  int parent;

  Result(int score, int parent) {
    this.score = score;
    this.parent = parent;
  }

  public String toString() {
    return String.format("(%d,%d)", score, parent);
  }
}

public class BottomUp {
  
  /**
   * Returns an array consisting of the longest increasing subsequence
   * in a. Your solution must follow the code sketch given in lecture.
   */

  public static int[] lis(int[] a) {
    int n = a.length;
    Result[] cache = new Result[n];

    if (n == 0)
      return a;

    //fill the cache
    cache[0] = new Result(1, -1);
    int prev, score;
    for(int i = 1; i < a.length; i++) {
      prev = 0;
      score = 0;
      for (int j = 0; j < i; j++) {
        if (a[j] < a[i] && cache[j].score > score) {
          prev = j;
          score = cache[j].score;
        }
      }
      if (score == 0)
        cache[i] = new Result(1, -1);
      else
        cache[i] = new Result(score + 1, prev);
    }

    int highestScore = 0;
    for (int i = 1; i < a.length; i++)
      if (cache[i].score > cache[highestScore].score)
        highestScore = i;


    int seqSize = cache[highestScore].score;
    int[] seq = new int[seqSize];
    int i = seqSize - 1;
    seq[i] = a[highestScore];
    i--;

    //follow parent pointers to recover longest subsequence
    while (cache[highestScore].parent != -1) {
      highestScore = cache[highestScore].parent;
      seq[i] = a[highestScore];
      i--;
    }

    return seq;
  }

  /**
   * Simple testing.
   */

  public static void main(String... args) {
    int[] a, b;
    a = new int[] {};
    b = lis(a);
    assert 0 == b.length;
    assert a == b;
    a = new int[] { 5, 6, 1, 2, 9, 3, 4, 7, 4, 3 };
    b = lis(a);
    assert 5 == b.length;
    assert 1 == b[0];
    assert 2 == b[1];
    assert 3 == b[2];
    assert 4 == b[3];
    assert 7 == b[4];
    a = new int[] { 2, 1, 5, 3, 6, 4, 2, 7, 9, 11, 8, 10 };
    b = lis(a);
    assert 6 == b.length;
    assert 2 == b[0];
    assert 5 == b[1];
    assert 6 == b[2];
    assert 7 == b[3];
    assert 9 == b[4];
    assert 11 == b[5];
    a = new int[] { 1, 2, 3, 4, 5 };
    b = lis(a);
    assert a.length == b.length;
    a = new int[] { 5, 4, 3, 2, 1 };
    b = lis(a);
    assert 1 == b.length;
    System.out.println("All tests passed...");
  }
}

