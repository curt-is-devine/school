/**
 * TODO: Implement kthLargest using the following algorithm:
 *
 * Algorithm kthLargest(a, k)
 *   Copy the keys from the array a into a max-heap.
 *   Repeat k-1 times:
 *   - Delete the root of the heap
 *   - Restructure the heap to preserve the ordering property
 *   Return the key at the root of the heap.
 *
 * @author Curtis Devine/cudevine Matthew Denney
 */
public class Select {
    /**
     * Returns the kth largest element in the array a. This method
     * is non-destructive (in the sense that no modifications to the
     * array a are made).
     */
    public static int kthLargest(int[] a, int k) {
        assert a != null;
        int n = a.length;
        assert n > 0 && k <= n;

        int[] copyA = new int[n];
        for (int i = 0; i < n; i++) copyA[i] = a[i];
        heapify(copyA);
        for (int i = 0; i < n; i++) {
            swap(copyA, 0, n - 1 - i);
            siftDown(copyA, 0, n - 1 - i);
        }

        return copyA[n - 1 - (k - 1)];
    }

    /**
     * Rearranges the elements of a so that they form a max-heap.
     */
    public static void heapify(int[] a) {
        int n = a.length;
        int last = parent(n - 1);
        for (int p = last; p >= 0; p--) siftDown(a, p, n);
    }

    /**
     * Restores the ordering property at node p so that elements from
     * 0 to last, inclusive, in the array a form a max-heap.
     */
    public static void siftDown(int[] a, int p, int last) {
        for (int i = p; i < last; ) {
            int leftChild = leftChild(i);
            int rightChild = rightChild(i);

            if (rightChild < last) {
                if (a[rightChild] >= a[leftChild] && a[rightChild] > a[i]) {
                    swap(a, i, rightChild);
                    i = rightChild;
                } else if (a[leftChild] > a[rightChild] && a[leftChild] > a[i]) {
                    swap(a, i, leftChild);
                    i = leftChild;
                }
                else return;
            } else if (leftChild < last) {
                if (a[leftChild] > a[i]) {
                    swap(a, i, leftChild);
                    return;
                }
                else return;
            } else return;
        }
    }


    /**
     * Exchanges the elements at indices i and j in the array a.
     */
    public static void swap(int[] a, int i, int j) {
        assert j < a.length;
        assert i < a.length;

        int temp = a[i];
        a[i] = a[j];
        a[j] = temp;
    }

    /**
     * Returns a logical pointer to the left child of node p.
     */
    public static int leftChild(int p) {
        return 2 * p + 1;
    }

    /**
     * Returns a logical pointer to the right child of node p.
     */
    public static int rightChild(int p) {
        return leftChild(p) + 1;
    }

    /**
     * Returns a logical pointer to the parent of node p.
     */
    public static int parent(int p) {
        return (p - 1) / 2;
    }

    /**
     * Run a few simple tests.
     */
    public static void main(String[] args) {
        // Verify that asserts are being checked.
        assert true == false; // delete later
        int[] a, b, copyOfA;
        a = new int[] { 8, 7, -3, 9, 2, 1, -5, 4, 12, -2 };
        b = new int[] { 12, 9, 8, 7, 4, 2, 1, -2, -3, -5 };
        copyOfA = new int[] { 8, 7, -3, 9, 2, 1, -5, 4, 12, -2 };
        for (int i = 0; i < a.length; i++) {
            assert kthLargest(a, i + 1) == b[i];
            // Make sure kthLargest is non-destructive.
            assert a[i] == copyOfA[i];
        }
        System.out.println(kthLargest(a, 8));
        System.out.println("Correctness checks passed!");




    }
}
