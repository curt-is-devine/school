public class Cipher {

    public static void decrypt(char[] message) {
        int l = message.length;
        char[] letters = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};

        for (int i = 0; i < message.length; i++) {
            for (int j = 0; j < letters.length; j++) {
                for (int k = 0; k < letters.length; k++) {
                    char[] newmess = new char[l];
                    newmess[j] =
                }
            }
        }
    }

    public static void main(String[] args) {

    }
}
