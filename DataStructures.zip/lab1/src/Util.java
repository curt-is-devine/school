public class Util {

    public static int search(int[] a, int[] b) {
        int m = a.length;
        int n = b.length;
        assert m <= n;

        for (int i = 0; i <= n - m; i++) {
            if (a[0] == b[i]) {
                for (int j = 0; j < m; j++) {
                    if (a[j] == b[i+j]) {
                        if (j == m-1) {
                            return i;
                        }
                        continue;
                    }
                    else break;
                }
            }
        }

        return -1;
    }

    public static void main(String[] args) {
        int[] a, b, c;
        b = new int[] {1, 2, 3, 4, 5, 6, 7};
        a = new int[] {4, 5};
        c = new int[] {1, 3, 5};

        System.out.println(search(a, b));
        System.out.println(search(c, b));
    }

}
