import java.io.File;
import javax.swing.SwingUtilities;

/**
 * This is the main entry point for the application. When run, a GUI
 * will appear showing the chip with the wires connected. The layout
 * computed by PathFinder will be used unless it returns an empty
 * layout. In that case, a fixedLayout will be used (if it exists for
 * the chip).
 *
 * REPORT: Curtis Devine
 * My algorithm for the wire routing problem follows a breadth first
 * search strategy with optimization regarding already visited coordinates.
 * In short, my algorithm processes the nearest coordinates, and if they are
 * not a solution, it continues to check neighboring coordinates until a
 * solution is found. Once a solution is found for the first wire, then
 * if more wires need routing, the algorithm continues the approach for each
 * wire until it reaches the final wire. Along the way, if any of the wires
 * are found to be unable to connect given the current wire layout, then that
 * wire's recursion fails, and the previous wire is rerouted to find a new,
 * less optimal path.
 *
 * I chose the BFS approach to the problem because I know that theoretically
 * it will find the most optimal path. However, there is a lot of overhead in
 * that BFS could just constantly re-investigate certain coordinates in the plain.
 * In order to account for this as I went, instead of as an after thought, I check
 * to make sure that each coordinate has not been visited before. This optimization
 * greatly increased my running time in my algorithm and I am confident in its ability
 * to work on small chips at the very least.
 *
 * Unfortunately I ran out of time to really work on this project as much as I would
 * have liked. There were some short comings in my priorityqueue.tostring() method
 * that I could not find. I assumed this was due to some error in my tracking of indices,
 * but with the removal of the front-reassigning feature of our ALists, this caused
 * many functionalities ot break, which I did not have time to go through and fix since the
 * remove function was not really used in my use of priority queue as a queue. I would have
 * also liked more time to create a better algorithm for the pathfinding. Obviously my solution
 * was more brute force than an actual solution, but every algorithm I attempted instead of
 * simple BFS search performed far slower than my current one, so I abandoned those. I know we
 * had two weeks to work on this assignment, but that just was not enough time for me considering
 * my other courses and I regret not having enough time to put forth the effort into this project
 * I would have liked. However, my solution works really well for small chips so this project was
 * not a complete failure. In my research of the problem I came across many high level algorithms
 * that could be solutions, but far beyond my understanding. My group members offered some valid
 * algorithms as well, but they ultimately fell short for me. There were a lot of ways to approach
 * this assignment and that is what I took out of this from a learning perspective. Having
 * to think about all of the different ways that this problem could be solved was a bit
 * overwhelming, but without trying those approaches, or at least looking into them, I would not
 * be able to critically htink about this problem in the way that I ultimately had to in order
 * to not only attempt implementation of them, but also understand how my functionality outperformed
 * such algorithms, which in my perspective is not a failure at all.
 *
 * pseudocode:
 * path <- new path, curr <- wire.from, end <- wire.to, pq <- new min-size priority queue
 * size <- 1, neighs <- list of coordinates
 *
 * pq.add(curr) *
 * infinite while
 *  while curr is not end
 *    neighs <- neighbors(curr)
 *    for coord in neighs
 *      if coord is end
 *        path <- path + coord
 *        break
 *      else if coord is not free or path contains coord
 *        continue
 *      else
 *        copy <- copy(path) + coord
 *        pq <- offer(copy)
 *    if pq is empty
 *      return 1
 *    else
 *      path <- pq.poll
 *      curr <- path.get(pathsize - 1)
 *
 *  layoutwire(wire, path)
 *
 *  if wire is not last wire
 *    size <- setShortestPath(wire + 1)
 *    if size is 1
 *      pullWire(wire)
 *      if pq is empty
 *        return 1
 *      path <- pq.poll
 *      curr <- path.get(pathsize - 1)
 *      continue
 *    else
 *      size <- size + pathsize
 *      layout.put(wire, path)
 *      return size
 *  else
 *    layout.put(wire, path)
 *    return path.size
 *
 *
 *Data Structures used:
 *  Priority Queue: used for prioritizing checking of the smallest possible paths
 *  for wire routing. Based the queue on size of the path. This queue structure is
 *  necessary for a BFS search algorithm to succeed as it is path length dependent.
 *  Probably could have used a general purpose queue, but the priority queue we have
 *  implemented allows for removal of elements not at the top of the queue, which may
 *  be useful in better algorithms.
 *
 *  HashMap: Used for mapping of where wires are in the chip. Useful to be passed
 *  in between recursive calls to keep track of wires and chip layouts.
 *
 *  DoublyLinkedList: Used for most front facing lists in this project. Paths are doubly linked
 *  lists of coordinates for each wire.
 *
 *No heuristics were implemented in this assignment. The only simplifications I made ot BFS
 * were the checking of current coordinates in the wire path and decisions to stop searching
 * neighboring coordinates if a solution was found. As stated above, the checking of
 * preexisting coordinates in the path is necessary to avoid infinite loops in the search tree
 * as well as simplifies what would have required a clean up after finding a successful
 * path for a wire. The early termination fo neighbor checking aids the search in that if the
 * current coordinate is already selected and the solution is in the neighbors, then
 * that is the shortest path containing that coordinate, and taking the "long way around"
 * does not help anything except for if a wire is already laid there, which in most cases it isnt.
 *
 * Results:
 *
 * Chip       | Success/failure
 * --------------------------------------------------------------------------
 * small_01   | success
 * small_02   | success
 * small_03   | success
 * small_04   | success
 * small_05   | success
 * small_06   | success
 * small_07   | success
 * small_08   | success
 * small_09   | success
 * small_10   | success
 * small_11   | success
 * small_12   | success
 * medium_01  | success, but extremely slow
 * medium_02  | success
 * medium_03  | failure: too slow
 * medium_04  | failure: too slow
 * big_01     | failure: too slow
 * big_02     | failure: too slow
 * big_03     | failure: too slow
 * big_04     | failure: too slow
 * huge_01    | failure: too slow
 * nopath_01  | success/failure: NoPathException
 * nopath_02  | success/failure: NoPathException
 */

public class Driver {

  public static void main(String... args) {
    String chipName = "small_10";  // change this name for different chips

    System.out.println(Constants.TITLE);
    System.out.println(String.format("Start the GUI on %s ...", chipName));
    String fileName = String.format("%s/%s%s", Constants.INPUTS_FOLDER,
                                    chipName, Constants.EXTENSION);
    File file = new File(fileName);
    Chip chip = new Chip(file);
    Map<Integer, Path> layout = getLayout(chip);

    int[][] data;
    if (layout.isEmpty() && (data = getData(chipName)) != null) {
      /**
       * data[i] contains the flattened coordinates of wire (i+1)'s path.
       * Manually lay out the wires for this chip as specified by data.
       */
      for (int i = 0; i < data.length; i++) {
        Path p = new Path();
        for (int j = 0; j < data[i].length; j += 2) {
          Coord coord = new Coord(data[i][j], data[i][j + 1]);
          p.add(coord);
          chip.grid.put(coord, i + 1);
        }
        layout.put(i + 1, p);
      }
    }
    SwingUtilities.invokeLater(() -> new GUI(chip, layout, fileName));
  }

  /**
   * Use PathFinder to layout the wires on the chip.
   */

  public static Map<Integer, Path> getLayout(Chip chip) {
    Map<Integer, Path> layout;
    try {
      layout = PathFinder.connectAllWires(chip);
    }
    catch (NoPathException ex) {
      System.out.println(String.format("Could not layout %s.", ex.wire));
      layout = new HashMap<>();
    }
    return layout;
  }

  /**
   * Returns a data description of the wire connections for the chip with
   * the given name, if one exists in the database. Otherwise, returns null.
   */

  public static int[][] getData(String chipName) {
    Map<String, int[][]> database = new HashMap<>();
    database.put("small_02", new int[][] {
        { 0, 0, 1, 0, 1, 1 }, // 1
    });
    database.put("small_09", new int[][] {
        { 1, 0, 2, 0, 3, 0, 3, 1, 3, 2, 3, 3, 3, 4, 2, 4, 1, 4 }, // 1
        { 0, 1, 1, 1, 2, 1 }, // 2
        { 0, 2, 1, 2, 2, 2 }, // 3
        { 0, 3, 1, 3, 2, 3 }, // 4
    });
    database.put("medium_03", new int[][] {
        { 10, 12, 10, 13, 10, 14, 10, 15, 10, 16, 10, 17, 10, 18, 10, 19, 10,
            20, 10, 21 }, // 1
        { 12, 10, 13, 10, 14, 10, 15, 10, 16, 10, 17, 10, 18, 10, 19, 10, 20,
            10, 21, 10 }, // 2
        { 23, 12, 23, 13, 23, 14, 23, 15, 23, 16, 23, 17, 23, 18, 23, 19, 23,
            20, 23, 21 }, // 3
        { 12, 23, 13, 23, 14, 23, 15, 23, 16, 23, 17, 23, 18, 23, 19, 23, 20,
            23, 21, 23 }, // 4
        { 11, 13, 11, 14, 11, 15 }, // 5
        { 22, 13, 22, 14, 22, 15 }, // 6
        { 11, 18, 11, 19, 11, 20 }, // 7
        { 22, 18, 22, 19, 22, 20 }, // 8
        { 13, 11, 14, 11, 15, 11 }, // 9
        { 18, 11, 19, 11, 20, 11 }, // 10
        { 13, 22, 14, 22, 15, 22 }, // 11
        { 18, 22, 19, 22, 20, 22 }, // 12
        { 17, 13, 17, 14, 17, 15 }, // 13
        { 16, 18, 16, 19, 16, 20 }, // 14
        { 13, 16, 14, 16, 15, 16 }, // 15
        { 18, 17, 19, 17, 20, 17 }, // 16
        { 12, 13, 12, 14, 12, 15, 13, 15, 14, 15, 15, 15, 16, 15 }, // 17
        { 18, 16, 19, 16, 19, 15, 20, 15, 20, 14, 20, 13, 21, 13 }, // 18
        { 13, 21, 13, 20, 13, 19, 14, 19, 15, 19, 15, 18, 15, 17 }, // 19
        { 17, 18, 17, 19, 17, 20, 18, 20, 18, 21, 19, 21, 20, 21 }, // 21
        { 10, 10 }, // 21
    });
    return database.get(chipName);
  }
}