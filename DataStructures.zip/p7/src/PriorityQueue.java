import java.util.Comparator;

/**
 * A PriorityQueue is a collection of keys, ordered according to a
 * specified comparator. The keys will be stored in a heap that is
 * represented as an array and indices will be stored ofr quick access
 * in a hashmap
 */
public class PriorityQueue<E> {
  
  E[] heap = newTable(10);
  Comparator<E> comp;
  int n;
  HashMap<E, Integer> indices = new HashMap<>(100);

  /**
   * Creates a priority queue that orders its elements according to
   * the specified comparator.
   */
  public PriorityQueue(Comparator<E> comp) {
    this.comp = comp;
  }

  /**
   * Inserts the specified element into this priority queue.
   */
  public void offer(E e) {
    if (n == heap.length)
      heap = newTable(2 * n, heap);

    //Since we assume that keys are unique in the priority queue
    if (indices.get(e) != null)
      return;

    heap[n] = e;
    indices.put(e, n);
    siftUp(n);
    n++;
  }

  /**
   * Retrieves, but does not remove, the head of this queue, or returns
   * null if this queue is empty.
   */

  public E peek() {
    if (isEmpty())
      return null;
    return heap[0];
  }

  /**
   * Retrieves and removes the head of this queue, or returns null if this
   * queue is empty.
   */

  public E poll() {
    E rem = peek();
    if (rem == null)
      return null;

    swap(0, n-1);
    n--;
    siftDown(0);
    return rem;
  }

  /**
   * Returns the number of keys in this queue.
   */

  public int size() {
    return n;
  }
  
  /**
   * Returns true iff this queue is empty.
   */

  public boolean isEmpty() {
    return size() == 0;
  }

  /**
   * Removes the given element from the queue. Returns true iff the remove
   * was successful. This must run in O(log n) time.
   */
  public boolean remove(E e) {

    Integer i = indices.get(e);
    if (i == null) // || i >= n)
      return false;

    swap(i, n - 1);
    heap[n-1] = null;
    n--;
    indices.remove(e);
    siftDown(i);

    return true;
  }

  /////////////////////////////////////
  // Utility methods below this line //
  /////////////////////////////////////

  /**
   * Restores the ordering property at node p so that the first n
   * elements of array heap form a heap ordered by this queue's
   * comparator. Used by poll().
   *
   * Implementation requirements: Use O(1) additional space. In
   * particular, this means that you should not use recursion to
   * implement this method.
   */
  public void siftDown(int p) {

    for (int i = p; i < n; ) {

      if (isLeaf(i))
        return;

      int leftChild = leftChild(i);
      int rightChild = rightChild(i);

      int leftCompare = comp.compare(heap[i], heap[leftChild]);

      if (rightChild < n) {
        int childComparison = comp.compare(heap[leftChild], heap[rightChild]);

        if (childComparison >= 0 && comp.compare(heap[i], heap[rightChild]) > 0) {
          swap(i, rightChild);
          i = rightChild;
          continue;
        } else if (leftCompare > 0) {
          swap(i, leftChild);
          i = leftChild;
          continue;
        }
      } else if ( leftCompare > 0)
        swap(i, leftChild);
      return;
    }
  }

  /**
   * Restores the heap ordering property by sifting the key at
   * position q up into the heap. Used by offer().
   *
   * Implementation requirements: Use O(1) additional space. In
   * particular, this means that you should not use recursion to
   * implement this method.
   */
  public void siftUp(int q) {

    for (int i = q; i >= 0; ) {
      int par =  parent(i);

      if (par >=0 && comp.compare(heap[i], heap[par]) < 0) {
          swap(i, par);
          i = par;
          continue;
      }
      return;
    }
  }

  public boolean isLeaf(int i) {
    return leftChild(i) > n-1 ? true : false;
  }

  public String toString() {

    StringBuilder sb = new StringBuilder();
    sb.append("[");
    for (int i = 0; i < n; i++)
      sb.append(heap[i].toString() + ", ");

    if (n > 0)
      sb.setLength(sb.length() - 2);
    sb.append("]");

    return sb.toString();
  }

  /**                                                                           
   * Exchanges the elements at indices i and j in the heap.       
   */
  private void swap(int i, int j) {
    if (i != j) {
      E temp = heap[i];
      heap[i] = heap[j];
      heap[j] = temp;
      indices.put(heap[i], i);
      indices.put(heap[j], j);
    }
  }

  /**                                                                           
   * Returns a logical pointer to the left child of node p.                     
   */
  private static int leftChild(int p) {
    return 2 * p + 1;
  }

  /**                                                                           
   * Returns a logical pointer to the right child of node p.                    
   */
  private static int rightChild(int p) {
    return leftChild(p) + 1;
  }

  /**                                                                           
   * Returns a logical pointer to the parent of node p.                         
   */
  private static int parent(int p) {
    return (p - 1) / 2;
  }

  /**
   * Technical workaround for creating a generic array.
   */
  @SafeVarargs 
  private static <E> E[] newTable(int length, 
                                  E... table) {
    return java.util.Arrays.copyOf(table, length);
  }

}
