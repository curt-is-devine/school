import java.util.ConcurrentModificationException;
import java.util.Iterator;

/**
 * A Path represents a sequence of connected coordinates.
 */

public class Path extends DoublyLinkedList<Coord> implements Iterable<Coord> {
  protected Wire wire;
  
  public Path() {

  }

  public Path(Wire wire) {
    this.wire = wire;
    add(wire.from);
  }

  public Coord getCurrCoord() {
    return head.prev.data;
  }

  /**
   * Returns the length of this path.
   */

  public int length() {
    return size();
  }
}
