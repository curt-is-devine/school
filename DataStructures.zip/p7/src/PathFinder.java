//import com.sun.xml.internal.bind.v2.runtime.reflect.opt.Const;

import java.util.Comparator;
import java.util.Iterator;

public class PathFinder {

  /**
   * Lays out a path connecting each wire on the chip, and then
   * returns a map that associates a wire id numbers to the paths
   * corresponding to the connected wires on the grid. If it is 
   * not possible to connect the endpoints of a wire, then there
   * should be no association for the wire id# in the result.
   */

  public static Map<Integer, Path> connectAllWires(Chip chip) {
    Map<Integer, Path> layout = new HashMap<>();
    int size = setShortestPath(0, chip, layout);
    if (size == 1)
      throw new NoPathException(null);
    int sum = 0;
    Iterator<Path> value = layout.values();
    while(value.hasNext())
      sum += value.next().size();

    return layout;
  }

  public static int setShortestPath(int w, Chip chip, Map<Integer, Path> layout) {

    Wire wire = chip.wires.get(w);
    Path path = new Path();
    Coord curr = wire.from, end = wire.to;
    PriorityQueue<Path> pq = new PriorityQueue<>((x, y) -> x.size() - y.size());
    path.add(curr);
    int size = 1;
    List<Coord> neighs;

    while (true) {
      inner:
      while (!curr.equals(end)) {
        neighs = chip.neighbors(curr);
        for (Coord c : neighs) {
          if (c.equals(end)) {
            path.add(c);
            break inner;
          }
          if (!chip.isFree(c) || path.contains(c))
            continue;
          Path copy = new Path();
          for (Coord coo : path)
            copy.add(coo);
          copy.add(c);
          pq.offer(copy);
        }


        if (!pq.isEmpty()) {
          path = pq.poll();
          curr = path.getCurrCoord();
        }
        else
          return 1;

      }
      chip.layoutWire(wire.wireId, path);

      if (w != chip.wires.size() - 1) {
        size = setShortestPath(w + 1, chip, layout);
        if (size == 1) {
          chip.pullWire(wire, path);
          if (pq.isEmpty())
            return 1;
          path = pq.poll();
          curr = path.getCurrCoord();
          continue;
        }
        size += path.size();
        layout.put(wire.wireId, path);
        return size;
      }
      layout.put(wire.wireId, path);
      return path.size();
    }

  }


  /**
   * Returns the sum of the lengths of all non-null paths in the given layout.
   */

  public static int totalWireUsage(Map<Integer, Path> layout) {

    int sum = 0;
    Iterator<Integer> key = layout.keys();
    while (key.hasNext()) {
      Integer next = key.next();
      if (layout.get(next) != null)
        sum += layout.get(next).size();
    }

    return sum;
  }

}

class NoPathException extends RuntimeException {
  public Wire wire;

  public NoPathException(Wire wire) {
    this.wire = wire;
  }
}

