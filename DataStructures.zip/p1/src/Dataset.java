import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.Random;
import java.util.Arrays;

public class Dataset extends LinkedList<Digit> {

  private Digit[] neighbors;

  /**
   * Creates an empty dataset.
   */

  public Dataset() {
    super();
  }

  /**
   * Initializes this dataset by loading digits from the given file.
   */

  public Dataset(String filename) {
    load(filename);
  }

  /**
   * Runs knn on each entry in the given test set, using k as the number of
   * nearest neighbors and this dataset as the training set.
   */

  public void classify(int k, Dataset unknowns) {
    int i = 1;
    for (Digit d : unknowns) {
      d.classify(knn(k, d).getLabel());
      System.out.println(i++ + ", " + d.getLabel());
    }
  }

  /**
   * Searches this dataset to find the k nearest neighbors to the given
   * unknown, and then returns the closest neighbor with the majority label.
   * 
   * Assume k is a positive integer less than the size of this dataset.
   */

  public Digit knn(int k, Digit unknown) {
    assert k > 0;

    //Create a new nested array for a digit and its distance from the number in question
    Object[][] kNearest = new Object[this.size()][2];
    int index = 0;
    for (Digit d : this) {
        kNearest[index][0] = d;
        kNearest[index][1] = unknown.distance(d);
        index++;
    }

    /*heapify the nested array and calculate its size, then populate the neighbors
     *array with the smallest distance digits based on swapping and sifting appropriately
     */
    heapify(kNearest);
    int lastIndex = kNearest.length - 1;
    neighbors = new Digit[k];
    for (int i = 0; i < k; i++) {
        neighbors[i] = (Digit) kNearest[0][0];
        swap(kNearest, 0, lastIndex);
        lastIndex--;
        siftDown(kNearest, 0, lastIndex);
    }
/*
    //Debugging
      lastIndex = kNearest.length;
      int[] distances = new int[lastIndex];
      for (int j = 0; j < lastIndex; j++) {
          distances[j] = (int) kNearest[j][1];
      }
      Arrays.sort(distances);
      System.out.print("The k + 3 smallest sorted distances are: ");
      for (int i = 0; i < k + 3; i++) {
          System.out.print(distances[i]);
          System.out.print(" ");
      }
      System.out.println("");
      System.out.print("The neighbor labels are: ");
      for(Digit d : neighbors)
        System.out.print(d.getLabel() + " ");
      System.out.println("");
      System.out.print("With distances: ");
      for(Digit d : neighbors)
          System.out.print(unknown.distance(d) + " ");
      System.out.println("");
      System.out.print("The sorted distances are: ");
      for (int i = lastIndex - 1; i > lastIndex - 1 - k; i--)
          System.out.print(kNearest[i][1] + " ");

      System.out.println("");
      System.out.println("The top and children of the heap: ");
      System.out.print(kNearest[0][1]);
      System.out.print(" ");
      System.out.print(kNearest[1][1]);
      System.out.print(" ");
      System.out.println(kNearest[2][1]);
*/

      return maxCount(neighbors);
  }


  //Count the count of times each digit label shows up in the neighbors to get the best likely match
  public Digit maxCount(Digit[] neighs) {
      int[] counts = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
      for (Digit d : neighbors)
          counts[d.getLabel()]++;

      //Search through the count array and find the index with the highest count
      int maxCount = counts[0];
      for (int i = 1; i < counts.length; i++)
          if (counts[i] > maxCount)
              maxCount = counts[i];

      //return the digit that best matches the value with the highest count of possible matches
      for (Digit d : neighbors)
          if (counts[d.getLabel()] == maxCount) {
            //System.out.println("Classified digit label: " + d.getLabel());
            //System.out.println("");
            return d;
          }

      //default case if neighbors is found to be empty
      return neighbors[0];
  }

    //Hepaifys the nested object array using the siftDown method
    public static void heapify(Object[][] a) {
        int lastIndex = a.length - 1;
        for (int p = parent(lastIndex); p >= 0; p--)
            siftDown(a, p, lastIndex);
    }

    /**
     * Restores the ordering property at node p so that elements from
     * 0 to last, inclusive, in the array a form a min-heap.
     */
    public static void siftDown(Object[][] a, int parentIndex, int lastIndex) {
        int leftChildIndex = leftChild(parentIndex);
        int rightChildIndex = rightChild(parentIndex);
        int distanceIndex = 1;

        if (rightChildIndex <= lastIndex) {
            int rightDistance = (int) a[rightChildIndex][distanceIndex];
            int leftDistance = (int) a[leftChildIndex][distanceIndex];
            int parentDistance = (int) a[parentIndex][distanceIndex];

            if (rightDistance <= leftDistance && rightDistance < parentDistance) {
                swap(a, parentIndex, rightChildIndex);
                siftDown(a, rightChildIndex, lastIndex);
            } else if (leftDistance < rightDistance && leftDistance < parentDistance) {
                swap(a, parentIndex, leftChildIndex);
                siftDown(a, leftChildIndex, lastIndex);
            }
        } else if (leftChildIndex == lastIndex) {
            int leftDistance = (int) a[leftChildIndex][distanceIndex];
            int parentDistance = (int) a[parentIndex][distanceIndex];

            if (leftDistance < parentDistance)
                swap(a, parentIndex, leftChildIndex);
        }
    }

    /**
     * Exchanges the elements at indices i and j in the array a.
     */
    public static void swap(Object[][] a, int i, int j) {
        Object[] temp = a[i];
        a[i] = a[j];
        a[j] = temp;
    }

    /**
     * Returns a logical pointer to the left child of node p.
     */
    public static int leftChild(int p) {
        return 2 * p + 1;
    }

    /**
     * Returns a logical pointer to the right child of node p.
     */
    public static int rightChild(int p) {
        return leftChild(p) + 1;
    }

    /**
     * Returns a logical pointer to the parent of node p.
     */
    public static int parent(int p) {
        return (p - 1) / 2;
    }

  /**
   * Returns the array of nearest neighbors found by the most
   * recent call to knn.
   */

  public Digit[] getNeighbors() {
    return neighbors;
  }

  /**
   * Loads the digits from the given filename into this dataset.
   */

  public void load(String filename) {
    if (!filename.endsWith(".csv"))
      filename += ".csv";
    try {
      BufferedReader in = new BufferedReader(new FileReader(new File(filename)));
      in.readLine(); // get rid of header
      in.lines().forEachOrdered(line -> add(new Digit(line)));
      in.close();
    }
    catch (IOException ex) {
      System.out.println("Problem reading file: [" + filename + "]\n");
    }    
  }

  /**
   * Saves this dataset into the specified file using the MNIST format.
   */

  public void save(String filename) {
    if (!filename.endsWith(".csv"))
      filename += ".csv";
    StringBuilder header = new StringBuilder();
    header.append("label,");
    int last = Constants.DIM * Constants.DIM - 1;
    for (int i = 0; i < last - 1; i++)
      header.append("pixel").append(i).append(",");
    header.append("pixel").append(last);  
    try {
      PrintWriter out = new PrintWriter(new File(filename));
      out.println(header);
      for (Digit d : this) 
        out.println(d.getCode());
      out.close();
    }
    catch (IOException e) {
      System.out.println("Problem creating the file: [" + filename + "]\n.");
    } 
  }

  /**
   * Returns the accuracy of knn on m random digits in this dataset. Takes a
   * long time if this dataset is large.
   */

  public double validate(int k, int m) {
    int n = size(), matches = 0;
    Random rand = new Random();
    for (int i = 0; i < m; i++) {
      int pos = rand.nextInt(n);
      // Select a sample and remove it (temporarily) from this dataset to avoid
      // matching with itself.
      Digit sample = remove(pos);
      Digit match = knn(k, sample);
      if (sample.getLabel() == match.getLabel()) {
        matches++;
        System.out.print(".");
      }
      else
        System.out.print("x");
      add(pos, sample);
    }
    return (100.0 * matches) / m;
  }

  /**
   * Simple testing.
   */

  public static void main(String[] args) {
      /*
    Dataset tiny = new Dataset(Constants.DATA_DIR + "/tiny.csv");
    Dataset train = new Dataset(Constants.DATA_DIR + "/menzel.csv");
    train.classify(3, tiny);
    System.out.println("\nSize of dataset: " + train.size());
    int m = 50;
    for (int k = 3; k <= 11; k += 2, m += 10)
        System.out.format("k = %2d: %.1f%%%n%n", k, train.validate(k, m));
*/
    Object[][] dummyHeap = new Object[10000][2];
    for(int i = 0; i < 10000; i++) {
        dummyHeap[i][0] = i;
        dummyHeap[i][1] = new Random().nextInt(500000);
    }
    int[] otherHeap = new int[10000];
    for(int i = 0; i < 10000; i++)
        otherHeap[i] = (int) dummyHeap[i][1];

    Arrays.sort(otherHeap);
    heapify(dummyHeap);
    int lastIndex = dummyHeap.length - 1;
    int k = new Random().nextInt(10000);
    System.out.println(k);
    for (int i = 0; i < k; i++) {
        swap(dummyHeap, 0, lastIndex);
        lastIndex--;
        siftDown(dummyHeap, 0, lastIndex);
    }
    for (int i = 0; i < k; i++) {
        if ((int) dummyHeap[10000 - 1 - i][1] != otherHeap[i]) {
            System.out.println("Wrong: ");
            System.out.print(dummyHeap[10000 - 1 - i][1] + " ");
            System.out.println(otherHeap[i]);
        }
    }
  }

}