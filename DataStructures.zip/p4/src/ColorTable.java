import java.awt.Color;
import java.util.ConcurrentModificationException;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.Iterator;

/**
 * There is much to do here!
 *
 * A ColorTable represents a dictionary of frequency counts, keyed on
 * Color. However, it is implemented as a HashMap whose keys are of
 * type TinyColor and whose values are of type Long. The benefit to
 * doing this is so that we can reduce the size of the key space by
 * limiting each Color to a certain number of bits per channel.
 *
 * Implement this class, including whatever data members you need
 * and all of the public methods below. You may create any number of
 * private methods if you find them to be helpful. Be sure to
 * document all data fields and helper methods you define.
 */

public class ColorTable extends HashMap<TinyColor, Long> {
  private int bitsPerChannel;
  private double rehashThreshold;

  /**
   * Constructs a color table with a starting capacity of
   * initialCapacity. Keys in the color key space are truncated to
   * bitsPerChannel bits. The rehashThrehold specifies the maximum
   * tolerable load factor before triggering a rehash. Note that
   * because we are using chaining as our collision resolution
   * strategy, the load factor may rise above 1 without impacting
   * performance.
   * 
   * @throws RuntimeException if initialCapacity is not in the range
   * [1..Constants.MAX_CAPACITY]
   * @throws RuntimeException if bitsPerChannel is not in the range
   * [1..8]
   */
  public ColorTable(int initialCapacity, int bitsPerChannel, 
                    double rehashThreshold) {

    super(initialCapacity);

    if (initialCapacity < 1 || initialCapacity > Constants.MAX_CAPACITY)
      throw new RuntimeException();
    if (bitsPerChannel < 1 || bitsPerChannel > 8)
      throw new RuntimeException();
    if (rehashThreshold <= 0)
        throw new RuntimeException();

    this.bitsPerChannel = bitsPerChannel;
    this.rehashThreshold = rehashThreshold;
  }

  /**
   * Returns the number of bits per channel used by the colors in this table.
   */
  public int getBitsPerChannel() {
    return bitsPerChannel;
  }

  /**
   * Returns the frequency count associated with the given color. Note
   * that colors not explicitly represented in the table are assumed
   * to be present with a count of zero.
   */
  public Long get(Color color) {

    Long l = get(new TinyColor(color, bitsPerChannel));
    if ( l != null )
      return l;
    return 0L;

  }

  /**
   * Associates the count with the color code in this table. Do NOT store
   * associations with a count of zero. The addition of a new association may
   * trigger a rehash.
   *
   * @throws IllegalStateException if count is negative.
   */
  public Long put(Color color, Long count) {

    if (count < 0)
      throw new IllegalStateException();

    TinyColor c = new TinyColor(color, bitsPerChannel);

    if (count == 0) {
        Long l = remove(c);
        return l == null ? 0L : l;
    }

    Long oldCount = put(c, count);
    if (oldCount == null) {
        double load = getLoadFactor();
        if (load >= rehashThreshold)
            rehash();
    }

    return oldCount == null ? 0L : oldCount;
  }

  /**
   * Increments the frequency count associated with color. Note that
   * colors not explicitly represented in the table are assumed to be
   * present with a count of zero.
   */
  public void increment(Color color) {

    TinyColor c = new TinyColor(color, bitsPerChannel);
    Long l = get(c);
    if (l == null)
      put(color, (long) 1) ;
    else
      put(color, l + 1);
  }

  /**
   * Returns the load factor for this table.
   */
  public double getLoadFactor() {

    return (double) n / table.length;
  }

  /**
   * Returns the size of the internal array representing this table.
   */
  public int capacity() {
    return table.length;
  }

  /**
   * Increases the size of the array to the smallest prime greater
   * than double the current size that is of the form 4j + 3 that can store
   * all of the associations, and then moves all the key/value associations
   * into the new array.
   *
   * @throws RuntimeException if the table is already at maximum capacity.
   */

  public void rehash() {

    int capacity = table.length;
    int size = size();
    while ((double) size/capacity > rehashThreshold) {

        if (capacity == Constants.MAX_CAPACITY)
            throw new RuntimeException();

        capacity = capacity * 2;

        if (capacity < 0)
            capacity = Constants.MAX_CAPACITY;
        else {
            while ((capacity - 3) % 4 != 0)
                capacity++;
            while (!Util.isPrime(capacity))
                capacity = capacity + 4;
        }
    }

    AList<TinyColor, Long>[] tablePrime = table;

    ColorTable newTable = new ColorTable(capacity, bitsPerChannel, rehashThreshold);
    for (int i = 0; i < tablePrime.length; i++) {
        if (!tablePrime[i].isEmpty()) {
            for (Assoc a : tablePrime[i])
                newTable.put((TinyColor) a.key, (Long) a.value);
        }
    }
    table = newTable.table;
  }

  /**
   * Returns an Iterator that marches through each color in the key
   * color space and returns the sequence of frequency counts.
   */
  public Iterator<Long> iterator() {
    return new Iterator<Long>() {

      int step = 256 / (int) Math.pow(2, bitsPerChannel);
      int maxNum = 256 - step;
      int redIndex = 0, greenIndex = 0, blueIndex = 0;


      @Override
      public boolean hasNext() {
        return redIndex != maxNum + step;
      }

      @Override
      public Long next() {
          if (!hasNext())
              throw new NoSuchElementException();

          Long l = get(new Color(redIndex, greenIndex, blueIndex));
          if (blueIndex == maxNum) {
              blueIndex = 0;
              if (greenIndex == maxNum) {
                  greenIndex = 0;
                  redIndex = redIndex + step;
              } else
                  greenIndex = greenIndex + step;
          } else
              blueIndex = blueIndex + step;

          return l;
      }
    };
  }

  /**
   * Returns a String representation of this table.
   */
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("{");
    for (int i = 0; i < capacity(); i++)
      for (Assoc<TinyColor, Long> a : table[i])
        sb.append(a).append(" ");
    String ans = sb.toString().trim();
    return ans + "}";
  }

  /**
   * Simple testing.
   */

  public static void main(String[] args) {
    ColorTable ct = new ColorTable(11, 1, .49);
    ct.put(Color.RED, 5L);
    ct.put(Color.GREEN, 6L);
    ct.put(Color.BLUE, 7L);

    Iterator<Long> it = ct.iterator();
    while (it.hasNext())
      System.out.println(it.next());
        
    ColorTable table = new ColorTable(3, 6, .49); 
    for (int code : new int[] { 32960, 4293315, 99011, 296390 })
      table.increment(new Color(code));

    System.out.println("capacity: " + table.capacity()); // Expected: 7
    System.out.println("size: " + table.size());         // Expected: 3
    
    System.out.println(table);  
  }
}
