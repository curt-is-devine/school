import java.awt.Color;
import java.util.Iterator;

/**
 * There's a moderate amount to do here, but only after you have
 * completed the ColorTable class. 
 *
 */

public class Util {

  /**
   * Implement s cosine similarity, which is simply the dot product of two
   * vectors divided by the product of their magnitudes. In the case of Color
   * Tables, the vectors are the counts for each color in the color space, represented
   * through iteration, and not an actual array vector
   */
  public static double cosineSimilarity(ColorTable A, ColorTable B) {

    Iterator<Long> itA = A.iterator();
    Iterator<Long> itB = B.iterator();

    Long magA = 0L;
    Long magB = 0L;
    double dotProduct = 0.0;

    while (itA.hasNext() && itB.hasNext()) {
      Long ai = itA.next();
      Long bi = itB.next();

      magA = magA + ai * ai;
      magB = magB + bi * bi;
      dotProduct = dotProduct + ai * bi;

    }

    double divisor = Math.sqrt(magA) * Math.sqrt(magB);

    return dotProduct / divisor;
  }
  
  /**
   * Return the ColorTable associated with this image, assuming the
   * color key space is restricted to bitsPerChannel.
   */
  public static ColorTable vectorize(Image image, int bitsPerChannel) {
    ColorTable t = new ColorTable(3, bitsPerChannel, 0.9);

    for (int i = 0; i < image.getHeight(); i++) {
      for (int j = 0; j < image.getWidth(); j++) {
        t.increment(image.getColor(j, i));
      }
    }

    return t;
  }

  /**
   * Returns the result of running Util.cosineSimilarity() on the
   * vectorized images.
   */
  public static double similarity(Image image1, Image image2, 
                                  int bitsPerChannel) {

    ColorTable i1 = vectorize(image1, bitsPerChannel);
    ColorTable i2 = vectorize(image2, bitsPerChannel);

    return cosineSimilarity(i1, i2);
  }

  /**
   * Returns true iff n is a prime number. We handles several common
   * cases quickly, and then use a variation of the Sieve of
   * Eratosthenes.
   */
  public static boolean isPrime(int n) {
    if (n < 2) 
      return false;
    if (n == 2 || n == 3) 
      return true;
    if (n % 2 == 0 || n % 3 == 0) 
      return false;
    long sqrtN = (long) Math.sqrt(n) + 1;
    for (int i = 6; i <= sqrtN; i += 6) {
      if (n % (i - 1) == 0 || n % (i + 1) == 0) 
        return false;
    }
    return true;
  }
  
}
