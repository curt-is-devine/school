import java.util.function.BiPredicate;

/**
 * This class implements a generic height-balanced binary search tree, 
 * using the AVL algorithm. Beyond the constructor, only the insert()
 * method needs to be implemented. All other methods are unchanged.
 */

public class AVLTree<K> extends BinarySearchTree<K> {

  /**
   * Creates an empty AVL tree as a BST organized according to the
   * lessThan predicate.
   */
  public AVLTree(BiPredicate<K, K> lessThan) {
    super(lessThan);
  }

  /**
   * Inserts the given key into this AVL tree such that the ordering 
   * property for a BST and the balancing property for an AVL tree are
   * maintained.
   */
  
  public Node insert(K key) {
    Node q = super.insert(key);
    Node p = q;

    if (p == root)
      return p;
    p = p.parent;

    while (p != null) {
      if (p.isBalanced())
        break;
      if (p.isOverweight()) {
        rebalance(p);
        break;
      }
      p = p.parent;
    }

    return q;
  }

  public void rebalance(Node k1) {
    if (k1.left == null) { //is right heavy
      Node k2 = k1.right;
      if (k2.left == null)
        RRRotate(k1, k2);
      else if (k2.right == null)
        RLRotate(k1, k2, k2.left);
      else if (k2.left.height > k2.right.height) { //RL rotation
        Node k3 = k2.left;
        RLRotate(k1, k2, k3);
      } else { //RR rotation
        RRRotate(k1, k2);
      }
    }
    else if (k1.right == null) { //is left heavy
      Node k2 = k1.left;
      if (k2.left == null)
        LRRotate(k1, k2, k2.right);
      else if (k2.right == null)
        LLRotate(k1, k2);
      else if (k2.left.height > k2.right.height) { //LL rotation
        LLRotate(k1, k2);
      } else { //LR rotation
        Node k3 = k2.right;
        LRRotate(k1, k2, k3);
      }
    }
    else if (k1.left.height > k1.right.height) { //is left heavy
      Node k2 = k1.left;
      if (k2.left.height > k2.right.height) { //LL rotation
        LLRotate(k1, k2);
      } else { //LR rotation
        Node k3 = k2.right;
        LRRotate(k1, k2, k3);
      }
    } else { //is right heavy
      Node k2 = k1.right;
      if (k2.left.height > k2.right.height) { //RL rotation
        Node k3 = k2.left;
        RLRotate(k1, k2, k3);
      } else { //RR rotation
        RRRotate(k1, k2);
      }
    }
  }

  public void LLRotate(Node k1, Node k2) {
    Node b = k2.right;
    Node rent = k1.parent;

    //fix parent of pivot to point at new node and change  new node parent
    k2.parent = rent;
    if (rent != null) {
      if (rent.left == k1)
        rent.left = k2;
      else
        rent.right = k2;
    }
    else if (k1 == root) {
      root = k2;
    }

    //change pivot's parent and add new node
    k1.parent = k2;
    k1.left = b;

    //add pivot to new "pseudo-root" and change b-tree parent to be old pivot
    k2.right = k1;
    if (b != null)
      b.parent = k1;

    k1.fixHeight();
    k2.fixHeight();
    k2 = k2.parent;
    if (k2 != null) {
      while (k2.fixHeight()) {
        if (k2 == root)
          break;
        k2 = k2.parent;
      }
    }
  }

  public void LRRotate(Node k1, Node k2, Node k3) {
    RRRotate(k2, k3);
    LLRotate(k1, k3);
    k2.fixHeight();
    k1.fixHeight();
    k3.fixHeight();
    while (k2.parent.fixHeight())
      k2 = k2.parent;
  }
  public void RLRotate(Node k1, Node k2, Node k3) {
    LLRotate(k2, k3);
    RRRotate(k1, k3);
    k2.fixHeight();
    k1.fixHeight();
    k3.fixHeight();
    while (k2.parent.fixHeight())
      k2 = k2.parent;
  }
  public void RRRotate(Node k1, Node k2) {
    Node b = k2.left;
    Node rent = k1.parent;

    //fix parent of pivot to point at new node and change  new node parent
    k2.parent = rent;
    if (rent != null) {
      if (rent.left == k1)
        rent.left = k2;
      else
        rent.right = k2;
    } else if (k1 == root)
      root = k2;

    //change pivot's parent and add new node
    k1.parent = k2;
    k1.right = b;

    //add pivot to new "pseudo-root" and change b-tree parent to be old pivot
    k2.left = k1;
    if (b != null)
      b.parent = k1;
    k1.fixHeight();
    k2.fixHeight();
    k2 = k2.parent;
    if (k2 != null) {
      while (k2.fixHeight()) {
        if (k2 == root)
          break;
        k2 = k2.parent;
      }
    }
  }
 
}
