import java.util.function.BiPredicate;

/**
 * This class implements a generic unbalanced binary search tree (BST).
 */

public class BinarySearchTree<K> implements Tree<K> {
  
  /**
   * A Node is a Location, which means that it can be the return value
   * of a search on the tree.
   */
  
  class Node implements Location<K> {

    /**
     * Note that our nodes have been enhanced with three additional
     * pieces of information, as outlined in lecture.
     */
    K data;
    Node left, right;
    Node parent;     // the parent of this node                       
    int height;      // the height of the subtree rooted at this node
    boolean dirty;   // true iff the key in this node has been removed     

    /**
     * Constructs a leaf node with the given key.
     */
    Node(K key) {
      this(key, null, null);
    }
    
    /**
     * Constructs a new node with the given values for fields.
     */
    Node(K data, Node left, Node right) {

      this.left = left;
      this.right = right;
      this.data = data;
      if (left != null && right != null) {
        left.parent = this;
        right.parent = this;
      }
      else if (left != null && right == null)
        left.parent = this;
      else if (right != null && left == null)
        right.parent = this;
      if (left != null && right != null)
        this.height = Math.max(left.height, right.height) + 1;
      else if (left == null && right != null)
        this.height = right.height + 1;
      else if (left != null && right == null)
        this.height = left.height + 1;
      else
        this.height = 1;
      this.dirty = false;
      this.parent = null;

    }

    /**
     * Return true iff this node is a leaf in the tree.
     */
    boolean isLeaf() {
      return left == null && right == null;
    }
    
    /**
     * Performs a local update on the height of this node. Assumes that the 
     * heights in the child nodes are correct. Returns true iff the height
     * actually changed. This function *must* run in O(1) time.
     */
    public boolean fixHeight() {

      if (left != null && right != null) {
        int maxHeight = Math.max(left.height, right.height);
        if (maxHeight + 1 != height) {
          height = maxHeight + 1;
          return true;
        }
      }
      if (left == null && right != null) {
        if (height != right.height + 1) {
          height = right.height + 1;
          return true;
        }
      }
      if (left != null && right == null) {
        if (height != left.height + 1) {
          height = left.height + 1;
          return true;
        }
      }
      if (this.isLeaf()) {
        if (height != 1) {
          height = 1;
          return true;
        }
      }
      return false;

    }
    
    /**
     * Returns the data in this node.
     */
    public K get() {
      return this.data;
    }

    /**
     * Returns the location containing the inorder predecessor of this node.
     */
    public Node getBefore() {
      Node p = getBeforeHelper(this);
      return p;
    }

    public Node getBeforeHelper(Node p) {

      if (p.left == null && p.parent == null)
        return null;
      if (p.left == null && p == p.parent.right) {
        if (p.parent.dirty)
          return getBeforeHelper(p.parent);
        return p.parent;
      }
      else if (p.left != null) {
        p = p.left;
        while (p.right != null)
          p = p.right;
        if (p.dirty)
          return getBeforeHelper(p);
        return p;
      }
      else { //no left node, but is its parent's right child
        while (p.parent != null) {
          if (p.parent.left != p) {
            if (p.parent.dirty)
              return getBeforeHelper(p.parent);
            return p.parent;
          }
          p = p.parent;
        }
        return null;
      }
    }

    /**
     * Returns the location containing the inorder successor of this node.
     */

    public Node getAfter() {
      Node p = getAfterHelper(this);
      return p;
    }

    public Node getAfterHelper(Node p) {

      if (p.right == null && p.parent == null)
        return null;
      if (p.right == null && p == p.parent.left) {
        if (p.parent.dirty)
          return getAfterHelper(p.parent);
        return p.parent;
      }
      else if (p.right != null) {
        p = p.right;
        while (p.left != null)
          p = p.left;
        if (p.dirty)
          return getAfterHelper(p);
        return p;
      }
      else { //no right node, but is its parent's right child
        while (p.parent != null) {
          if (p.parent.right != p) {
            if (p.parent.dirty)
              return getAfterHelper(p.parent);
            return p.parent;
          }
            p = p.parent;
        }
        return null;
      }
    }

    /**
     * Returns true iff this node is overweight. Must run in O(1) time!
     */

    boolean isOverweight() {
      if (isBalanced())
        return false;
      else if (left != null && right != null) {
        if (left.height - right.height == 2 || left.height - right.height == -2)
          return true;
        return false;
      }
      else if (left == null) {
        if (right.height == 2)
          return true;
      }
      else if (right == null) {
        if (left.height == 2)
          return true;
      }
      return false;
    }

    /**
     * Returns true iff this node is balanced. Must run in O(1) time!
     */

    boolean isBalanced() {

      if (left != null && right != null) {
        if (left.height == right.height)
          return true;
      } else if (isLeaf())
        return true;
      return false;
    }

  }

  Node root;
  int n;
  BiPredicate<K, K> lessThan;
  
  int dirtyCount;

  /**
   * Constructs an empty BST, where the data is to be organized according to
   * the given lessThan relation.
   */

  public BinarySearchTree(BiPredicate<K, K> lessThan) {
    this.lessThan = lessThan;
  }
  
  /**
   * Looks up the key in this tree and, if found, returns the (possibly dirty)
   * location containing the key.
   */

  public Node search(K key) {
    Node p = searchHelper(key, root);
    return p;
  } 

  public Node searchHelper(K key, Node p) {

    if (p == null)
      return null;

    if (p.data.equals(key))
      return p;
    else if (lessThan.test(key, p.data))
      return searchHelper(key, p.left);
    else
      return searchHelper(key, p.right);
  }

  /**
   * Returns the height of this tree. Must run in O(1) time!
   */
  public int height() {
    if (root == null)
      return 0;
    return root.height;
  }
  
  /**
   * Clears all the keys from this tree. Must run in O(1) time!
   */
  public void clear() {
      n = 0;
      root = null;
      dirtyCount = 0;
  }

  /**
   * Returns the number of keys in this tree.
   */
  public int size() {
    return n;
  }
  
  /**
   * Inserts the given key into this BST, as a leaf, where the path
   * to the leaf is determined by the predicate provided to the tree
   * at construction time. The parent pointer of the new node and
   * the heights in all node along the path to the root are adjusted
   * accordingly.
   * 
   * Note: we assume that all keys are unique. Thus, if the given
   * key is already present in the tree, nothing happens.
   * 
   * Returns the location where the insert occurred (i.e., the leaf
   * node containing the key).
   */
  public Node insert(K key) {
    Node p;
    if (root == null) {
      n++;
      root = new Node(key);
      p = root;
    } else
      p = insertHelper(key, root);
    return p;
  }

  public Node insertHelper(K key, Node p) {

    if (p.data.equals(key)) {
      if (p.dirty) {
        n++;
        dirtyCount--;
        p.dirty = false;
      }
      return p;
    }

    if (lessThan.test(key, p.data)) {
      if (p.left == null) {
        n++;
        Node check = p;
        p.left = new Node(key);
        p.left.parent = p;
        p = p.left;
        while(check != null && check.fixHeight())
          check = check.parent;
      }
      else
        p = insertHelper(key, p.left);
    } else {
      if (p.right == null) {
        n++;
        Node check = p;
        p.right = new Node(key);
        p.right.parent = p;
        p = p.right;
        while (check != null && check.fixHeight())
            check = check.parent;
      }
      else
        p = insertHelper(key, p.right);
    }

    return p;
  }
  
  /**
   * Returns true iff the given key is in this BST.
   */
  public boolean contains(K key) {
    Node p = search(key);
    if (p == null)
      return false;
    if (p.dirty)
      return false;
    return true;
  }

  /**
   * Removes the key from this BST. If the key is not in the tree,
   * nothing happens. Implement the removal using lazy deletion.
   * 
   * Use the following algorithm:
   * (1) Search for the key.
   * (2) If found (and it's not already dirty), then make it dirty.
   */
  public boolean remove(K key) {
    Node loc = search(key);

    if (loc == null)
      return false;

    if (loc.dirty)
      return true;

    n--;
    dirtyCount++;
    loc.dirty = true;
    return true;
  }
  
  /**
   * Clears out all dirty nodes from this BST and reconstructs a
   * nicely balanced tree.
   * 
   * Use the following algorithm:
   * (1) Let ks be the list of keys in this tree. 
   * (2) Clear this tree.
   * (3) As long as ks is not empty:
   *       Remove the middle element in ks and
   *       Insert it into this tree.
   */
  /*
  public void rebuild() {
    List<K> ks = new DoublyLinkedList<>();
    ks = this.keys();
    this.clear();
    while (!ks.isEmpty()) {
      K toAdd = ks.get(ks.size()/2);
      ks.remove(toAdd);
      this.insert(toAdd);
    }
  }
  */

  public void rebuild() {
    List<K> ks = new DoublyLinkedList<>();
    ks = this.keys();
    this.clear();
    if (!ks.isEmpty())
      rebuildHelper(0, ks.size() - 1, ks, this);
  }

  public void rebuildHelper(int begin, int end, List keys, BinarySearchTree tr) {

    if (begin == end - 1) {
      tr.insert(keys.get(begin));
      tr.insert(keys.get(end));
      return;
    }
    if (begin == end) {
      tr.insert(keys.get(begin));
      return;
    }
    int midpoint = (end + begin) / 2;
    tr.insert(keys.get(midpoint));
    rebuildHelper(begin, midpoint-1, keys, tr);
    rebuildHelper(midpoint+1, end, keys, tr);

  }
    
  /**
   * Returns a sorted list of all the keys in this tree. 
   * Must run in O(n) time.
   */
  public List<K> keys() {

    Node p = root;
    if (p == null)
      return new DoublyLinkedList<K>();

    while (p.left != null)
      p = p.left;
    List<K> kees = new DoublyLinkedList<K>();
    while (p.dirty) {
      if (p.getAfter() == null)
        return kees;
      p = p.getAfter();
    }
    kees.add(p.data);
    while (p.getAfter() != null) {
      p = p.getAfter();
      kees.add(p.data);
    }
    return kees;
  }

  /**
   * Returns a preorder traversal of this BST.
   */
  public String toString() {
    return toStringPreorder(root);
  }

  private String toStringPreorder(Node p) {
    if (p == null)
      return "";
    String left = toStringPreorder(p.left);
    if (left.length() != 0) left = " " + left;
    String right = toStringPreorder(p.right);
    if (right.length() != 0) right = " " + right;
    String data = p.data.toString();
    if (p.dirty) data = "*" + data;
    return data + left + right;
  }
}
