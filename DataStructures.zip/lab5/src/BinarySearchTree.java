/**
 * Starter code for lab5. This is an implementation of BinarySearchTree 
 * for int data.
 *
 * (1) Modify Tree and BinarySearchTree so that they are generic for
 * any Comparable type object. 
 *
 * (2) Implement BinarySearchTree.toString() so that it yields a
 * string containing the sorted sequence of elements in the tree.
 *
 * (3) Implement the remove() method using the algorithm described by
 * your AI. Your code must run in O(h) time, where h is the height of
 * the tree.
 *
 * -- Start by defining the helper method largestNode(p) that returns
 *    a pointer to the node in the subtree rooted at p with the largest
 *    data value. You may assume that p is non-null.
 *
 * @author Curtis Devine and Xing Wei
 */

interface Tree<E extends Comparable<E>> {
  void insert(E key);
  default boolean remove(E key) {
    throw new UnsupportedOperationException();
  }
  boolean contains(E key);
  int size();
  default boolean isEmpty() {
    return size() == 0;
  }
  default int height() {
    throw new UnsupportedOperationException();
  }
}

public class BinarySearchTree<E extends Comparable<E>> implements Tree<E> {

  class Node {
    E data;
    Node left, right;

    Node(E key) {
      this(key, null, null);
    }

    Node(E data, Node left, Node right) {
      this.data = data;
      this.left = left;
      this.right = right;
    }

    boolean isLeaf() {
      return left == null && right == null;
    }
  }

  Node root;
  int n;

  /**
   * Inserts the key into this tree. Runs in O(h) time, where h is
   * the height of the tree.
   */

  public void insert(E key) {
    n++;
    root = insertHelper(key, root);
  }

  private Node insertHelper(E key, Node p) {
    if (p == null) 
      p = new Node(key);
    else if (key.compareTo(p.data) < 0)
      p.left = insertHelper(key, p.left);
    else 
      // if keys are unique, it must be the case that key > p.data
      p.right = insertHelper(key, p.right);
    return p;
  }

  /**
   * Returns true iff key is in this tree. Runs in O(h) time, where h is
   * the height of the tree.
   */

  public boolean contains(E key) {
    return containsHelper(key, root);
  }

  private boolean containsHelper(E key, Node p) {
    if (p == null)
      return false;
    if (key.equals(p.data))
      return true;
    if (key.compareTo(p.data) < 0)
      return containsHelper(key, p.left);
    return containsHelper(key, p.right);
  }

  /**
   * Returns the number of keys in this tree.
   */

  public int size() {
    return n;
  }

  /**
   * Returns a pointer to the node containing the largest data
   * value in this non-empty BST.
   */

  Node largestNode(Node p) {
    assert p != null;
    Node parent = null;

    while (p.right != null) {
      parent = p;
      p = p.right;
    }

    if (p.left != null && parent != null)
      parent.right = p.left;
    else if (p.left == null && parent != null)
      parent.right = null;

    return p;
  }

  public boolean remove(E key) {
    return removeHelper(key, root);
  }

  public boolean removeHelper(E key, Node p) {
    if (p == null)
      return false;
    else if (p.data.equals(key)) {
      n--;
      if (p.left != null) {
        Node largest = largestNode(p.left);
        largest.left = p.left;
        largest.right = p.right;
        p = largest;
      }
      else
        p = p.right;
      return true;
    }
    else if (key.compareTo(p.data) < 0)
      return removeHelper(key, p.left);
    else
      return removeHelper(key, p.right);
  }

  /**
   *
   * Returns a pretty text version of this tree. in in-order
   */

  public String toString() {

    Node p = root;
    StringBuilder str = new StringBuilder();
    str.append("(");
    if (p != null)
      stringHelper(p, str);
    str.append(")");
    return str.toString();

  }

  public StringBuilder stringHelper(Node p, StringBuilder str) {
    if (p.left != null) {
      str = stringHelper(p.left, str);
    }
    str.append(" ");
    str.append(p.data);
    str.append(" ");
    if (p.right != null) {
      str = stringHelper(p.right, str);
    }
    return str;
  }

  public static void main(String[] args) {

  }

}


