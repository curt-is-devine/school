#include <xinu.h>
//#include <prodcons.h>

void consumer(int count) {
}

