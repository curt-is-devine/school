#include <xinu.h>
//#include <prodcons.h>

void producer(int count) {
}



