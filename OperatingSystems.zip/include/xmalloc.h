//Function prototyped defined in system/xmalloc.c
void xmalloc_init();
void* xmalloc(size_t);
void xfree(void*);
char* xheap_snapshot();

//Arrays to hold information for xheap_snapshot and for tracking allocated memory
bpid32 xmalloc_buffs[8];
int usedMemPerBP[8];
int allocBuffsPerBP[8];
char* usedmems[510];
int respectiveMems[510];
bpid32 respectiveBuffs[510];

