char* kv_get(char*);
int kv_set(char*, char*);
bool kv_delete(char*);
void kv_reset();
int kv_init();
int get_cache_info(char*);
char** most_popular_keys(int);

struct sllNode {
	char* key;
	char* val;
	struct dllNode* next;
};

extern struct sllNode* cache;
int cacheHits, cacheAccesses, cacheSets, cacheSize, cacheKeys, cacheEvicts;
