/*Global variable for producer consumer*/
extern int n; /*this is just declaration*/

/*function Prototype*/
void consumer(int);
void producer(int);

/* Semaphore Declarations */
extern sid32 produced, consumed;
  
