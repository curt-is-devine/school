/* xsh_date.c - xsh_date */

#include <xinu.h>
#include <string.h>
#include <stdio.h>

/*------------------------------------------------------------------------
 * xsh_date - obtain and print the current month, day, year, and time
 *------------------------------------------------------------------------
 */
shellcmd xsh_hello(int nargs, char *args[]) {

	if (nargs < 2) {
		printf("Too few arguments. Expected one. Got 0\n");
		return 0;
	}
	if (nargs > 2) {
		printf("Too many arguments. Expected one, got %d\n", nargs - 1);
		return 0;
	}
	printf("Hello %s, Welcome to the world of Xinu!!\n", args[1]);
	return 0;	

}
