#include <xinu.h>
#include <kv.h>

shellcmd xsh_kv_test (int nargs, char* args[]) {

	kv_init();
	kv_set("abc", "def");
	printf("Inserted key: %s\n", kv_get("abc"));	
	printf("Status of xmalloc: %s\n\n\n", xheap_snapshot());

	kv_delete("abc");
	printf("After the removal, the stored value is: %s\n", kv_get("abc"));
	printf("The xmalloc status: %s", xheap_snapshot());
	return;
}	
