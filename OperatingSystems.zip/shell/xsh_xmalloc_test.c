/*xsh_xmalloc_test.c - xsh_xmalloc */

#include <xinu.h>
#include <string.h>
#include <stdio.h>
#include <xmalloc.h>

/*----------------------------------------------------------------------
 * xsh_xmalloc_test.c - test xmalloc functions developed for HW4
 *----------------------------------------------------------------------
 */

bpid32 xmalloc_buffs[];
char* usedmems[];

shellcmd xsh_xmalloc_test(int nargs, char *args[]) {

	//Initialize the data structures needed for mallocing
	xmalloc_init();
	//Create pointers and print the buffer pool status' each time
	//to ensure that the values are correct
	int *numptr = xmalloc(sizeof(int));
	printf("After adding int: \n%s\n", xheap_snapshot());
	char *charptr = xmalloc(sizeof(char));
	printf("After adding char: \n%s\n", xheap_snapshot());
	void *largeptr = xmalloc(555);
	printf("After adding large pointer (size 555): \n%s\n", xheap_snapshot());

	//Free each pointer and print the buffer pools' status following each
	//removal
	xfree(largeptr);
	printf("After deleting the large pointer: \n%s\n", xheap_snapshot());

	xfree(usedmems[1]);
	printf("After deleting the char pointer: \n%s\n", xheap_snapshot());

	xfree(numptr);
	printf("After deleting the last pointer: \n%s\n", xheap_snapshot());

	return 0;

}
