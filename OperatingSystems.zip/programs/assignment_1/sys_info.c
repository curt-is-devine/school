/* sys_info.c
 * Part of assignment 1
*/

#include <string.h>
#include <stdio.h>
#include <unistd.h>

/*------------------------------------------------------------------------
 * sys_info.c - mess iwth system calls
 *------------------------------------------------------------------------
 */

int main(int argc, char* argv[]) {

	if (argc < 2) {
		printf("Too few arguments, need a bash command.\n");
		return -1;
	}
	else if (argc > 2) {
		printf("Too many arguments, only need one bash command.\n");
		return -1;
	}

	int fd[2];
	if (pipe (fd)) {
		printf("Pipe failed.\n");
		return -1;
	}

	char readbuff[sizeof(argv[1]) +5];
	int pid = fork();
	if (pid < 0) {
		printf("Fork failed.\n");
		return -1;
	}


	if (pid == 0) {
		printf("Child PID: %d\n", getpid());
		//Closes write end of pipe
		close(fd[1]);
		read(fd[0], readbuff, sizeof(readbuff));
		if (strcmp(readbuff, "/bin/echo") == 0)
			execl("/bin/echo", "/bin/echo", "Hello World!", (char *)0);
		else
			execl(readbuff, readbuff, (char *)0);
	}
	else {
		printf("Parent PID: %d\n", getpid());
		//closes read end of pipe
		close(fd[0]);
		write(fd[1], argv[1], strlen(argv[1])+1);
		wait(NULL);
	}	

	return 0;
} 
