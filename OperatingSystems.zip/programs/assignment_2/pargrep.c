#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <ctype.h>
#include <stdlib.h>

FILE *file;
char *word;
pthread_mutex_t mutex;

void *findWord() {
	char *line;
	size_t line_len;
	int chars;

	while ((chars = getline(&line, &line_len, file)) != -1){
		pthread_mutex_lock(&mutex);
		if (strstr(line, word) != NULL)
			printf("%s", line);
		pthread_mutex_unlock(&mutex);
	}

	return;
}

int main(int nargs, char *args[]) {
	
	//For invalid argument count
	if (nargs > 5 || nargs == 1) {
		printf("Invalid arguments. pargrep requires at least a file and a word.\n");
		return -1;
	}

	if (nargs >= 4 & strcmp(args[1], "-t") != 0) {
		printf("Invalid argument %s, terminating.\n", args[1]);
		return -1;
	}

	//If piped input, only 2 or four arguments valid
	if (nargs == 2 || nargs == 4) {
		file = stdin;
		word = args[nargs - 1];
	}
	//nargs = 3 or 5, aka a file is present (or should be)
	else { 
		file = fopen(args[nargs - 1], "r");
		word = args[nargs - 2];
	}
	//If no file provided, error
	if (file == NULL) {
		printf("Did not receive a valid file.\n");
		return -1;
	}

	//Accounts for invalid thread counts (if applicable) and sets
	int tcount = 2;
	if (strcmp("-t", args[1]) == 0){
		int tinput = atoi(args[2]); 
		if (tinput <= 0) {
			printf("Invalid thread count.\n");
			return -1;
		}
		else 
			tcount = tinput;
	}
	pthread_t tid[tcount];
	
	int j = 0, err;
	while (j < tcount) {
		err = pthread_create(&(tid[j]), NULL, findWord, NULL);
		if (err != 0) {
			printf("Could not create thread, terminating.");
			return -1;
		}
		j++;
	}
	j = 0;
	while (j < tcount){ 
		pthread_join(tid[j], NULL);
		j++;
	} 
	
	if (nargs == 3 || nargs == 5)	
		fclose(file);
	
	return 0;
}
