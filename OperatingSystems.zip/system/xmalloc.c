#include <xinu.h>
#include <xmalloc.h>

//Arrays to hold information needed for xheap_snapshot() that were 
//initialized in include/xmalloc.h
bpid32 xmalloc_buffs[];
bpid32 mkbufpool(int32 bufsiz, int32 numbufs);
int usedMemPerBP[];
int allocBuffsPerBP[];
char* usedmems[];
int respectiveMems[];


void xmalloc_init() {

	//i and j correspond to indexes for buffer pools and memory locations
	//in the above outlines arrays needed for storing data. Size is 
	//hardcoded to only allow 8 different buffer pools and numbuffs
	//corresponds to how many buffers are allowed in a pool
	int i, j, size = 8, numbuffs = 256;

	//For each buffer pool t o be created:
	for (i = 0; i < 8; i++) {
		//Make the buffer pool and add it to the buffer pool array
		//fo reasy access in the xmalloc scope
		xmalloc_buffs[i] = mkbufpool(size, numbuffs);

		//double the size and halve the number of buffers in the next
		//pool 
		size = size * 2;
		numbuffs = numbuffs / 2;

		//Initialize the used memory and allocated buffers for this 
		//pool to be zero
		usedMemPerBP[i] = 0;
		allocBuffsPerBP[i] = 0;
	}
	
	//For each memory location to be created,
	for (j = 0; j < 510; j++) {
		//initiailize the array to all be zero (for probing purposes)
		//and set memory and buffer pointers to be zero as well
		usedmems[j] = (char *)0;
		respectiveMems[j] = 0;
		respectiveBuffs[j] = 0; 
	}

	//All data structures are initialized, so return
	return;
}

void* xmalloc(uint32 size) {

	//If an unallowed size: return an error
	if (size < 0 || size > 1024)
		return SYSERR;

	//Indices to hold buffer pool and memory use data respectively
	int i = 0, j = 0;

	//Finds the buffer pool of size just small enough to fit the size needed
	for (i; i < 8; i++)
		if (buftab[xmalloc_buffs[i]].bpsize >= size) 
			break;		

	//Finds the first available index in the memory arrays to be used for 
	//tracking this particular address
	for (j; j < 510; j++)
		if (usedmems[j] == (char* )0) 
			break;

	//If there are no available memory locations, return an error
	if (j == 510)
		return SYSERR;
		
	//get a buffer and save the memory address in the used mems array
	//corresponding to the first fre ememory location. Save to the size 
	//array at that same index the size of this memory 
	usedmems[j] = getbuf(xmalloc_buffs[i]);
	respectiveMems[j] = size;

	//increment the amount of memory stored in the appropriate buffer pool 
	//by the requested size and increment the same buffer pool's allocated
	//count
	usedMemPerBP[i] += size;
	allocBuffsPerBP[i] += 1;

	//Save a pointer to the buffer pool that the memory belongs to and return
	//the memory address
	respectiveBuffs[j] = i; 
	return usedmems[j];
}

void xfree(void* ptr) {

	//Saves indices of memory coresspondance arrays and buffer pool arrays
	//respectively
	int i, j;
	
	//Find the memory index that corresponds to the pointer wanting to be
	//released. Save the buffer pool at that index for accounting purposes
	//and free the memory from use
	for (i = 0; i < 510; i++) {
		if(usedmems[i] == ptr) {
			j = respectiveBuffs[i]; 
			freebuf((char *)ptr);
			break;
		}
	}

	//For bookkeeping, get the used size in this memory location and
	//subtract it from the appropriate used buffer pool memory, decrement
	//the number of allocated buffers for that pool, set the memory
	//tracking index to be zero in the saved memory addresses, and zero
	//out the used memory and respective buffer for that index as well
	int size = respectiveMems[i];
	usedMemPerBP[j] -= size;
	allocBuffsPerBP[j] -= 1;
	usedmems[i] = (char *)0;
	respectiveMems[i] = 0;
	respectiveBuffs[i] = 0;
	
	return;
}

char* xheap_snapshot() {
	
	//Index for each buffer pool as well as the number of pools that exist
	//in it
	int i = 0, numpools = 256;
	//An empty string builder
	char retVal[4200] = "";
	//Keeps track of the actual buffer pool for ease of access
 	struct bpentry *curr;
	
	//For each buffer pool:
	for (i; i < 8; i++) {
		//We need string builders to store appropriate output information
		char pid[50], buffsiz[50], totbuffs[50], allocbyts[50], 
			allocbuffs[50], fragbyts[50], thisIt[400];
		//Set the buffer pool pointer
		curr = &buftab[xmalloc_buffs[i]];

		//Save appropriate data for the screenshot to the appropriate
		//string builder
		sprintf(pid, "pool_id= %d, ", xmalloc_buffs[i]);
		sprintf(buffsiz, "buffer_size= %d, ", curr->bpsize);
		sprintf(totbuffs, "total_buffers= %d, ", numpools);
		sprintf(allocbyts, "allocated_bytes= %d, ", usedMemPerBP[i]);
		sprintf(allocbuffs, "allocated_buffers= %d, ", allocBuffsPerBP[i]);
		sprintf(fragbyts, "fragmented_bytes= %d, ", 
			allocBuffsPerBP[i] * curr->bpsize - usedMemPerBP[i]); 
		sprintf(thisIt, "%s%s%s%s%s%s\n", pid, buffsiz, totbuffs, 
			allocbyts, allocbuffs, fragbyts);
		//Add all the string builders for this iteration of the buffer
		//pools to the return value and halve the number of pools (since
		//it will always follow this pattern in my implementation)
		strncat(retVal, thisIt, strlen(thisIt)); 
		
		numpools = numpools / 2;
	}
	//Return the string builder
	return retVal;
}
