#include <xinu.h>
#include <kv.h>

//Data structure of a singly linked list cache, and global variables to hold
//information needed for kv_get_cache_info
struct sllNode *cache;
int cacheHits, cacheAccesses, cacheSets, cacheSize, cacheKeys, cacheEvicts;

//Gets the value associated with the key (if any)
char* kv_get(char* key) {
	
	//prev and curr nodes for list traversal/rearranging if a node
	//is found with the key
	struct sllNode *prev = cache, *curr = cache->next;
	int i = cacheKeys;
	//Since a get request takes place, increment total get requests
	cacheAccesses++;
	//WHile there are still nodes in the list:
	while(i > 0) {
		//If the current node's key and the function's key match
		if (strcmp(curr->key, key) == 0) {
			//Increment the number of successful hits
			cacheHits++;
			//Reset the pointers 
			prev->next = cache->next;
			curr->next = cache->next;
			cache->next = curr;
			return curr->val;
		}
		//If the keys dont match, then increment the node pointers 
		prev = curr;
		curr = curr->next;
		i--;
	}
	//if nor match was found, simply return null
        return (char* )NULL;
}

//Sets a key-value association in the cache.
int kv_set(char* key, char* value) {
	//First checks that the key and value sizes are less than the
	//described limits in the project description
        if (sizeof(key) > 64) {
                printf("Key size is too large.\n");
                return 1;
        }
        if (sizeof(value) > 1000) {
                printf("Value size is too large.\n");
                return 1;
        }
	
	//defines a previous, current, and new node to use for traversing
	//the cache to ensure that if found, we can re locate the node
	//sinc ethe cache is a LRU list as well.
	struct sllNode *new, *prev = cache, *curr = prev->next;
	int i = cacheKeys;
	//WHile we have not traversed all of the nodes:
	while ( i > 0 ) {
		//Found the key in the mapping
		//never tests if semaphore count for val allows access
		if (strcmp(*(curr->key), key) == 0) {
			//Decrements the cache size by the value stored in the 
			//node since it will be overwritten, then free the 
			//value's location in memory.
			cacheSize -= sizeof(*(curr->val));
			xfree(curr->val);
			//Allocate memory for the new value to be stored, set
			//its value ot value, and then increment the cache size
			//by the size of the new value
			curr->val = xmalloc(sizeof(value));
			*(curr->val) = value;
			cacheSize += sizeof(value);
			//Readjust pointers such that the current node moves
			//to the front of the LRU list
			prev->next = curr->next;
			curr->next = cache->next;
			cache->next = curr;
			//increment the global number of cache sets
			cacheSets++;
			return 0;
		}
		//If the current node doesnt hold the key, then increase
		//the node pointers by one link and decrement the count of
		//remaining nodes
		prev = curr;
		curr = curr->next;
		i--;
	}
	//Allocate memory block for a new node, key, and value 
	//didnt test semaphore count for a new node, new key, and new value
	new = (struct sllNode*)xmalloc(sizeof(struct sllNode));
	char *keyPtr = xmalloc(sizeof(key)), *valPtr = xmalloc(sizeof(value));
	//Set the key and value to the provided values
	keyPtr = key;
	valPtr = value;
	//Set the key and vlaues within the node
	new->key = keyPtr;
	new->val = valPtr;
	//Set the node after the head of the queue
	new->next = cache->next;
	cache->next = new;

	//Increment the cache size by the node, key, and value size, and 
	//increment the count of sets and keys.
	cacheSize += sizeof(key) + sizeof(value) + sizeof(new);
	cacheKeys++;
 	cacheSets++;
        return 0;
}

//Deletes an association if one exists
bool kv_delete(char* key) {
	//Nodes to use for traversal and pointer rearranging if the key is
	//found and a count of how many nodes exist.
        struct sllNode *prev = cache, *curr = cache->next;
        int i = cacheKeys;
        
	//While there are still nodes left to check:
        while(i > 0) {
		//IF the key of the current node matches the inquired key:
                if (strcmp(*(curr->key), key) == 0) {
			//Remove the current node from the path of the list
                        prev->next = curr->next;
			//Decrement the key count and queue memory size count
			cacheKeys--;
			cacheSize = cacheSize - sizeof(*key) - sizeof(*(curr->val)) - sizeof(struct sllNode*);
                        //Free the allocated value, key, and node memory locations
			xfree(curr->key);
			xfree(curr->val);
			xfree(curr);
			return 1;
                }
		//If no match, keep walking the list
                prev = curr;
                curr = prev->next;
                i--;
        }
	//If no match for the key was fount, return 0
        return 0;
}

//Resets the cache to empty and resets all global variables
void kv_reset() {

	//Nodes to keep track of nodes we are erasing
	struct sllNode *curr = cache->next, *next =curr->next;
        int i = cacheKeys;
	//While nodes still exist
        while(i > 0) {
		//Free the key, value, and node memory locations in memory
		xfree(curr->key);
		xfree(curr->val);
		xfree(curr);
		//Set the current node to be the chronological next
		curr = next;
		//Increment the next node if one exists
		if (i > 1)
			next = curr->next;
                i--;
        }
	//Reset the global variables to their defaults as shown in kv_init((
	cacheKeys = 0;
	cacheSize = sizeof(cache);
	cache->next = NULL;
	cacheHits = 0;
	cacheAccesses = 0;
	cacheSets = 0;
	cacheEvicts = 0;
	return;
}

//Initialization of the cache structure
int kv_init() {
	//Must start by initializing xmalloc from the previous assignmenr
	//(this assignment showed me that my implementation is broken)
	xmalloc_init();

	//Initialize a node cache head node using my xmalloc function and
	//the defined struct in ../include/kv.h
	cache = (struct sllNode*)xmalloc(sizeof(struct sllNode));
	//Initialize all global variables needed for kv_get_cache_info
	cacheKeys = 0;
	cacheSize = sizeof(cache);
	cacheHits = 0;
	cacheAccesses = 0;
	cacheSets = 0;
	cacheEvicts = 0;
	return 0;
}

//Returns info associated with the cahce based off of user entered parameter
//"kind"
int get_cache_info(char* kind) {
	//Returns the value of the appropriate global variable with respect to
	//"kind" inquiry
	if (strcmp(kind, "total_hits") == 0)
		return cacheHits;
	if (strcmp(kind, "total_accesses") == 0)
		return cacheAccesses;
	if (strcmp(kind, "total_set_success") == 0)
		return cacheSets;
	if (strcmp(kind, "cache_size") == 0)
		return cacheSize;
	if (strcmp(kind, "num_keys") == 0)
		return cacheKeys;
	if (strcmp(kind, "total_evictions") == 0)
		return cacheEvicts;
	return -1;
}

//Should return the k most popular keys (i.e. the first k nodes of 
//the LRU cache
char** most_popular_keys(int k) {
	//A current node to keep track of which key to store in the return
	struct sllNode *curr = cache->next;
	//an incrementor i, and then a limit on how far i can increment
	//based off of the minimum value of the number of keys existing
	//in the cache and k
	int i = 0, its = k < cacheKeys ? k : cacheKeys;
	//The array of strings to return
	char* keys[its];
	//For every iteration of i, the current node's value is added to 
	//the return array, and then the current node is incremented
	for( i; i < its; i++) {
		keys[i] = curr->key;
		curr = curr->next;
	}
	//Returns the keys
	return keys;
}
