#include <xinu.h>
#include <string.h>
#include <future.h>

//These four first functions are my own in order to use my own queue
//data structure (singly linked list), node_t defined in futures.h
node_t* new_list() {
	//For a new list: create a head node and set its values to null, return
	//the head
	node_t* head = (node_t *)getmem(sizeof(node_t));
	head->pid = NULL;
	head->next = NULL;
	return head;
}

pid32 dequeue_node(node_t * head) {
	//To dequeue a node, take the next one (I always want to keep the head),
	//and set the head equal to the next's head, return the pid of the
	//removed node and free the memory
	node_t *curr = head->next;
	if (curr == NULL)
		return 0;

	head->next = curr->next;
	pid32 pid = curr->pid;
	freemem((char *)curr, sizeof(curr));
	return pid;
}

void enqueue_node(pid32 pid, node_t *head) {
	//To enqueue a node, traverse the "next" elements until the next would
	//be null. Then, allocate enough memory for a new node and set the 
	//parameters appropriately
	node_t *curr = head;
	while (curr->next != NULL) 
		curr = curr->next;

	curr->next = (node_t *)getmem(sizeof(node_t));
	curr->next->pid = pid;
	curr->next->next = NULL;
}

//SImpy return if the list is empty by looking to see if the head has a 
//next node
bool is_empty_list(node_t *head) {
	return head->next == NULL;
}

future_t* future_alloc(future_mode_t mode) {

	//Allocates enough memory to hold all of the future_t struct
	//and then sets all available values, returns the future
	future_t *fut = (future_t* )getmem(sizeof(future_t));
	fut->state = FUTURE_EMPTY;
	fut->mode = mode;
	fut->get_queue = new_list();
	fut->set_queue = new_list();
	return fut;
}

syscall future_free(future_t* f) {

	//Defers rescheduling and then clears all of the queues of the 
	//future. Then stops deferring and frees the memory
	intmask mask;
	mask = disable();
	resched_cntl(DEFER_START);
	while (!is_empty_list(f->set_queue))
		ready(dequeue_node(f->set_queue));	
	while (!is_empty_list(f->get_queue)) 
		ready(dequeue_node(f->get_queue));
	resched_cntl(DEFER_STOP);
	restore(mask);
	freemem((char *)f, sizeof(f));
	return OK;

}

syscall future_get(future_t* f, int* value) {

	//Test if there shouldnt be anything waiting on this future
	if (f->state == FUTURE_WAITING && f->mode == FUTURE_EXCLUSIVE)
		return SYSERR;
	intmask mask;
	mask = disable();

	//Saves the process' entry in the proctab in case it needs to wait
	struct procent *prptr = &proctab[currpid];
	//Will need to wait for the setter if the state is not ready (and we
	//are not sharing futures), or if we are sharing futures and the state
	//is empty (if it is ready or waiting, then a producer has already 
	//set the future)
	if ((f->mode != FUTURE_SHARED && f->state != FUTURE_READY) || 
		(f->mode == FUTURE_SHARED && f->state==FUTURE_EMPTY) ||
		!is_empty_list(f->get_queue)) {
		prptr->prstate = PR_WAIT;
		enqueue_node(currpid, f->get_queue);
		resched();
	}

	//Set the value and state that the consumer has gathered the future
	*value = f->value;
	f->state = FUTURE_WAITING;

	//If a producer is waiting, release the longest waiting one
	if (!is_empty_list(f->set_queue))
		ready(dequeue_node(f->set_queue));
	//If the state is shared and there are waiting consumers, release one
	if (f->mode == FUTURE_SHARED && !is_empty_list(f->get_queue))
		ready(dequeue_node(f->get_queue));
	restore(mask);
	return OK;
}

syscall future_set(future_t* f, int value) {

	//If only one producer is allowed and the state is waiting (even though)
	//changing to the waiting state only occurs when a consumer has taken
	//a value, return syserr
	if (f->mode != FUTURE_QUEUE && f->state == FUTURE_WAITING)
		return SYSERR;

	intmask mask;
	mask = disable();
	
	struct procent *prptr = &proctab[currpid];
	//If a producer has already read the future (free and waiting imply
	//that one hasnt), then wait
	if (f->state == FUTURE_READY) {
		prptr->prstate = PR_WAIT;
		enqueue_node(currpid, f->set_queue);
		resched();
	}

	//Set the value and state appropriately
	f->state = FUTURE_READY;
	f->value = value;

	//If there are waiting consumers, then release one
	if (!is_empty_list(f->get_queue))
		ready(dequeue_node(f->get_queue));

	restore(mask);
	return OK;
}
