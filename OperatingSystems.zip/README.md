# Welcome to Xinu

# Build instructions

Copy the file config/Makedefs.EXAMPLE to config/Makedefs and make appropriate changes if necessary.
