pp2code version 1.0 10/10/2018

-----------------------------------------------------------
GENERAL USE NOTES
-----------------------------------------------------------
-Code was compiled and drafted using the Spyder
 IDE for Python 3.4 that came with Anaconda
 Navigator

-All dependent files must be in a subdirectory called pp2data 
 which is located in the same directory that the code is being 
 executed from. In addition, all dependent files must follow the 
 format: test-?.csv, testR-?.csv, train-?.csv, and trainR-?.csv
 for all data sets to be trained and tested. Regressed target 
 values should be in a single column and examples should be in rows
 of a matrix, with attributes in columns

-Code is available in files PP2_part1.py, PP2_part2.py, PP2_part3.py
 and PP2_part4.py which all correspont to appropriate experiments in 
 the project assignment.

-In order to use the code for parts 1, 3, and 4, you can decide what
 files to train/test by changing the descriptor variable at the
 top of each file to the descriptor placeheld by the "?" above. 
 Remember, every descriptor should have the four files fitting the
 forms enumerated above or the code will not work.

------------------------------------------------------------
USE OF CODE FILES
------------------------------------------------------------
-Execute code via IDE or linux system. 

 In an IDE use run command. This is by far the best performing option
 since math plots are allowed and correct output was generated for me
 as opposed to on the Tank SICE server.

 From Linux terminal (That allows use of matplotlib), use command
    >python ./path/to/file
 granted the file is given appropriate permissions and graphical
 displays are allowed. On the Tank server where I tested this code, 
 matplotlib caused the program to fail every time, and then when 
 commented out, as well as the plotting lines, the calculations of MSE
 were zero, which is not what I get when running on my own machine.

-Must have random, numpy, and matplotlib libraries installed.
 can be installed via Anaconda's website: 
     https://www.anaconda.com/download/
 or on Linux systems:
     python -m pip install --user matplotlib math numpy



For any questions contact: cudevine@indiana.edu