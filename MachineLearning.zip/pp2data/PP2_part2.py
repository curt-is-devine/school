#! /usr/bin/env python
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import random

#File descriptor for ease of access in testing for other data sets
descrip = "1000-100"

#find files that correspond to training data and test data
matrixFile = "pp2data/train-"+descrip+".csv"
trainTFile = "pp2data/trainR-"+descrip+".csv"
testFile = "pp2data/test-"+descrip+".csv"
testTFile = "pp2data/testR-"+descrip+".csv"

#makes the phi matrix of attributes for the data set, the size of the sample and number of categories based off 
#dimensions of phi, and seting result vector (need to transpose to make a column vector)
phi = np.matrix(np.genfromtxt(matrixFile, delimiter = ','))
(trN, trM) = phi.shape
t = np.transpose(np.matrix(np.genfromtxt(trainTFile, delimiter = ',')))

#Same as above for test matrices
testPhi = np.matrix(np.genfromtxt(testFile, delimiter = ','))
(teN, teM) = testPhi.shape
testT = np.transpose(np.matrix(np.genfromtxt(testTFile, delimiter = ',')))

#arrays of sizes of randomly selected data to create the learning curve (I test every 5th size for smoothness of the plot),
#an array of row numbers to use for generation of random data entries for the learning curve, and my "too small", 
#"just right", and "too large" values of lambda to use for these calculations
sizes = range(10, 800, 5)
rows = range(trN)
lambdas = [1, 22, 140]

#For each lambda I chose: Print which lambda I am using
for l in lambdas:
    print("lambda = " + str(l))
    
    #Calculate lambda * I and sets an array to hold MSE values for the plot of this lambda for each size
    lambdaI = np.diag([l] * trM)
    testMSEs = []
    
    #for each size in my array: create an MSE array to average later for this size
    for size in sizes:
        trialMSEs = []
        
        #For 10 trials:
        for repeat in range(10):
            
            #Extracts different samples
            indices = random.sample(rows, size)
                
            #Calculate subset data needed to calculate the new W matrixd
            subset = phi[indices,:]
            tSet = t[indices,:]
            subsetT = np.transpose(subset)            
            
            w = np.linalg.inv(lambdaI + (subsetT * subset)) * subsetT * tSet
            #Calculate the sum term of MSE and then divide by the number of testing examples
            MSESum = 0
            for j in range(teN):
                MSESum += (testPhi[j,:] * w - testT[j,0])[0,0]**2
            trialMSEs.append(1/teN * MSESum)
        #Add the mean MSE for this size to smooth out the curve
        testMSEs.append(sum(trialMSEs)/10)
    #Plot the MSE curve as a functino of example size for each lambda
    plt.plot(sizes, testMSEs)
    plt.show()