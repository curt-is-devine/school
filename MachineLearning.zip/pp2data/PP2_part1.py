#! /usr/bin/env python
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt

#Type in file descriptor here
descrip = "crime"

#find files that correspond to training data and test data
matrixFile = "pp2data/train-"+descrip+".csv"
trainTFile = "pp2data/trainR-"+descrip+".csv"
testFile = "pp2data/test-"+descrip+".csv"
testTFile = "pp2data/testR-"+descrip+".csv"

#The phi matrix of testing attributes
phi = np.matrix(np.genfromtxt(matrixFile, delimiter = ','))
#size of the sample and number of categories respectively based off of the shape of phi
(trN, trM) = phi.shape
#transpose of phi
phiT = np.transpose(phi)
#sets result vector (need to transpose to make a column vector)
t = np.transpose(np.matrix(np.genfromtxt(trainTFile, delimiter = ',')))

#Same as above for the test set. Do not need the transpose of phi for any calculations w.r.t. test set
testPhi = np.matrix(np.genfromtxt(testFile, delimiter = ','))
(teN, teM) = testPhi.shape
testT = np.transpose(np.matrix(np.genfromtxt(testTFile, delimiter = ',')))

#Arrays to hold the training and test MSEs and lambda values to test
trainMSEs = []
testMSEs = []
lambdas = range(151)

for l in lambdas:
    #Sets up a diagonal array of the lambdas
    lambdaI = np.diag([l] * trM)
    
    #Calculates w matrix
    w = np.linalg.inv(lambdaI + (phiT * phi)) * phiT * t
    
    #Running sum for the MSE of training and test sets respectively
    trainingSum = 0
    testingSum = 0
    #Calculation of MSE formula for both testing and training sets, using appropriate t and phi when needed
    for j in range(trN):
        trainingSum += (phi[j,:] * w - t[j,0])[0,0]**2
    trainMSEs.append(1/trN * trainingSum)  
    for j in range(teN):
        testingSum += (testPhi[j,:] * w - testT[j,0])[0,0]**2
    testMSEs.append(1/teN * testingSum)
    
#Added this because the "100-100" data set was VERY bad for lambda = 0 to the point that interesting apects
#Of the graph could not be easily seen.
if descrip == "100-100": 
    plt.plot(lambdas, trainMSEs, lambdas[1:], testMSEs[1:])
else:
    plt.plot(lambdas, trainMSEs, lambdas, testMSEs)
#Plots training and testing MSE values as a function of lambda on the same plot. Higher line is testing data, lower is training
plt.show()
print(testMSEs)