#! /usr/bin/env python
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import random

#Descriptor that we care about, then collects all files that relate to that file
descrip = "f5"

matrixFile = "pp2data/train-"+descrip+".csv"
trainTFile = "pp2data/trainR-"+descrip+".csv"
testFile = "pp2data/test-"+descrip+".csv"
testTFile = "pp2data/testR-"+descrip+".csv"

#Function to generate a phi of some degree based on the x values given
def generatePhi(xes, degree):
    #Start with an empty array and get dimensions of the x vector to use for indexing
    newMatrix = []
    n, m = xes.shape
    for row in range(m):
        #For each entry, create a new row of all powers of that x value and add it to the above array
        newRow = []
        for deg in range(degree + 1):
            newRow.append(xes[0, row]**deg)
        newMatrix.append(newRow)
    #return the array as a matrix
    return np.matrix(newMatrix)

#Functions to succinctly calculate the m_N, s_N, alpha, beta, and gamma values based on the book equations
def newM_N(t, phiT, s_N, beta):
    return beta * s_N * phiT * t

def newS_N(phi, phiT, columns, alpha, beta):
    return np.linalg.inv(np.diag([alpha] * columns) + beta * phiT * phi)

def newAlpha(gamma, m_N):
    return gamma/(np.transpose(m_N) * m_N)[0,0]

def newBeta(phi, t, N, m_N, gamma ):
    denom = N - gamma
    tot = 0
    for row in range(N):
        t_n = t[row,0]
        m_N_T = np.transpose(m_N)
        phi_xN = np.transpose(phi[row,:])
        tot += (t_n - m_N_T * phi_xN)[0,0]**2 
    return denom/tot

def newGamma(alpha, evalues):
    tot = 0
    for evalue in evalues:
        tot += evalue/(alpha + evalue)
    return tot

#Collects data needed to generate polynomial phi matrices for the training and test data and their target values
xes = np.matrix(np.genfromtxt(matrixFile, delimiter = ','))
t = np.transpose(np.matrix(np.genfromtxt(trainTFile, delimiter = ',')))
testXes = np.matrix(np.genfromtxt(testFile, delimiter = ','))
testT = np.transpose(np.matrix(np.genfromtxt(testTFile, delimiter = ',')))

#Arrays to hold degrees to be testing, log evidence values, and MSE values for regularized and non-regularized methods
degrees = range(1, 10)
logEvidence = []
MSEReg = []
MSENonReg = []

#Makes the whole N x 10 matrix for training and testing data, which will be reduced to only the degrees needed
finalPhi = generatePhi(xes, 10)
finalTestPhi = generatePhi(testXes, 10)

#For each degree in question
for d in degrees:
    
    #Create the phi matrix of that degree and extract important information for later calculations
    phi = finalPhi[:,range(d+1)]
    (trN, trM) = phi.shape
    phiT = np.transpose(phi)
    
    #Do the same for the testing matrix
    testPhi = finalTestPhi[:,range(d+1)]
    (teN, teM) = testPhi.shape
    
    #Initialize all values needed to calculate m_N
    alpha = random.randint(1, 10)
    beta = random.randint(1, 10)
    m_N = 0
    s_N = 0
    evalues = 0
    gamma = 0 

    #Iterate and update all of these values 15 times for convergence in the bayes method
    for it in range(15):
        evalues = np.linalg.eigvals(beta * phiT * phi)
        gamma = newGamma(alpha, evalues)
        s_N = newS_N(phi, phiT, trM, alpha, beta)
        m_N = newM_N(t, phiT, s_N, beta)
        alpha = newAlpha(gamma, m_N)
        beta = newBeta(phi, t, trN, m_N, gamma)
        
    #From the equation in the book, calculate intermediate functions/values and then proceed to calculate the error function
    Em_N = beta/2 * np.linalg.norm(t - phi * m_N)**2 + alpha/2 * np.transpose(m_N) * m_N
    A = np.diag([alpha] * trM) + beta * phiT * phi
    logEvidence.append(d/2 * np.log(alpha) + trN/2 * np.log(beta) - Em_N[0,0] - 1/2 * np.log(np.linalg.det(A)) - trN/2 * np.log(2 * np.pi))
    
    #Calculate w for the non regularized MSE values
    w = np.linalg.inv(phiT * phi)*phiT * t
    
    #Running totals for regularized and non regularized MSEs, using m_N and w respectively
    resReg = 0 
    resNonReg = 0
    for j in range(teN):
        resReg += (testPhi[j,:] * m_N - testT[j,0])[0,0]**2
        resNonReg += (testPhi[j,:] * w - testT[j,0])[0,0]**2
    MSEReg.append(1/teN * resReg)
    MSENonReg.append(1/teN * resNonReg)

#Plot on seperate graphs since the evidence function is extremely small compared to the MSE functions
plt.plot(degrees, logEvidence)
plt.show()  
plt.plot(degrees, MSEReg, degrees, MSENonReg)
plt.show()