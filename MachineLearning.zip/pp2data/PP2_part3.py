#! /usr/bin/env python
import numpy as np
import random

#Set file descriptor here, uses the term that changes among the files in our data sets
descrip = "100-10"

matrixFile = "pp2data/train-"+descrip+".csv"
trainTFile = "pp2data/trainR-"+descrip+".csv"
testFile = "pp2data/test-"+descrip+".csv"
testTFile = "pp2data/testR-"+descrip+".csv"

#Functions to succinctly calculate the m_N, s_N, alpha, beta, and gamma values based on the book equations
def newM_N(t, phiT, s_N, beta):
    return beta * s_N * phiT * t

def newS_N(phi, phiT, columns, alpha, beta):
    return np.linalg.inv(np.diag([alpha] * columns) + beta * phiT * phi)

def newAlpha(gamma, m_N):
    return gamma/(np.transpose(m_N) * m_N)[0,0]

def newBeta(phi, t, N, m_N, gamma):
    denom = N - gamma
    tot = 0
    for row in range(N):
        t_n = t[row,0]
        m_N_T = np.transpose(m_N)
        phi_xN = np.transpose(phi[row,:])
        tot += (t_n - m_N_T * phi_xN)[0,0]**2 
    return denom/tot

def newGamma(alpha, evalues):
    tot = 0
    for evalue in evalues:
        tot += evalue/(alpha + evalue)
    return tot

#makes the phi matrix of values, Calculates the size of the sample and number of categories based off dimensions,
#Calculates transpose of phi, and sets result vector (need to transpose to make a column vector)
phi = np.matrix(np.genfromtxt(matrixFile, delimiter = ','))
(trN, trM) = phi.shape
phiT = np.transpose(phi)
t = np.transpose(np.matrix(np.genfromtxt(trainTFile, delimiter = ',')))

#Same as above for the testing data
testPhi = np.matrix(np.genfromtxt(testFile, delimiter = ','))
(teN, teM) = testPhi.shape
testT = np.transpose(np.matrix(np.genfromtxt(testTFile, delimiter = ',')))

#Initialize alpha and beta randomly in the range 1 to 10 and initialize values needed for calculating of m_N 
#These values can be initialized ot whatever since they are about to be set to real values in the loop
alpha = random.randint(1, 10)
beta = random.randint(1, 10)
evalues = 0
gamma = 0
s_N = 0
m_N = 0

#Assume that 15 iterations will be fine for calculating alpha nad beta since we were told that convergence occurs
#Very rapidle
for it in range(15):
    #Calculate eigenvalues (to be used in gamma calculation), gamma (to be used in alpha and beta calculations), 
    #s_N (to be used in m_N calculation), m_N (which will eventually act as our w matrix upon convergence), alpha,
    #and beta, which are used in the S_N and eigenvalue calculations
    evalues = np.linalg.eigvals(beta * phiT * phi)
    gamma = newGamma(alpha, evalues)
    s_N = newS_N(phi, phiT, trM, alpha, beta)
    m_N = newM_N(t, phiT, s_N, beta)
    alpha = newAlpha(gamma, m_N)
    beta = newBeta(phi, t, trN, m_N, gamma)
  
#Once converged, calculate MSE with w as the expected value from MAP
testSum = 0 
for j in range(teN):
    testSum += (testPhi[j,:] * m_N - testT[j,0])[0,0]**2
print(1/teN * testSum)
