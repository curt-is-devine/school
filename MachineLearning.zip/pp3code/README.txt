pp3code version 1.0 11/5/2018

-----------------------------------------------------------
GENERAL USE NOTES
-----------------------------------------------------------
-Code was compiled and drafted using the Spyder
 IDE for Python 3.4 that came with Anaconda
 Navigator

-All dependent files must be in a subdirectory called pp3data 
 which is located in the same directory that the code is being 
 executed from. In addition, all dependent files must follow the 
 format: ?.csv for examples and labels-?.csv for the respective labels
 for all data sets. examples should be in rows of a matrix, with 
 attributes in columns

-Code is available in files PP3_Part1.py and PP3_Part2.py
 which all correspond to appropriate experiments in 
 the project assignment.

-In order to use the code you can decide what
 files to investigate by changing the descriptor variable at the
 top of each file to the descriptor placeheld by the "?" above. 
 Remember, every descriptor should have the two files fitting the
 forms enumerated above or the code will not work.

------------------------------------------------------------
USE OF CODE FILES
------------------------------------------------------------
-Execute code via IDE or linux system. 

 In an IDE use run command. This is by far the best performing option
 since math plots are allowed and correct output was generated for me
 as opposed to on the Tank SICE server, in which case comment out
 the final couple of lines of code corresponding to the plots
 at the end of each script

 From Linux terminal (That allows use of matplotlib), use command
    >python ./path/to/file
 granted the file is given appropriate permissions and graphical
 displays are allowed. On the Tank server where I tested this code, 
 matplotlib caused the program to fail every time.

-Must have random, numpy, time, and matplotlib libraries installed.
 can be installed via Anaconda's website: 
     https://www.anaconda.com/download/
 or on Linux systems:
     python -m pip install --user matplotlib math numpy



For any questions contact: cudevine@indiana.edu