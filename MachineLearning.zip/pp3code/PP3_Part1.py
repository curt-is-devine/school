#! /usr/bin/env python
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import random

#Type in file descriptor here
descrip = "B"

#find files that correspond to features and labels
featuresFile = "pp3data/"+descrip+".csv"
labelsFile = "pp3data/labels-"+descrip+".csv"

#The phi array of example attributes
features = np.genfromtxt(featuresFile, delimiter = ',')
#sets label array
t = np.genfromtxt(labelsFile, delimiter = ',')
#The number of total examples provided
N = len(features)

#Instructed to limit our test set to a third of the provided examples
testSize = N//3
#The training set sizes that will be used for the experiment of training set size as a function of error
trainingSizes = [size for size in range(50, N - testSize, 25)]
#Arrays to hold the errors of the intermediate results for each training size
genErrorsPerSize = [[] for i in range(len(trainingSizes))]
discErrorsPerSize = [[] for i in range(len(trainingSizes))]

#constants needed for Bayesian Logistic Regression
alpha = 0.1
alphaI = np.matrix(np.diag([alpha for i in range(len(features[0]) + 1)]))

#Repeat 30 times
for repeat in range(30):
    
    #Extract a random sample of indices of the feature/label sets to use as test data
    testIndices = random.sample(range(N), testSize)
    #Sets array for feature and label sets for the training and test data
    trainFeaturesSet = []
    trainLabelSet = []
    testFeaturesSet = []
    testLabelSet = []
    for i in range(N):
        if i not in testIndices:
            trainFeaturesSet.append(list(features[i]))
            trainLabelSet.append([t[i]])
        else:
            testFeaturesSet.append(list(features[i]))
            testLabelSet.append([t[i]])

    #Makes the test attributes into matrices since they will be uniform for each training set size
    testFeaturesSet = np.matrix(testFeaturesSet)
    bayesTestFeats = np.c_[np.ones(testSize), testFeaturesSet]
    testLabelSet = np.matrix(testLabelSet)
    
    #For each training Size:
    for trainingSize in trainingSizes:
        
        #Set the matrices for features and labels each iteration (per the instructions)
        trainIndices = random.sample(range(len(trainFeaturesSet)), trainingSize)
        trainFeaturesSubset = []
        trainLabelsSubset = []
        for i in trainIndices:
            trainFeaturesSubset.append(trainFeaturesSet[i])
            trainLabelsSubset.append(trainLabelSet[i])
        trainingFeatures = np.matrix(trainFeaturesSubset)
        bayesFeatures = np.c_[np.ones(trainingSize), trainingFeatures]
        trainingLabels = np.matrix(trainLabelsSubset)
        
        #Maximum Likelihood Approximation of Linear Regression---------------------------------------------------
        #constants to use for calculation of the mus for linear regression
        sum0 = 0
        sum1 = 0
        n0 = 0
        n1 = 0
        n = trainingSize
        for i in range(n):
            if trainingLabels[i,0] == 0:
                if n0 == 0:
                    sum0 = trainingFeatures[i]
                else:
                    sum0 = sum0 + trainingFeatures[i]
                n0 += 1
            else:
                if n1 == 0:
                    sum1 = trainingFeatures[i]
                else:
                    sum1 = sum1 + trainingFeatures[i]
                n1 += 1
        mu0 = sum0 * 1/n0
        mu1 = sum1 * 1/n1
        
        #Same as above for calculation of the shared covariance matrix per the book's formulas
        s0 = 0
        emptys0 = True
        s1 = 0
        emptys1 = True
        for i in range(n):
            if trainingLabels[i,0] == 0:
                if emptys0:
                    s0 =  np.transpose((trainingFeatures[i] - mu0)) * (trainingFeatures[i] - mu0)
                    emptys0 = False
                else:
                    s0 = s0 +  np.transpose((trainingFeatures[i] - mu0)) * (trainingFeatures[i] - mu0)
            else:
                if emptys1:
                    s1 = np.transpose((trainingFeatures[i] - mu1)) * (trainingFeatures[i] - mu1)
                    emptys1 = False
                else:
                    s1 = s1 +  np.transpose((trainingFeatures[i] - mu1)) * (trainingFeatures[i] - mu1)
            
        s0 = 1/n0 * s0
        s1 = 1/n1 * s1
        s = n0/n * s0 + n1/n * s1
        sInv = s.I
        w = sInv * np.transpose(mu0 - mu1)
        #I assume in this line that the probability of each class is simply the ratio of its occurances with respect to 
        #total examples.
        w_0 = -0.5 * mu0 * sInv * np.transpose(mu0) + 0.5 * mu1 * sInv * np.transpose(mu1) + np.log(n0/n1)
        
        #Bayesian Logistic Regression -----------------------------------------------------------------------------------
        #Start by calculating the next iteration of w since we cannot divide by zero in our limit to how many times
        #We compare the previous w with the current 
        w_prev = -(alphaI + np.transpose(bayesFeatures) * np.diag([0.25 for i in range(n)]) * bayesFeatures).I * (np.transpose(bayesFeatures) * (np.transpose(np.matrix([0.5 for i in range(n)]))-trainingLabels))
        #y is the matrix of sigmoid values for the product of the transpose of w and each example
        y = np.transpose(np.matrix([1/(1+np.exp((-np.transpose(w_prev) * np.transpose(bayesFeatures[i]))[0,0])) for i in range(n)]))
        #R is the diagonal matrix of y values for each example mulitpilied by its difference from one
        R = np.diag([y[i,0]*(1-y[i,0]) for i in range(n)])
        #Calculate the next iteration of w using the previously defined constants and above defined matrices per the instructions
        w_next = w_prev - (alphaI + np.transpose(bayesFeatures) * R * bayesFeatures).I * (np.transpose(bayesFeatures) * (y - trainingLabels) + alpha * w_prev)
        #since we have updated w twice, we start at the second iteration
        itNum = 2
        #While the w matrices are not converging and we have not iterated 100 times:
        while np.linalg.norm(w_next - w_prev)/np.linalg.norm(w_prev) > 0.01 and itNum < 100:
            #Set the previous w to the current 
            w_prev = w_next
            #Recalculate y and R using this new w
            y = np.transpose(np.matrix([1/(1+np.exp((-np.transpose(w_prev) * np.transpose(bayesFeatures[i]))[0,0])) for i in range(n)]))
            R = np.diag([y[i,0]*(1-y[i,0]) for i in range(n)])
            #and update the w, incrementing the iterations by one
            w_next = w_prev - (alphaI + np.transpose(bayesFeatures) * R * bayesFeatures).I * (np.transpose(bayesFeatures) * (y - trainingLabels) + alpha * w_prev)
            itNum += 1
        #Now we have the w matrix
        
        #Error Calculation ------------------------------------------------------------------------
        #Success counts for each method above
        linSucCount = 0
        baySucCount = 0
        #For each test case:
        for i in range(testSize):
            #if the sigmoid correctly classifies the example with the linear regression w, increment the success count
            if ((1/(1+np.exp(-(np.transpose(w) * np.transpose(testFeaturesSet[i]) + w_0)))) >= 0.5 and testLabelSet[i, 0] == 0) or \
            ((1/(1+np.exp(-(np.transpose(w) * np.transpose(testFeaturesSet[i]) + w_0)))) < 0.5 and testLabelSet[i, 0] == 1):
                linSucCount += 1
            #Same as above, but for the logistic regression based w
            if ((1/(1 + np.exp(-np.transpose(w_next) * np.transpose(bayesTestFeats[i])))) >= 0.5 and testLabelSet[i, 0] == 1) or \
            ((1/(1 + np.exp(-np.transpose(w_next) * np.transpose(bayesTestFeats[i])))) < 0.5 and testLabelSet[i,0] == 0):
                baySucCount += 1
        #A simple reference used to update the appropriate error in each of the global error tracking arrays
        j = trainingSizes.index(trainingSize)
        genErrorsPerSize[j].append((testSize - linSucCount)/testSize)
        discErrorsPerSize[j].append((testSize - baySucCount)/testSize)
    
#Calculate the generative errors and discriminate errors from the error tracking arrays for each testing size    
genMeans = []
discMeans = []
for i in range(len(trainingSizes)):
    genMeans.append(sum(genErrorsPerSize[i])/30)
    discMeans.append(sum(discErrorsPerSize[i])/30)

#Same as above but for sample standard deviation  
genSDs = []
discSDs = []
for i in range(len(trainingSizes)):
    genSDs.append(np.std(genErrorsPerSize[i], ddof = len(genErrorsPerSize[i]) - 1))
    discSDs.append(np.std(discErrorsPerSize[i], ddof = len(discErrorsPerSize[i]) - 1))
#Prints the standard deviations since I did not have enough time to figure out how to add error bars to my plots correctly    
print(genSDs)
print(discSDs)
#Plots the mean errors as a function of training set size
plt.plot(trainingSizes, genMeans, trainingSizes, discMeans)
plt.show()
