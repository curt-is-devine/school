#! /usr/bin/env python
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import time

#Type in file descriptor here
descrip = "A"

#find files that correspond to features and labels
featuresFile = "pp3data/"+descrip+".csv"
labelsFile = "pp3data/labels-"+descrip+".csv"

#The phi matrix of testing attributes
features = np.genfromtxt(featuresFile, delimiter = ',')
#sets label vector (need to transpose to make a column vector)
t = np.genfromtxt(labelsFile, delimiter = ',')
#Constants for ease of access for total number of training examples, testing set size, training set size, eta and alpha
N = len(features)
testSize = N//3
n = N - testSize
eta = 0.01
alpha = 0.1
alphaI = np.diag([alpha for i in range(len(features[0]) + 1)])

#Matrices to hold the training set, their labels, the test set, and their labels
trainFeatures = np.c_[np.ones(n), np.matrix(features[testSize:])]
trainLabels = np.transpose(np.matrix(t[testSize:]))
testFeatures = np.c_[np.ones(testSize), np.matrix(features[:testSize])]
testLabels = np.transpose(np.matrix(t[:testSize]))

#Arrays to hold the w vectors and their time stamps for both newton's method and gradient descent
newtonStampsPerW = []
gdStampsPerW = []
allNewtonWs = []
allGDWs = []

#repeat three times per the instructions
for repeat in range(3):
    
    #Arrays to hold values for the time stamps for calculating each w in this iteration and the w vectors for storage 
    gdTimeStamps = []
    newtonTimeStamps = []
    newtonWs = []
    gdWs = []
    
    #For Newton's Method---------------------------------------------------------------------------------------------
    start = time.time()
    #Start with the iteration past w = 0 since that is insignificant in calculating and makes for testing the limit conditions
    #Easier. Start R as diagonals of 0.25 since y will always be 0.5 when w = 0 and 0.5 * (1-0.5) = 0.25. using equation in 
    #the instructions for updating W with w_n = 0:
    w_PrevNewton =  -(alphaI + np.transpose(trainFeatures) * np.diag([0.25 for i in range(n)]) * trainFeatures).I * (np.transpose(trainFeatures) * (np.transpose(np.matrix([0.5 for i in range(n)]))-trainLabels))
    end = time.time()
    #Append this w and the time it took to do this calculation to the appropriate arrays
    newtonTimeStamps.append(end-start)
    newtonWs.append(w_PrevNewton)
    
    #Calculate y and R based on y's results
    y = np.transpose(np.matrix([1/(1+np.exp((-np.transpose(w_PrevNewton) * np.transpose(trainFeatures[i]))[0,0])) for i in range(n)]))
    R = np.diag([y[i,0]*(1-y[i,0]) for i in range(n)])
    #update w with the full equation provided
    w_NextNewton = w_PrevNewton - (alphaI + np.transpose(trainFeatures) * R * trainFeatures).I * (np.transpose(trainFeatures) * (y - trainLabels) + alpha * w_PrevNewton)
    end = time.time()
    #Append the w and time to the arrays
    newtonTimeStamps.append(end-start)
    newtonWs.append(w_NextNewton)
    
    #We have updated w twice now, so we are going on the third iteration
    its = 2
    #for every iteration, test that we have not iterated too much and that the w is being modified by a significant ammount
    #(i.e. not converging)
    while np.linalg.norm(w_NextNewton - w_PrevNewton)/np.linalg.norm(w_PrevNewton) > 0.01 and its < 100:
        #Set prev to be the last calculated w
        w_PrevNewton = w_NextNewton
        #Calculate y and R as above and update w appropriately
        y = np.transpose(np.matrix([1/(1+np.exp((-np.transpose(w_PrevNewton) * np.transpose(trainFeatures[i]))[0,0])) for i in range(n)]))
        R = np.diag([y[i,0]*(1-y[i,0]) for i in range(n)])
        w_NextNewton = w_PrevNewton - (alphaI + np.transpose(trainFeatures) * R * trainFeatures).I * (np.transpose(trainFeatures) * (y - trainLabels) + alpha * w_PrevNewton)
        end = time.time()
        #increment the iteration count and add time stamp and w to the rigth arrays
        its += 1
        newtonTimeStamps.append(end-start)
        newtonWs.append(w_NextNewton)
        
    #For Gradient Descent --------------------------------------------------------------------------------------------------
    start = time.time()
    #Calculate the iteration of w after the 0 initialization using gradient descent/ascent
    w_PrevGD = -eta * (np.transpose(trainFeatures) * (np.transpose(np.matrix([0.5 for i in range(n)]))-trainLabels))
    end = time.time()
    #add the time stamp and w vector to the appropriate arrays
    gdTimeStamps.append(end-start)
    gdWs.append(w_PrevGD)
  
    #Update y based on the above w and then update w based on that y
    y = np.transpose(np.matrix([1/(1+np.exp((-np.transpose(w_PrevGD) * np.transpose(trainFeatures[i]))[0,0])) for i in range(n)]))
    w_NextGD = w_PrevGD - eta * (np.transpose(trainFeatures) * (y - trainLabels) + alpha * w_PrevGD)
    end = time.time()
    #Append the new y and time stamp to the arrays
    gdTimeStamps.append(end-start)
    gdWs.append(w_NextGD)
    
    #Since we have updated w twice now, set iteration count to 2
    its = 2
    #For every iteration, test that we have not iterated too many times and that the w is being modified by a significant
    #amount (i.e. not converging)
    while np.linalg.norm(w_NextGD - w_PrevGD)/np.linalg.norm(w_PrevGD) >= 0.01 and its < 6000:
        w_PrevGD = w_NextGD
        y = np.transpose(np.matrix([1/(1+np.exp((-np.transpose(w_PrevGD) * np.transpose(trainFeatures[i]))[0,0])) for i in range(n)]))
        w_NextGD = w_PrevGD - eta * (np.transpose(trainFeatures) * (y - trainLabels) + alpha * w_PrevGD)
        end = time.time()
        if its % 10 == 0:
            gdTimeStamps.append(end-start)
            gdWs.append(w_NextGD)
        its += 1
        
    #bookkeeping of time stamps--------------------------------------------------------------------------------------------------
    if repeat == 0:
        newtonStampsPerW = [[] for i in range(len(newtonTimeStamps))]
        gdStampsPerW = [[] for i in range(len(gdTimeStamps))]
        for i in range(len(newtonTimeStamps)):
            newtonStampsPerW[i].append(newtonTimeStamps[i])
        for i in range(len(gdTimeStamps)):
            gdStampsPerW[i].append(gdTimeStamps[i])
        allNewtonWs = newtonWs.copy()
        allGDWs = gdWs.copy()
    else:
        for i in range(len(newtonTimeStamps)):
            newtonStampsPerW[i].append(newtonTimeStamps[i])
        for i in range(len(gdTimeStamps)):
            gdStampsPerW[i].append(gdTimeStamps[i])
  
newtonMeans = [np.mean(newtonStampsPerW[i]) for i in range(len(newtonStampsPerW))]
gdMeans = [np.mean(gdStampsPerW[i]) for i in range(len(gdStampsPerW))]
#Error Calculation ------------------------------------------------------------------------
newtonError = []
#For each test case:
for w in newtonWs:
    sucCount = 0
    for i in range(len(testLabels)):
        #if the sigmoid correctly classifies the example with the linear regression w, increment the success count
        if ((1/(1 + np.exp(-np.transpose(w) * np.transpose(testFeatures[i])))) >= 0.5 and testLabels[i, 0] == 1) or \
        ((1/(1 + np.exp(-np.transpose(w) * np.transpose(testFeatures[i])))) < 0.5 and testLabels[i,0] == 0):
            sucCount += 1
    #Calculate percent error and add the result to error array for newton's method
    newtonError.append((testSize - sucCount)/testSize)
    
gdError = []
for w in gdWs:
    sucCount = 0
    for i in range(len(testLabels)):
        #if the sigmoid correctly classifies the example with the linear regression w, increment the success count
        if ((1/(1 + np.exp(-np.transpose(w) * np.transpose(testFeatures[i])))) >= 0.5 and testLabels[i, 0] == 1) or \
        ((1/(1 + np.exp(-np.transpose(w) * np.transpose(testFeatures[i])))) < 0.5 and testLabels[i,0] == 0):
            sucCount += 1
    # alculate the percent error and add it to the error array for gradient descent
    gdError.append((testSize - sucCount)/testSize)
  
#Plot the errors as functions of time
plt.plot(newtonMeans, newtonError)
plt.show()
plt.plot(gdMeans, gdError)
plt.show()