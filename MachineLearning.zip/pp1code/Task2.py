import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import math


#A function to calculate the log of a factorial of an integer in a manner that 
#does not result in data overfolow
def log_fact(number):
    tot = 0
    while number > 0:
        tot += math.log(number)
        number -= 1
    return tot

#opens and splits the words for each file (training and test respectively)
file = open("training_data.txt", "r")
training_file_words = file.readline().split()

file = open("test_data.txt", "r")
test_file_words = file.readline().split()

#Creates a vocabulary of all the words in both files and a dictionary for counts
vocabulary = training_file_words + test_file_words
vocab_dict = {word:0 for word in vocabulary}
vocabulary = vocab_dict.keys()
K = len(vocabulary)

#Arrays to hold evidence and perplexity values for graphs later in the code
log_evidences = []
test_perplexities = []

#The size of the testing/training sets, and the trial size to use for Task 2 plots
N = len(training_file_words)
n = N//128
training_set = training_file_words[:n]
 
#For each word encountered, increment the count dictionary entry by one
for word in training_set:
    vocab_dict[word] += 1    

#Domain for the plots, sets domain as values from 1-10 in one step intervals
aprimes = [a for a in range(1, 11)]

#For every spot of the domain
for a in aprimes:  
      
    #Calculates a0, which is based of of a scalar quantity, so multiply scalar by the dimension of the array
    a0 = K * a
       
    print("For a' = " + str(a) + ":")
    
    #Calculates the log evidence funciton of the training set based off of the equation provided. "First terms corresponds 
    #to the leading factors of the equation, numerator_prod is the log of the product in the numerator, and denom_prod 
    #is the log of the second term in the denominator
    first_terms = log_fact(a0-1) - log_fact(a0 + n - 1)
    numerator_prod = sum([log_fact(a + vocab_dict[word] - 1) for word in vocabulary])
    denom_prod = -K * log_fact(a - 1)
    #Append this evidence
    log_evidences.append(first_terms + numerator_prod + denom_prod)
    print("\tLog evidence of training set: " + str(log_evidences[-1]))
    
    #Calculate p for every word in the vocabulary
    mu = {word: (vocab_dict[word] + a)/(n + a0) for word in vocabulary}
    
    #For the test perplexities w.r.t. a via the equation (m_x + a_x)/(N + a_0) for the probability of each w_x
    test_perplexities.append(math.exp(-1/N * sum([math.log(mu[word]) for word in test_file_words])))
    print("\tPerplexity for Test data: " + str(test_perplexities[-1]))
    
#Plots the log evidences and test perplexity values for the testing data as a function of size of input
plt.plot(aprimes, log_evidences) 
plt.show()
plt.plot(aprimes, test_perplexities)
plt.show()