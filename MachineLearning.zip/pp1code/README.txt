pp1code version 1.0 09/11/2018

-----------------------------------------------------------
GENERAL USE NOTES
-----------------------------------------------------------
-Code was compiled and drafted using the Spyder
 IDE for Python 3.4 that came with Anaconda
 Navigator

-All dependent files: pg121.txt.clean, pg141.txt.clean,
 pg1400.txt.clean, test_data.txt, and training_data.txt 
 must be in a subdirectory called pp1data which is located
 in the same directory that the code is being executed from.

-Code is available in files Task1.py, Task2.py, and Task3.py
 which all correspont to appropriate experiments in the 
 project assignment.

------------------------------------------------------------
USE OF CODE FILES
------------------------------------------------------------
-Execute code via IDE or linux system. In an IDE, use run
 command. From Linux terminal, use command
    >python path/to/file
 granted the gile is granted appropriate permissions

-Must have math, numpy, and matplotlib libraries installed.
 can be installed via Anaconda's website: 
     https://www.anaconda.com/download/
 or on Linux systems:
     python -m pip install --user matplotlib math numpy



For any questions contact: cudevine@indiana.edu