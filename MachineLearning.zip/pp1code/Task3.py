import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import math

#Creates this array in floating point numbers
file = open("pp1data/pg121.txt.clean", "r")
#Looking at characters in this file, they are from Jane Austen's Northanger Abbey
training_set = [word for line in file for word in line.split()]

file = open("pp1data/pg141.txt.clean", "r")
#Looking at this file's characters, they are from Mansfield Park by Jane Austen
test_set1 = [word for line in file for word in line.split()]

file = open("pp1data/pg1400.txt.clean", "r")
#Looking at characters from this excerpt, the work is Charles Dickens' Great Expectations
test_set2 = [word for line in file for word in line.split()]

vocabulary = test_set1 + test_set2 + training_set
vocab_count = {word:0 for word in vocabulary}
vocabulary = vocab_count.keys()
K = len(vocabulary)
alpha = 2
a0 = 2 * K

#Training the training set
N = len(training_set)
for word in training_set:
    vocab_count[word] += 1
#Setting p(mx) based off of the testing file
mu = {word:((vocab_count[word] + alpha)/(N + a0)) for word in vocabulary}

#Now need to test the model on test_set1
vocab_count = {word:0 for word in vocabulary}    
N = len(test_set1)
perplexity1 = math.exp(-1/N * sum([math.log(mu[word]) for word in test_set1]))

#Now need to test the model on test_set2
vocab_count = {word:0 for word in vocabulary}    
N = len(test_set2)
perplexity2 = math.exp(-1/N * sum([math.log(mu[word]) for word in test_set2]))

print("Perplexity of pg141.txt.clean based off of pg121.txt.clean: " + str(perplexity1))
print("Perplexity of pg1400.txt.clean based off of pg121.txt.clean: " + str(perplexity2))
print("The test page that is most like the training author based off of diction is: " + ("pg141.txt.clean" if perplexity1 < perplexity2 else "pg1400.txt.clean"))

