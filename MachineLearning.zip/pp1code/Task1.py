import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import math

#opens and splits the words for each file (training and test respectively)
file = open("pp1data/training_data.txt", "r")
training_file = file.readline().split()

file = open("pp1data/test_data.txt", "r")
test_set = file.readline().split()

#Creates a vocabulary of all the words in both files, a counting dictionary, and a and a0 value per 
#Task 1 instructions
vocabulary = training_file + test_set
vocab_count = {word: 0 for word in vocabulary}
vocabulary = vocab_count.keys()
K = len(vocabulary)
a = 2
a0 = a * K

#Arrays to hold test and training perplexities respectively for graphs later in the code
perplexities_test_ml = []
perplexities_test_map = []
perplexities_test_pd = []
perplexities_ml = []
perplexities_map = []
perplexities_pd = []

#The size of the training set, and the trial sizes to use for Task 1 plots
N = len(training_file)
sizes = [N//128, N//64, N//16, N//4, N]

#For each of the desired sizes: extract the first that many words from the training file
for size in sizes:
    
    training_set = training_file[:size]
    #Count how many times each word is used
    for word in training_set:
        vocab_count[word] += 1
    #Add one to the size to account for inputs that never occured (how I address test values that are 
    #not in training set). Considering the sizes, adding one should not impact probabilities heavily
    new_size = len(training_set) + 1 
    
    #Probability dictionarys to store word snad their probabilities
    mu_ml = {}
    mu_map = {}
    mu_pd = {}
   
    #Dictionary with value of 1 indicating the word was in the training set, 0 if it wasnt 
    quick_lookup = {key:0 for key in vocabulary}
    for word in training_set:
        quick_lookup[word] = 1
        
    #Saves testing probabilities based off of our models for each word in the vocabulary
    for word in vocab_count.keys():
        mu_ml[word] = vocab_count[word]/new_size
        mu_map[word] = (vocab_count[word] + a - 1)/(new_size + a0 - K)
        mu_pd[word] = (vocab_count[word] + a)/(new_size + a0)
        
    #Probability to be used for p = 0 in map since log(0) = -infinity. Simply assuming that such words are 
    #incredibly sparse, and count them only once for every set one larger than the current set
    p_missing_mu = 1/new_size
   
    print("Size = " + str(size))
    #For training maximum likelihood, append the perplexity of the current model via the equation m_x/N for the probability of each w_x
    perplexities_ml.append(math.exp(-1/new_size * sum([math.log(mu_ml[word]) for word in training_set])))
    print("\tPerplexity of Maximum Likelihood in training set: " + str(perplexities_ml[-1]))
    
    #For training map, append the perplexity of the current model via the equation (m_x + a_x - 1)/(N + a_0 - K) for the probability of each w_x
    perplexities_map.append(math.exp(-1/new_size * sum([math.log(mu_map[word]) for word in training_set])))
    print("\tPerplexity of Maximum A Posteriori in training set: " + str(perplexities_map[-1]))
    
    #For training predictive distribution, append the perplexity of the current model via the equation (m_x + a_x)/(N + a_0) for the probability of each w_x
    perplexities_pd.append(math.exp(-1/new_size * sum([math.log(mu_pd[word]) for word in training_set])))
    print("\tPerplexity of Predictive Distribution in training set: " + str(perplexities_pd[-1]))
    
    #For testing maximum likelihood, do as above, substituting the missing error for words that were not in the testing data
    perplexities_test_ml.append(math.exp(-1/N * sum([math.log(mu_ml[word]) if quick_lookup[word] != 0 else math.log(p_missing_mu) for word in test_set])))
    print("\tFor Maximum Likelihood in test set: " + str(perplexities_test_ml[-1]))
    
    #For testing map
    perplexities_test_map.append(math.exp(-1/N * sum([math.log(mu_map[word]) for word in test_set])))
    print("\tFor Maximum A Posteriori in test set: " + str(perplexities_test_map[-1]))
    
    #For testing predictive distribution
    perplexities_test_pd.append(math.exp(-1/N * sum([math.log(mu_pd[word]) for word in test_set])))
    print("\tFor Predictive Distribution in test set: " + str(perplexities_test_pd[-1]))
    
    #Reset word counter for next size iteration
    vocab_count = {word:0 for word in vocabulary}

#Plots perplexity values for the testing and train data as a function of size of 
#testing size for the three models on seperate graphs (first graph is training set, second is testing)    
plt.plot(sizes, perplexities_ml, sizes, perplexities_map, sizes, perplexities_pd)
plt.show()
plt.plot(sizes, perplexities_test_ml, sizes, perplexities_test_map, sizes, perplexities_test_pd)
plt.show()