#! /usr/bin/env python
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import random
import csv

#Change these lines to match dataset used, number of documents in the set, number of topics, number of iterations,
#alpha, beta, and number of words per topic in query
data = "20newsgroups"
docCount = 200
K = 20
alpha = 5 / K
beta = 0.01
its = 500
kWords = 5

#Initialization of words array and document indices 
words = []
docs = []
for i in range(docCount):
    filename = "pp4data/" + data + "/" + str(i + 1) 
    file = open(filename, "r")
    fileWords = file.readline().split()
    docLen = len(fileWords)
    docAppend = [i for j in range(docLen)]
    words += fileWords
    docs += docAppend

#Set N, the vocabulary, and V
n = len(words)
vocab = {}
for word in words:
    vocab[word] = ""
vocab = list(vocab.keys())
vocabLength = len(vocab)

#Set a mapping of word to index in vocabulary to be used in resetting the word indices array
hashWordToVocabIndex = {}
for i in range(vocabLength):
    hashWordToVocabIndex[vocab[i]] = i
  
#Initialize word indices, z as an array of randomly assigned topics (for initialization), and shuffled index array 
z = []
pi = []
for i in range(n):
    words[i] = hashWordToVocabIndex[words[i]]
    z += [random.randint(0, K - 1)]
    pi += [i]
random.shuffle(pi)  

#Initialize the C_d and C_t matrices that hold document counts per topic and topic counts per word respectively
C_d = np.zeros((docCount, K))
C_t = np.zeros((K, vocabLength))
for i in range(n):
    word = words[i]
    doc = docs[i]
    topic = z[i]
    C_d[doc, topic] += 1
    C_t[topic, word] += 1
    
#Initialize probability array (all to zero initially)
probs = [0 for i in range(K)]

#for every iteration: 
for i in range(its):
    #For every element of the shuffled indices:
    for j in range(n):
        #Extract the element's index and get the respective word, document, and topic
        index = pi[j]
        word = words[index]
        topic = z[index]
        doc = docs[index]
        #Decrement the document count per topic and word count per topic by one based on the above extractions
        C_d[doc, topic] -= 1
        C_t[topic, word] -= 1
        #Calculate new probabilities for the topic
        for k in range(K):
            probs[k] = ((C_t[k, word] + beta)/(vocabLength * beta + sum(C_t[k,:]))) * \
            ((C_d[doc, k] + alpha)/(K * alpha + sum(C_d[doc,:])))
        #Normalize P:
        tot = sum(probs)
        for k in range(K):
            probs[k] = probs[k] / tot
        #Sample from P:
        thresh = random.random()
        tot = probs[0]
        count = 0
        while thresh > tot and count < K - 1:
            tot += probs[count + 1]
            count += 1
        newTopic = count
        #Reset z as the new topic, and C-d and C_t counts accordingly
        z[index] = newTopic 
        C_d[doc, newTopic] += 1
        C_t[newTopic, word] += 1

#holds topic representations of documents and the list of words per topic for writing
        #To the csv file
topicReps = [[] for d in range(docCount)]
topicWords = []
#Need C_t for this (words per topic), topics x word calculation of top k words in each topic
for k in range(K):
    #For every document, calculate the topic representation of this topic and store it in that topics' index
    for d in range(docCount):
        topicReps[d].append((C_d[d, k] + alpha)/(K * alpha + sum(C_d[doc,:])))
    #Initialize counter of top words found, array of the words, and indices of the words (so that the word can be skipped)
    found = 0
    foundWords = []
    foundWordsIndices = []
    #WHile we havent found all of the words
    while found < kWords:
        #Set the highest count and its index thus far to unachievable numbers
        mostCounts = -1
        respWordIndex = -1
        #For every element in the vocabulary:
        for i in range(vocabLength):
            #If the count of words is less than the highest count thus far or the word has already
            #Been collected, continue to the next item
            if C_t[k, i] < mostCounts or i in foundWordsIndices:
                continue
            #Otherwise, set the most counts thus far and its index for comparison
            mostCounts = C_t[k, i]
            respWordIndex = i
        #Increase the found count since a new top word has been found and append the index to the found indices and the
        #Word to the found words
        found += 1
        foundWordsIndices.append(respWordIndex)
        foundWords.append(vocab[respWordIndex])
    #Append this set of words to the collections of topic words and print it for the user
    topicWords.append(foundWords)
    print("The " + str(kWords) + " words most common for topic " + str(k + 1) + " are: " + str(foundWords))
#Write a csv file with every topic as a row and its most common words as the elements
f = open("topicwords.csv", "w")
with f:
    write = csv.writer(f)
    write.writerows(topicWords)
