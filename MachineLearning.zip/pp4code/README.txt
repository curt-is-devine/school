pp4code version 1.0 12/5/2018

-----------------------------------------------------------
GENERAL USE NOTES
-----------------------------------------------------------
-Code was compiled and drafted using the Spyder
 IDE for Python 3.4 that came with Anaconda
 Navigator

-All data files must be in a subdirectory called pp4data within
 an additional directory that contains all of the necessary files
 with the pp4 directory located in the same directory that the code 
 is being executed from. In addition, all dependent files must follow 
 the format: "n" for n as an integer index of which file in the 
 set it is for words and index.csv for the respective labels
 for all files, with the first column being the document
 index and the second being the appropriate label.

 i.e.: pp4data/?/n or index.csv

-Code is available in files PP4_Part1.py and PP4_Part2.py (unfinished)
 which all correspond to appropriate experiments in 
 the project assignment.

-In order to use the code you can decide what
 files to investigate by changing the descriptor variable at the
 top of each file to the descriptor placeheld by the "?" above. 
 The docCount variable underneath corresponds to the final N in 
 the subdirectory. In the pp4_part1.py file, alpha, beta, number of
 LDA iterations, and query number of words all need specified as well.
 In pp4_part2.py, alpha for linear regression and number of samples
 for each training set size to use for data plotting. Since the code 
 is not finished, the topicReps and vocabulary from pp4_part1.py 
 need to be copied directly into the code as well into the 
 topic_rep and vocabulary variables.

------------------------------------------------------------
USE OF CODE FILES
------------------------------------------------------------
-Execute code via IDE or linux system. 

 In an IDE use run command. This is by far the best performing option
 since math plots are allowed and correct output was generated for me
 as opposed to on the Tank SICE server, in which case comment out
 the final couple of lines of code corresponding to the plots
 at the end of each script

 From Linux terminal (That allows use of matplotlib), use command
    >python ./path/to/file
 granted the file is given appropriate permissions and graphical
 displays are allowed. On the Tank server where I tested this code, 
 matplotlib caused the program to fail every time.

-Must have random, numpy, csv, and matplotlib libraries installed.
 Can be installed via Anaconda's website: 
     https://www.anaconda.com/download/
 or on Linux systems:
     python -m pip install --user matplotlib math numpy csv



For any questions contact: cudevine@indiana.edu